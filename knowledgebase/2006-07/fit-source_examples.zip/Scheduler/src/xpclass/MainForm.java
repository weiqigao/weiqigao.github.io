package xpclass;

import java.awt.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import xpclass.ui.AddEventDialog;
import xpclass.ui.EventTable;

public class MainForm extends JFrame {

	public static final DateFormat DATEFORMAT = new SimpleDateFormat("MM/dd/yyyy HH:mm");
	
	// event 1
	static final String EVENT1NAME = "Breakfast";
	static final String EVENT1START_STR = "10/15/2005 08:00";
	static final String EVENT1END_STR = "10/15/2005 09:00";
	static Date EVENT1START;
	static Date EVENT1END;

	// event 2
	static final String EVENT2NAME = "Lunch";	
	static final String EVENT2START_STR = "10/15/2005 11:30";
	static final String EVENT2END_STR = "10/15/2005 12:00";
	static Date EVENT2START;
	static Date EVENT2END;

	// event 3
	static final String EVENT3NAME = "Dinner";
	static final String EVENT3START_STR = "10/15/2005 17:00";
	static final String EVENT3END_STR = "10/15/2005 18:00";
	static Date EVENT3START;
	static Date EVENT3END;
	public static String ADDBUTTON = "Add Event";

	private Schedule schedule;
	
	static {
		try {
			EVENT1START = DATEFORMAT.parse(EVENT1START_STR);
			EVENT1END = DATEFORMAT.parse(EVENT1END_STR);

			EVENT2START = DATEFORMAT.parse(EVENT2START_STR);
			EVENT2END = DATEFORMAT.parse(EVENT2END_STR);

			EVENT3START = DATEFORMAT.parse(EVENT3START_STR);
			EVENT3END = DATEFORMAT.parse(EVENT3END_STR);
		} catch (ParseException ex) {
			System.err.println(ex.toString());
		}
	}
	
	
	public MainForm() {
		final Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());		
		EventTable eventTable = new EventTable();
		schedule = new Schedule();
		Event event1 = new EventImpl();
		event1.setName(EVENT1NAME);
		event1.setStartDate(EVENT1START);
		event1.setEndDate(EVENT1END);
		
		Event event2 = new EventImpl();
		event2.setName(EVENT2NAME);
		event2.setStartDate(EVENT2START);
		event2.setEndDate(EVENT2END);

		Event event3 = new EventImpl();
		event3.setName(EVENT3NAME);
		event3.setStartDate(EVENT3START);
		event3.setEndDate(EVENT3END);

		schedule.addEvent(event2);
		schedule.addEvent(event3);
		schedule.addEvent(event1);
		
		schedule.addScheduleUpdateHandler(eventTable);
		
		Collection allEvents = schedule.getAllEvents();
		eventTable.setEvents((Event[]) allEvents.toArray(new Event[allEvents.size()]));
		contentPane.add(BorderLayout.CENTER, eventTable);
		contentPane.add(BorderLayout.WEST, createButtonPanel());
	}
	
	/**
	 * 
	 * @return
	 */
	private JPanel createButtonPanel() {
		
		JPanel panel = new JPanel();
		panel.setLayout( new GridBagLayout() );
		
		GridBagConstraints gbc = new GridBagConstraints();
		
		gbc.gridx = 0;
		gbc.gridy = 0;
		
		Insets insets = new Insets( 10, 10, 10, 10 ); 
		gbc.insets = insets;
		
		JButton button = new JButton(ADDBUTTON);
		button.addActionListener(new AddEventController(new AddEventDialog(), new ValidatorImpl(), schedule));
		
		panel.add(button, gbc);
		
		return panel;
	}

	public static void main(final String [] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run()
            {
                MainForm gui = new MainForm();
                gui.setTitle("Scheduler");
                Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
                gui.setSize(640, 480);
                gui.setLocation((int) ((dim.getWidth() - gui.getWidth()) / 2),
                                (int) ((dim.getHeight() - gui.getHeight()) / 6));
                if (args.length == 0) {
                    gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                }
                gui.setVisible(true);
            }
        });
	}
}
