package xpclass;

import xpclass.ui.AddInput;

public interface Validator {
	
	public static final String NAME_ERR = "NULL name.";
	public static final String START_DATE_ERR = "Invalid start date.";
	public static final String START_TIME_ERR = "Invalid start time.";	
	public static final String END_DATE_ERR = "Invalid end date.";
	public static final String END_TIME_ERR = "Invalid end time.";
	
	
	public static final String DATE_FORMAT = "MM/dd/yyyy";
    public static final String TIME_FORMAT = "HH:mm";
    	
	
	public boolean validate (AddInput form);

}
