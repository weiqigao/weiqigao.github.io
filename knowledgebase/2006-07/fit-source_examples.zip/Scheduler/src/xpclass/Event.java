package xpclass;

import java.util.Date;

public interface Event {

	public abstract int compareTo(Object obj);

	public abstract boolean equals(Object obj);

	public abstract int hashCode();

	public abstract Date getEndDate();

	public abstract void setEndDate(Date endDate);

	public abstract String getName();

	public abstract void setName(String name);

	public abstract Date getStartDate();

	public abstract void setStartDate(Date startDate);

}