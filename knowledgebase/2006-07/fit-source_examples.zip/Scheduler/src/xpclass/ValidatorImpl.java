package xpclass;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import xpclass.ui.AddInput;

public class ValidatorImpl implements Validator {

	public boolean validate(AddInput form) {
		
		SimpleDateFormat date_formatter = newSimpleDateFormat(DATE_FORMAT);
		
		SimpleDateFormat time_formatter = newSimpleDateFormat(TIME_FORMAT);
		
		SimpleDateFormat combined = new SimpleDateFormat(DATE_FORMAT + " " +TIME_FORMAT);
		boolean val = true;
		Date start_date = null;
		Date end_date = null;
		
		if ((form.getName() == null) || (form.getName().length() == 0)){			
			val = false;
			form.handleNameError(NAME_ERR);
			return val;
		}

		if (isDateInvalid(form.getStartDate(), date_formatter)) {
			form.handleStartDateError(START_DATE_ERR);
			return false;
		}
		
		if (isDateInvalid(form.getStartTime(), time_formatter)) {
			form.handleStartTimeError(START_TIME_ERR);
			return false;
		}

		if (isDateInvalid(form.getEndDate(), date_formatter)) {
			form.handleEndDateError(END_DATE_ERR);
			return false;
		}
		
	
		if (isDateInvalid(form.getEndTime(), time_formatter)) {
			form.handleEndTimeError(END_TIME_ERR);
			return false;
		}		
		
		try {
			start_date = combined.parse(form.getStartDate()+ " "+ form.getStartTime());
			
		}catch (ParseException pe) {
			val = false;
			form.handleEndTimeError(END_TIME_ERR);
			return val;
		}
		
		try {
			end_date = combined.parse(form.getEndDate()+ " "+ form.getEndTime());
			
		}catch (ParseException pe) {
			val = false;
			form.handleEndTimeError(END_TIME_ERR);
			return val;
		}		
		
		if ((start_date !=null) && (end_date !=null)) {
			if (end_date.before(start_date) || ( start_date.after(end_date)) || start_date.equals(end_date)){
				val = false;
				form.handleEndTimeError(END_TIME_ERR);
				return val;
			}
		}
		

		return val;
	}

	private SimpleDateFormat newSimpleDateFormat(String format) {
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		formatter.setLenient(false);
		return formatter;
	}
	
	private boolean isDateInvalid(String date, SimpleDateFormat formatter) {
		return date == null || !isDateParseable(date, formatter);
	}

	private boolean isDateParseable(String date, SimpleDateFormat formatter) {
		try {
			formatter.parse(date);
			return true;
		} catch (ParseException pe) {
			return false;
		}
	}
}
