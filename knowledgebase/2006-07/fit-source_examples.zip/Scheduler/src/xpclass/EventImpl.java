package xpclass;

import java.util.Date;

public class EventImpl implements Comparable, Event{

	// name of the event
	private String name = null;
	// start date and time of the event
	private Date startDate = null;
	// end date and time of the event
	private Date endDate = null;
	
		
	/* (non-Javadoc)
	 * @see xpclass.Event#compareTo(java.lang.Object)
	 * 
	 * Returns 0 when current object and 'obj' represent two events where startDate, 
	 * endDate and Name are same. Returns (> 0) when 'this' event occurs later in time than
	 * event represented by 'obj'.
	 * 
	 */
	public int compareTo(Object obj)		
	{
		int compare = 0;
		Event eventTwo = (Event)obj;
		
		compare = this.startDate.compareTo(eventTwo.getStartDate());
		
		if(compare == 0)
		{
			compare = this.endDate.compareTo(eventTwo.getEndDate());
		}
		
		if(compare == 0) 
		{
			compare = this.name.compareTo(eventTwo.getName());
		}
		
		return compare;
	}
	
	/* (non-Javadoc)
	 * @see xpclass.Event#equals(java.lang.Object)
	 */
	public boolean equals(Object obj)
	{
		boolean equal = false;
		Event eventTwo = (Event)obj;
		
		if(		this.name.equals(eventTwo.getName()) 
			&& (this.startDate.compareTo(eventTwo.getStartDate())== 0)
			&& (this.endDate.compareTo(eventTwo.getEndDate()) == 0))
			equal = true;
		
		return equal;
	}
	
	/* (non-Javadoc)
	 * @see xpclass.Event#hashCode()
	 */
	public int hashCode()
	{	
		int result = 0;
		result = name.hashCode()+startDate.hashCode()+startDate.hashCode();
		
		return result;
	}
	
	/* (non-Javadoc)
	 * @see xpclass.Event#getEndDate()
	 */
	public Date getEndDate() {
		return endDate;
	}
	/* (non-Javadoc)
	 * @see xpclass.Event#setEndDate(java.util.Date)
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	/* (non-Javadoc)
	 * @see xpclass.Event#getName()
	 */
	public String getName() {
		return name;
	}
	/* (non-Javadoc)
	 * @see xpclass.Event#setName(java.lang.String)
	 */
	public void setName(String name) {
		this.name = name;
	}
	/* (non-Javadoc)
	 * @see xpclass.Event#getStartDate()
	 */
	public Date getStartDate() {
		return startDate;
	}
	/* (non-Javadoc)
	 * @see xpclass.Event#setStartDate(java.util.Date)
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	
}
