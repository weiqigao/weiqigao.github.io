package xpclass;

public interface ScheduleUpdateHandler {

	public void handleScheduleUpdate(Event[] events);
}
