package xpclass;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

import xpclass.ui.AddInput;

public class AddEventController implements ActionListener, Controller {
	
	private AddInput inputForm = null;
	private Validator validator = null;
	private Schedule schedule = null;
	
	public AddEventController(AddInput inputForm, Validator validator, Schedule schedule)
	{
		this.inputForm = inputForm;
		this.validator = validator;
		this.schedule = schedule;
		this.inputForm.setController(this);
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		inputForm.display();
	}
	
	/* (non-Javadoc)
	 * @see xpclass.Controller#addEvent(xpclass.ui.AddInput)
	 */
	/* (non-Javadoc)
	 * @see xpclass.Controller#addEvent(xpclass.ui.AddInput)
	 */
	public void addEvent(AddInput inputForm)
	{
		if(validator.validate(inputForm))
		{
			Event event = new EventImpl();
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm");
			sdf.setLenient(false);
			Date sDate = null;
			Date eDate = null;
			try
			{
				sDate = sdf.parse(inputForm.getStartDate()+" "+inputForm.getStartTime());
				eDate = sdf.parse(inputForm.getEndDate()+" "+inputForm.getEndTime());
				
			}catch(Exception e)
			{
				throw new UnsupportedOperationException();
			}
			
			event.setName(inputForm.getName());
			event.setStartDate(sDate);
			event.setEndDate(eDate);
			schedule.addEvent(event);
			
			inputForm.destroy();
		}
	}
}
