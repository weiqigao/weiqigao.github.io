package xpclass.ui;

import xpclass.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddEventDialog extends JDialog implements AddInput {

	public static final String ADD_EVENT_ERROR = "Add Event Error";
	private JTextField nameField = null;
	private JTextField startDateField = null;
	private JTextField startTimeField = null;
	private JTextField endDateField = null;
	private JTextField endTimeField = null;
	private JButton okButton = null;
	private JButton cancelButton = null;
	
	public static final String NAME_LABEL_TEXT = "Name:";
	public static final String START_DATE_LABEL_TEXT = "Start Date:";
	public static final String START_TIME_LABEL_TEXT = "Start Time:";
	public static final String END_DATE_LABEL_TEXT = "End Date:";
	public static final String END_TIME_LABEL_TEXT = "End Time:";
	public static final String OK_BUTTON_TEXT = "OK";
	public static final String CANCEL_BUTTON_TEXT = "Cancel";
	
	Controller ctr = null;
	
	public AddEventDialog() throws HeadlessException {
		super();
		
		JPanel panel = createInputPanel();
		this.setContentPane( panel );
	}
	
	/**
	 * 
	 * @return
	 */
	private JPanel createInputPanel() {
		
		JPanel panel = new JPanel();		
		panel.setLayout( new GridBagLayout() );
		
		Insets insets = null;
		GridBagConstraints gbc = null;
		JLabel label = null;
		
		// name
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = insets;
		label = new JLabel(NAME_LABEL_TEXT);
		panel.add( label, gbc );
		
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.gridwidth = 3;
		gbc.insets = insets;
		gbc.anchor = GridBagConstraints.WEST;
		nameField = new JTextField( 20 );
		label.setLabelFor( nameField );
		panel.add( nameField, gbc );
		
		// date format 1
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.insets = insets;
		label = new JLabel("MM/DD/YYYY");
		panel.add( label, gbc );
		
		// time format 1
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 3;
		gbc.gridy = 1;
		gbc.insets = insets;
		label = new JLabel("HH:MM");
		panel.add( label, gbc );
		
		// start date
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.insets = insets;
		label = new JLabel(START_DATE_LABEL_TEXT);
		panel.add( label, gbc );
		
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.insets = insets;
		startDateField = new JTextField( 10 );
		label.setLabelFor( startDateField );
		panel.add( startDateField, gbc );
		
		// start time
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 2;
		gbc.gridy = 2;
		gbc.insets = insets;
		label = new JLabel(START_TIME_LABEL_TEXT);
		panel.add( label, gbc );
		
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 3;
		gbc.gridy = 2;
		gbc.insets = insets;
		startTimeField = new JTextField( 10 );
		label.setLabelFor( startTimeField );
		panel.add( startTimeField, gbc );
		
		// date format 2
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 1;
		gbc.gridy = 3;
		gbc.insets = insets;
		label = new JLabel("MM/DD/YYYY");
		panel.add( label, gbc );
		
		// time format 2
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 3;
		gbc.gridy = 3;
		gbc.insets = insets;
		label = new JLabel("HH:MM");
		panel.add( label, gbc );
		
		// End Date
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.insets = insets;
		label = new JLabel(END_DATE_LABEL_TEXT);
		panel.add( label, gbc );
		
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 1;
		gbc.gridy = 4;
		gbc.insets = insets;
		endDateField = new JTextField(10);
		label.setLabelFor( endDateField );
		panel.add( endDateField, gbc );
		
		// End Time
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 2;
		gbc.gridy = 4;
		gbc.insets = insets;
		label = new JLabel(END_TIME_LABEL_TEXT);
		panel.add( label, gbc );
		
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 3;
		gbc.gridy = 4;
		gbc.insets = insets;
		endTimeField =  new JTextField(10);
		label.setLabelFor( endTimeField );
		panel.add( endTimeField, gbc );
		
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 1;
		gbc.gridy = 5;
		gbc.insets = insets;
		okButton = new JButton( OK_BUTTON_TEXT );
		okButton.addActionListener( new ActionListener(){
			
			public void actionPerformed(ActionEvent arg0) 
			{
				handleOkButtonClick();
			}
			
		});
		panel.add( okButton, gbc );
		
		insets = new Insets( 2, 2, 2, 2 );
		gbc = new GridBagConstraints();
		gbc.gridx = 2;
		gbc.gridy = 5;
		gbc.insets = insets;
		cancelButton = new JButton( CANCEL_BUTTON_TEXT );
		cancelButton.addActionListener( new ActionListener(){
			
			public void actionPerformed(ActionEvent arg0) 
			{
				handleCancelButtonClick();
			}
			
		});
		panel.add( cancelButton, gbc );
		
		return panel;	
	}

	
	
	public String getEndDate() {
		return endDateField.getText();
	}

	public String getEndTime() {
		return endTimeField.getText();
	}

	public String getStartDate() {
		return startDateField.getText();
	}

	public String getStartTime() {
		return startTimeField.getText();
	}

	public String getName() {
		return nameField.getText();
	}
	
	public void handleEndDateError(String msg) {
		showErrorMessageDialog(msg);
		
		endDateField.requestFocus();
	}
	
	private void showErrorMessageDialog(String msg) {
		JOptionPane.showMessageDialog(this, msg, ADD_EVENT_ERROR, JOptionPane.ERROR_MESSAGE);
	}

	public void handleEndTimeError(String msg) {
		showErrorMessageDialog(msg);
		
		endTimeField.requestFocus();		
	}

	public void handleNameError(String msg) {
		showErrorMessageDialog(msg);
		
		nameField.requestFocus();
	}

	public void handleStartDateError(String msg) {
		showErrorMessageDialog(msg);
		
		startDateField.requestFocus();
	}

	public void handleStartTimeError(String msg) {
		showErrorMessageDialog(msg);
		
		startTimeField.requestFocus();
	}

	public void display() {
		pack();
		setVisible(true);
	}
	
	public void destroy() {
		setVisible(false);
	}
	
	public void setController( Controller ctr ) {
		this.ctr = ctr;
	}
	
	private void handleOkButtonClick() {
		ctr.addEvent(this);
	}
	
	private void handleCancelButtonClick() {
		setVisible(false);
	}
	//////////////////////////////////////////////////////////////////

	public static void main(String[] args) {
	
		AddInput form = new AddEventDialog();
		form.display();
		
	}
	
}
