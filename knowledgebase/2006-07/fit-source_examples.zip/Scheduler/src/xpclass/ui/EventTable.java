package xpclass.ui;

import javax.swing.JTable;

import xpclass.Event;
import xpclass.ScheduleUpdateHandler;
import xpclass.ui.model.EventTableModel;

public class EventTable extends JTable implements ScheduleUpdateHandler{

	public void handleScheduleUpdate(Event[] events) {

		setEvents(events);
	}

	/**
	 * 
	 * @param events
	 */
	public void setEvents(Event[] events) {
		EventTableModel model = new EventTableModel(events);
		this.setModel( model );
	}
}
