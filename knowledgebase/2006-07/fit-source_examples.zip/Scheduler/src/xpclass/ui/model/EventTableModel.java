package xpclass.ui.model;

import xpclass.Event;
import xpclass.MainForm;

import javax.swing.table.AbstractTableModel;

/**
 * 
 * @author train
 *
 */
public class EventTableModel extends AbstractTableModel   {

	public static final int NAME_COLUMN_INDEX = 0;
	public static final int START_DATE_TIME_COLUMN_INDEX = 1;
	public static final int END_DATE_TIME_COLUMN_INDEX = 2;
	
	private Event[] events = null;

	/**
	 * 
	 * @param events
	 */
	public EventTableModel( Event[] events ) {
		this.events = events;
	}
	
	/**
	 * 
	 */
	public int getColumnCount() {
		return 3;
	}

	/**
	 * 
	 */
	public int getRowCount() {
		return events.length;
	}

	/**
	 * 
	 */
	public Object getValueAt(int arg0, int arg1) {
		
		switch(arg1)
		{
			case NAME_COLUMN_INDEX:
				return this.events[arg0].getName();
			case START_DATE_TIME_COLUMN_INDEX:
				if ( this.events[arg0].getStartDate() == null ) {
					return "";
				}
				else {
					return MainForm.DATEFORMAT.format(this.events[arg0].getStartDate());
				}
			case END_DATE_TIME_COLUMN_INDEX:
				if ( this.events[arg0].getEndDate() == null ) {
					return "";
				}
				else {
					return MainForm.DATEFORMAT.format(this.events[arg0].getEndDate());
				}
			default:
				System.out.println("Error finding value");
				return "";
		}
	}
	
	/**
	 * 
	 * @param events
	 */
	public void setEvents( Event[] events ) throws Exception {
		
		if( events==null || events.length<1 ) {
			throw new Exception("Illegal events argument.");
		}
		
		this.events = events;
	}

}
