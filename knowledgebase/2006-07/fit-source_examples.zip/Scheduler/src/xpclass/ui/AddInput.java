package xpclass.ui;

import java.io.IOException;

import xpclass.Controller;

public interface AddInput {

	String getName();
	String getStartDate();
	String getStartTime();
	String getEndDate();
	String getEndTime();
	
	void handleNameError(String msg);
	void handleStartDateError(String msg);
	void handleStartTimeError(String msg);
	void handleEndDateError(String msg);
	void handleEndTimeError(String msg);
	
	void display();
	void destroy();
	
	void setController( Controller ctr );
}
