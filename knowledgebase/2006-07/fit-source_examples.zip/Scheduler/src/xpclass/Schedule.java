package xpclass;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.TreeSet;

public class Schedule {

	private Collection events = new TreeSet();
	private Collection handlers = new ArrayList();
	
	public Collection getAllEvents(){
		
		return events;
	}
	
	public void addEvent(Event event) throws IllegalArgumentException {
		if(event==null) throw new IllegalArgumentException("Null event object!");
		
		events.add(event);
		
		for (Iterator iter = handlers.iterator(); iter.hasNext();) {
			ScheduleUpdateHandler element = (ScheduleUpdateHandler) iter.next();
			element.handleScheduleUpdate((Event[])events.toArray(new Event[events.size()]));
		}
	}
	
	public void addScheduleUpdateHandler(ScheduleUpdateHandler handler) throws IllegalArgumentException {
		if(handler==null)throw new IllegalArgumentException("Null handler object!");
		handlers.add(handler);
	}
}
