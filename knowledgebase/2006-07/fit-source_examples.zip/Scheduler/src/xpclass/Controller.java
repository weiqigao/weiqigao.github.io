package xpclass;

import xpclass.ui.AddInput;

public interface Controller {
	public void addEvent(AddInput inputForm);
}
