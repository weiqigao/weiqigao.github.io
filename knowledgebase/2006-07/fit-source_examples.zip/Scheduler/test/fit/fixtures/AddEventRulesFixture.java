package fit.fixtures;

import fit.ColumnFixture;
import xpclass.AbstractJemmyTestCase;
import org.netbeans.jemmy.operators.JDialogOperator;

import java.awt.*;

public class AddEventRulesFixture extends ColumnFixture {
    public String eventName;
    public String startDate;
    public String startTime;
    public String endDate;
    public String endTime;

    public boolean addSuccessful() {
        final AbstractJemmyTestCase system = SchedulerSetupFixture.system;
        if (system == null) {
            return false;
        }

        system.pushButton(system.getMainFrameOperator(), "Add Event");
        final JDialogOperator dialog = system.findDialog();
        final Container source = (Container)dialog.getSource();
        system.setLabeledTextField(source, "Name:", eventName);
        system.setLabeledTextField(source, "Start Date:", startDate);
        system.setLabeledTextField(source, "Start Time:", startTime);
        system.setLabeledTextField(source, "End Date:", endDate);
        system.setLabeledTextField(source, "End Time:", endTime);
        system.pushButton(dialog, "OK");

        final JDialogOperator error = system.findDialog();
        if (error != null) {
            system.pushButton(error, "OK");
            system.pushButton(system.findDialog(), "Cancel");
            return false;
        }


        return true;
    }
}
