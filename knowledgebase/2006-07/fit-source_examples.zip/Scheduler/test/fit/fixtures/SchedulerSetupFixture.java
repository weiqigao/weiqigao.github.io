package fit.fixtures;

import fit.Fixture;
import xpclass.AbstractJemmyTestCase;

public class SchedulerSetupFixture extends Fixture {
    public static AbstractJemmyTestCase system;

    public SchedulerSetupFixture()
    {
        system = new AbstractJemmyTestCase() {
            protected void executeTest()
            {
                //do nothing;
            }
        };

        try {
            system.setUp();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void endTest() {
        system.tearDown();
        system = null;
    }
}
