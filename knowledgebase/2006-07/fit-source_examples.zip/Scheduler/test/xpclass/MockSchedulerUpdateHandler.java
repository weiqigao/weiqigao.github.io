package xpclass;

public class MockSchedulerUpdateHandler implements ScheduleUpdateHandler {

	private boolean isHandled = false;
	
	public MockSchedulerUpdateHandler() {
		super();
		// TODO Auto-generated constructor stub
	}

	public boolean isHandled(){
		return isHandled;
	}
	public void handleScheduleUpdate(Event[] events) {
		isHandled=true;
		

	}

}
