package xpclass;

import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;

import junit.framework.TestCase;

public class ScheduleTest extends TestCase {

	Schedule _schedule;
	
	protected void setUp() throws Exception {
		super.setUp();		
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testAddNullScheduleUpdateHandler(){
		
		_schedule  = new Schedule();
		try{
			_schedule.addScheduleUpdateHandler(null);
			assertTrue(false);
			
			} catch(IllegalArgumentException eae) {
				assertTrue(true);
			}		
	}
	
	
	public void testAddScheduleUpdateHandler(){
		
		_schedule  = new Schedule();
		MockEvent event = new MockEvent();
		MockSchedulerUpdateHandler handler = new MockSchedulerUpdateHandler();
		
		_schedule.addScheduleUpdateHandler(handler);
		_schedule.addEvent(event);
		
		assertTrue(handler.isHandled());

		
	}
	
	public void testAddNull() {
		_schedule  = new Schedule();
		try{
		_schedule.addEvent(null);
		assertTrue(false);
		
		} catch(IllegalArgumentException eae) {
			assertTrue(true);
		}		
	}
	
	public void testNone() {
		_schedule  = new Schedule();
		Collection events = _schedule.getAllEvents();
		assertNotNull(events);
		assertTrue(events.isEmpty());
	}
	
	public void testOne(){
		_schedule  = new Schedule();
		_schedule.addEvent(new MockEvent());
		Collection events = _schedule.getAllEvents();
		assertNotNull(events);
		assertTrue(events.size()==1);
		
	}

	public void testTwo(){
		_schedule  = new Schedule();
		Calendar startCal1 = Calendar.getInstance();
		startCal1.set(Calendar.MONTH, 7);
		startCal1.set(Calendar.DATE, 7);
		startCal1.set(Calendar.YEAR, 2005);

		MockEvent one = new MockEvent();
		one.setName("one");
		one.setStartDate(startCal1.getTime());
		one.equalsReturn = false;
		one.hashCodeReturn = 1;
		one.compareToReturn = -1;
		
		Calendar startCal2 = Calendar.getInstance();
		startCal2.set(Calendar.MONTH, 8);
		startCal2.set(Calendar.DATE, 8);
		startCal2.set(Calendar.YEAR, 2005);
		
		MockEvent two = new MockEvent();
		two.setName("two");
		two.setStartDate(startCal2.getTime());		
		two.equalsReturn = false;
		two.hashCodeReturn =2;
		two.compareToReturn=1;
		
		_schedule.addEvent(two);
		_schedule.addEvent(one);	
				
		
		Collection events = _schedule.getAllEvents();
		assertNotNull(events);
		assertTrue(events.size()==2);
		
		Iterator iter = events.iterator();
		assertEquals( "one", ((Event)iter.next()).getName());
		assertEquals( "two", ((Event)iter.next()).getName());
	}
}
