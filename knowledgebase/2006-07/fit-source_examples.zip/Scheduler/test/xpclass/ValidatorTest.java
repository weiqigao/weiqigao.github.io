package xpclass;

import xpclass.ui.MockAddInput;
import junit.framework.TestCase;

public class ValidatorTest extends TestCase {

	private MockAddInput form = null;	
	protected void setUp() throws Exception {
		form = new MockAddInput();
		init(form);		
	}

	protected void tearDown() throws Exception {
	}

	
	private void init(MockAddInput form) {
		form.name = "Richa";
		form.startDate = "11/04/2005";
		form.startTime = "12:20";
		form.endDate = "11/06/2005";
		form.endTime = "15:30";
	}
	
	public void testNullName() {

		form.name=null;
		Validator v  = new ValidatorImpl();
		boolean success = v.validate(form);
		assertFalse(success);
		
	}
	
	public void testBadStartDate() {
		
		form.startDate="2000/11/04";
		Validator v  = new ValidatorImpl();
		boolean success = v.validate(form);
		assertFalse(success);
		
	}
	
	public void testGoodStartDate() {
		
		Validator v  = new ValidatorImpl();
		boolean success = v.validate(form);
		assertTrue(success);
		
	}
	
	public void testBadEndDate() {
		
		form.startDate="11/04/2004";
		form.endDate = "foo";
		Validator v  = new ValidatorImpl();
		boolean success = v.validate(form);
		assertFalse(success);
		assertFalse(form.handleStartDateErrorCalled);
		assertTrue(form.handleEndDateErrorCalled);
		assertEquals(Validator.END_DATE_ERR, form.handleEndDateErrorMsg);
		
	}
	
	public void testGoodEndDate() {
		
		Validator v  = new ValidatorImpl();
		boolean success = v.validate(form);
		assertTrue(success);
		
	}
	
	public void testGoodStartTime() {
		
		Validator v  = new ValidatorImpl();
		boolean success = v.validate(form);
		assertTrue(success);
		
	}
	
	public void testBadStartTime() {
		
		form.startTime="haha";
		Validator v  = new ValidatorImpl();
		boolean success = v.validate(form);
		assertFalse(success);
		assertTrue(form.handleStartTimeErrorCalled);
		assertEquals(Validator.START_TIME_ERR, form.handleStartTimeErrorMsg);
	}
	
	public void testGoodEndTime() {
		
		Validator v  = new ValidatorImpl();
		boolean success = v.validate(form);
		assertTrue(success);
		
	}
	
	public void testBadEndTime() {
		
		compareForBadEndTime("haha");
		compareForBadEndTime(null);
	}
	
	private void compareForBadEndTime(String endTime) {
		form.endTime = endTime;
		Validator v  = new ValidatorImpl();		
		assertFalse(v.validate(form));
		assertTrue(form.handleEndTimeErrorCalled);
		assertEquals(Validator.END_TIME_ERR, form.handleEndTimeErrorMsg);
		resetForm();
	}
	
	private void resetForm() {
		form = new MockAddInput();
		init(form);
	}
	
	public void testGoodDates() {		
		Validator v  = new ValidatorImpl();
		boolean success = v.validate(form);
		assertTrue(success);
		
	}
	
	public void testBadDates() {
		
		form.startDate="11/04/2005";
		form.endDate="11/02/2005";
		Validator v  = new ValidatorImpl();
		boolean success = v.validate(form);
		assertFalse(success);
		
	}
	
	
	
}
