package xpclass;

import java.text.DateFormat;

import junit.framework.TestCase;

public class MainFormTest extends TestCase {
	public void testDateFormat() {
		DateFormat dateFormat = MainForm.DATEFORMAT;

		assertEquals(MainForm.EVENT1START_STR, dateFormat.format(MainForm.EVENT1START));
		assertEquals(MainForm.EVENT1END_STR, dateFormat.format(MainForm.EVENT1END));

		assertEquals(MainForm.EVENT2START_STR, dateFormat.format(MainForm.EVENT2START));
		assertEquals(MainForm.EVENT2END_STR, dateFormat.format(MainForm.EVENT2END));

		assertEquals(MainForm.EVENT3START_STR, dateFormat.format(MainForm.EVENT3START));
		assertEquals(MainForm.EVENT3END_STR, dateFormat.format(MainForm.EVENT3END));
	}
}
