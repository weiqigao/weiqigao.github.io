package xpclass;

import java.util.Date;

public class MockEvent implements Event, Comparable {

	public int compareToReturn;
	public int hashCodeReturn;
	public boolean equalsReturn;
	public Date endDate;
	public Date startDate;
	public String name;
	
	public int hashCode(){
		return hashCodeReturn;
	}
	
	public boolean equals(){
		return equalsReturn;
	}
	
	public int compareTo(Object obj) {
		// TODO Auto-generated method stub
		return compareToReturn;
	}

	public Date getEndDate() {
		// TODO Auto-generated method stub
		return endDate;
	}

	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	public Date getStartDate() {
		// TODO Auto-generated method stub
		return startDate;
	}

	public void setEndDate(Date endDate) {
		// TODO Auto-generated method stub
		this.endDate = endDate;
		
	}

	public void setName(String name) {
		// TODO Auto-generated method stub
		this.name = name;
	}

	public void setStartDate(Date startDate) {
		// TODO Auto-generated method stub
		this.startDate = startDate;
	}

}
