package xpclass;

public class EventViewJemmy extends AbstractJemmyTestCase {

	protected void executeTest() {
		
		// test event 1
		assertEquals(MainForm.EVENT1NAME, getTableCellValue(0,0));
		assertEquals(MainForm.EVENT1START_STR, getTableCellValue(0,1));
		assertEquals(MainForm.EVENT1END_STR, getTableCellValue(0,2));

		// test event 2
		assertEquals(MainForm.EVENT2NAME, getTableCellValue(1,0));
		assertEquals(MainForm.EVENT2START_STR, getTableCellValue(1,1));
		assertEquals(MainForm.EVENT2END_STR, getTableCellValue(1,2));

		// test event 3
		assertEquals(MainForm.EVENT3NAME, getTableCellValue(2,0));
		assertEquals(MainForm.EVENT3START_STR, getTableCellValue(2,1));
		assertEquals(MainForm.EVENT3END_STR, getTableCellValue(2,2));
		
		queueWait();
	}
}
