package xpclass;

import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

import xpclass.ui.AddInput;
import xpclass.ui.MockAddInput;

import junit.framework.TestCase;

public class AddEventControllerTest extends TestCase {

	private MockAddInput mockInput = null;
	private MockValidator mockValidator = null;
	private Schedule scheduler = null;
	private AddEventController addController = null;
	
	public void setUp()
	{
		mockInput = new MockAddInput();
		mockValidator = new MockValidator();
		scheduler = new Schedule();
		addController = new AddEventController(mockInput, mockValidator, scheduler);
	}
	
	public void testActionPerformedValidForm()
	{		
		addController.actionPerformed(null);
		
		assertTrue(mockInput.isShowCalled());
				
	}
	
	public void testAddInvalidEvent()
	{
		int eventCount = scheduler.getAllEvents().size();
		
		mockValidator.validateReturn = false;
		
		addController.addEvent(mockInput);
		
		assertFalse(mockValidator.validate(mockInput));
		assertTrue(mockValidator.validateCalled);
		
		assertEquals(eventCount,scheduler.getAllEvents().size());
		assertFalse(mockInput.hideCalled);
		
	}
	
	public void testAddEventFormValid()
		throws Exception
	{
		mockValidator.validateReturn = true;
		
		mockInput.name = "Who";
		mockInput.startDate="10/17/2005";
		mockInput.startTime="15:15";
		mockInput.endDate="10/17/2005";
		mockInput.endTime="15:15";
		
		addController.addEvent(mockInput);
		
		assertTrue(mockValidator.validateCalled);
		
		Collection events = scheduler.getAllEvents();
		assertEquals(1, events.size());
		Event event = (Event)events.iterator().next();
		
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm");
		
		Date startDate = sdf.parse(mockInput.startDate+" "+mockInput.startTime);
		Date endDate = sdf.parse(mockInput.endDate+" "+mockInput.endTime);
		
		assertEquals("Who", event.getName());
		assertEquals(startDate, event.getStartDate());
		assertEquals(endDate, event.getEndDate());
		
		assertTrue(mockInput.hideCalled);
		
	}
	
}
