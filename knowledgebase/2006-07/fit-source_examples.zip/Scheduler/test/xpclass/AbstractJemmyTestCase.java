package xpclass;

import java.awt.Container;
import java.awt.Point;
import java.io.PrintWriter;
import java.io.Writer;

import javax.swing.*;

import junit.framework.TestCase;

import org.netbeans.jemmy.ClassReference;
import org.netbeans.jemmy.JemmyProperties;
import org.netbeans.jemmy.QueueTool;
import org.netbeans.jemmy.Scenario;
import org.netbeans.jemmy.Test;
import org.netbeans.jemmy.TestOut;
import org.netbeans.jemmy.operators.*;

public abstract class AbstractJemmyTestCase extends TestCase {
    private JFrameOperator mainFrame;

    protected AbstractJemmyTestCase() {
        super("testJemmyScenario");
    }

    public void setUp() throws Exception {
        JemmyProperties.setCurrentOutput(new TestOut(System.in,
                                                     new PrintWriter(newNullWriter()),
                                                     new PrintWriter(System.err)));
        new ClassReference(getMainClassName()).startApplication(getStartupParams());
        queueWait();
        mainFrame = new JFrameOperator();
    }

    public void tearDown() {
        mainFrame.close();
    }

    private Writer newNullWriter() {
        return new Writer() {
            public void close() {}
            public void flush() {}
            public void write(char cbuf[], int off, int len) {}
            public void write(int c) {}
            public void write(char cbuf[]) {}
            public void write(String str) {}
            public void write(String str, int off, int len) {}
        };
    }

    protected String[] getStartupParams() {
        //pass this to the main() so that closing the frame won't kill the VM
        return new String[] { "test" };
    }

    public JFrameOperator getMainFrameOperator() {
        return mainFrame;
    }

    public void testJemmyScenario() {
        Scenario scenario = new Scenario() {
            public int runIt(Object o) {
                executeTest();
                return 0;
            }
        };

        assertEquals(0, new Test(scenario).startTest(null));
    }

    protected abstract void executeTest();

    protected String getMainClassName() {
        return MainForm.class.getName();
    }

    public static void queueWait() {
        queueWait(50); //wait until the AWT Event Queue has been empty for 50 milliseconds
    }

    public static void queueWait(long millis) {
        new QueueTool().waitEmpty(millis);
    }

    public void setTextField(String tooltip, String value) {
    	setTextFieldOperatorText(new JTextFieldOperator(getMainFrameOperator(),
                               new JComponentOperator.JComponentByTipFinder(tooltip)), value);        
    }
    
    public void setTextFieldOperatorText(JTextFieldOperator textField, String value) {
    	textField.enterText(value);
    	queueWait();
    }
    
    public void setLabeledTextField(Container container, String labelText, String value) {
    	JLabel label = findJLabelByText(container, labelText);
    	setTextFieldOperatorText(new JTextFieldOperator((JTextField)label.getLabelFor()), value);
    }

    public String getTextFieldValue(String tooltip) {
        return new JTextFieldOperator(getMainFrameOperator(),
                                      new JComponentOperator.JComponentByTipFinder(tooltip)).getText();
    }

    public void setComboBox(String tooltip, String value) {
        new JComboBoxOperator(getMainFrameOperator(),
                              new JComponentOperator.JComponentByTipFinder(tooltip)).selectItem(value);
        queueWait();
    }

    public String getComboBoxValue(String tooltip) {
        return new JComboBoxOperator(getMainFrameOperator(),
                              new JComponentOperator.JComponentByTipFinder(tooltip)).getSelectedItem().toString();
    }

    public void clickTableRow(int row) {
        new JTableOperator(getMainFrameOperator()).setRowSelectionInterval(row, row);
        queueWait();
    }

    public void clickColumnHeader(int column, int clickCount) {
        JTableHeaderOperator operator = new JTableHeaderOperator(getMainFrameOperator());
        Point columnPoint = operator.getPointToClick(column);
        operator.clickMouse((int)columnPoint.getX(), (int)columnPoint.getY(), clickCount);
        queueWait();
    }

    public Object getTableCellValue(int row, int column) {
        return new JTableOperator(getMainFrameOperator()).getValueAt(row, column);    
    }

    public void pushButton(ContainerOperator container, String buttonText) {
        new JButtonOperator(container, buttonText).pushNoBlock();
        queueWait();
    }
    
    public JLabel findJLabelByText(Container container, String labelText) {
    	return JLabelOperator.findJLabel(container, new JLabelOperator.JLabelByLabelFinder(labelText));
    }

    public JDialogOperator findDialog() {
        JDialog dialog = JDialogOperator.findJDialog(new JDialogOperator.JDialogFinder());
        return dialog != null ? new JDialogOperator(dialog) : null;
    }
}
