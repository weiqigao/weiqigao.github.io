package xpclass;

import org.netbeans.jemmy.operators.JDialogOperator;
import org.netbeans.jemmy.operators.JTableOperator;

import xpclass.ui.AddEventDialog;

import javax.swing.*;

public class EventAddJemmy extends AbstractJemmyTestCase {

	protected void executeTest() {
		// 1. User presses "Add" button.
		pushButton(getMainFrameOperator(), MainForm.ADDBUTTON);

        JDialogOperator addEventDialogOperator = findDialog();
        JDialog addEventDialog = (JDialog)addEventDialogOperator.getSource();

		// 2. User fills in valid values for all text fields.
		final String name = "Midnight Snack";
		setLabeledTextField(addEventDialog, AddEventDialog.NAME_LABEL_TEXT, name);
		setLabeledTextField(addEventDialog, AddEventDialog.START_DATE_LABEL_TEXT, "10/20/2005");
		setLabeledTextField(addEventDialog, AddEventDialog.START_TIME_LABEL_TEXT, "00:00");
		setLabeledTextField(addEventDialog, AddEventDialog.END_DATE_LABEL_TEXT, "10/20/2005");
		setLabeledTextField(addEventDialog, AddEventDialog.END_TIME_LABEL_TEXT, "00:15");

		// 4. User presses "OK" button.
		pushButton(addEventDialogOperator, AddEventDialog.OK_BUTTON_TEXT);
		
		// 4. Verify that event with given name was added.
		JTableOperator op = new JTableOperator(getMainFrameOperator());		
		int numRows = op.getRowCount();
		boolean found = false;
		for(int i=0;i<numRows;i++){
			if (name.equals(getTableCellValue(i,0))) {
				found = true;
				break;
			}
		}
		assertTrue(found);
	}
}
