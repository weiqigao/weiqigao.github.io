package xpclass;

import org.netbeans.jemmy.operators.JDialogOperator;

import xpclass.ui.AddEventDialog;

import javax.swing.*;

public class InvalidEntryJemmy extends AbstractJemmyTestCase {

	protected void executeTest() {
		// 1. User presses "Add" button.
		pushButton(getMainFrameOperator(), MainForm.ADDBUTTON);

        JDialogOperator addEventDialogOperator = findDialog();
        JDialog addEventDialog = (JDialog)addEventDialogOperator.getSource();

		// 2. User types in invalid start date.
		setLabeledTextField(addEventDialog, AddEventDialog.NAME_LABEL_TEXT, "Late Night Snack");
		setLabeledTextField(addEventDialog, AddEventDialog.START_DATE_LABEL_TEXT, "Bogus");
		setLabeledTextField(addEventDialog, AddEventDialog.START_TIME_LABEL_TEXT, "00:00");
		setLabeledTextField(addEventDialog, AddEventDialog.END_DATE_LABEL_TEXT, "10/18/2005");
		setLabeledTextField(addEventDialog, AddEventDialog.END_TIME_LABEL_TEXT, "01:00");
		
		// 3. User presses "OK".
		pushButton(addEventDialogOperator, "OK");
		
		// 4. Verify that error message is displayed.
		JDialogOperator op = new JDialogOperator(addEventDialogOperator, AddEventDialog.ADD_EVENT_ERROR);
		JDialog dlg = (JDialog)op.getSource();
		JLabel errLabel = findJLabelByText(dlg, Validator.START_DATE_ERR);
		assertNotNull(errLabel);
	}
}
