package xpclass;

import org.netbeans.jemmy.operators.JTableOperator;
import org.netbeans.jemmy.operators.JDialogOperator;

import xpclass.ui.AddEventDialog;

import javax.swing.*;

public class EventCancelJemmy extends AbstractJemmyTestCase {

	protected void executeTest() {
		// 1. User presses "Add" button.
		pushButton(getMainFrameOperator(), MainForm.ADDBUTTON);

        JDialogOperator addEventDialogOperator = findDialog();
        JDialog addEventDialog = (JDialog)addEventDialogOperator.getSource();

		// 2. User fills in valid values for all text fields.
		final String name = "Late Night Snack";
		setLabeledTextField(addEventDialog, AddEventDialog.NAME_LABEL_TEXT, name);
		setLabeledTextField(addEventDialog, AddEventDialog.START_DATE_LABEL_TEXT, "10/20/2005");
		setLabeledTextField(addEventDialog, AddEventDialog.START_TIME_LABEL_TEXT, "00:00");
		setLabeledTextField(addEventDialog, AddEventDialog.END_DATE_LABEL_TEXT, "10/20/2005");
		setLabeledTextField(addEventDialog, AddEventDialog.END_TIME_LABEL_TEXT, "00:15");
		
		// 3. User presses "Cancel" button.
		pushButton(addEventDialogOperator, AddEventDialog.CANCEL_BUTTON_TEXT);
		
		// 4. Verify that event with given name was NOT added.
		JTableOperator op = new JTableOperator(getMainFrameOperator());		
		int numRows = op.getRowCount();
		for(int i=0;i<numRows;i++){
			assertNotSame(name,getTableCellValue(i,0));
		}
	}
}
