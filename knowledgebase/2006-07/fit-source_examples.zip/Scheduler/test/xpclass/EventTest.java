package xpclass;

import java.util.Date;

import junit.framework.TestCase;

public class EventTest extends TestCase {

		
	public void testCompareAndEqualsTo()
	{
		long currTime1 = System.currentTimeMillis();
		long currTime2 = System.currentTimeMillis();
		
		EventImpl eventOne = newEvent("Event One", new Date(currTime1), new Date(currTime2));
		Event eventTwo = newEvent("Event One", new Date(currTime1), new Date(currTime2));
		// both events are identical
		assertTrue(eventOne.compareTo(eventTwo) == 0);
		
		long currTime3 = System.currentTimeMillis()+100;
		eventOne.setEndDate(new Date(currTime3));
		// event one lasts longer than event two, hence is considered 
		// as occuring later than event two
		assertTrue(eventOne.compareTo(eventTwo) > 0);
		
		eventOne.setEndDate(new Date(currTime2));
		eventTwo.setStartDate(new Date(currTime1+1000));
		// event two starts later than event one
		assertTrue(eventTwo.compareTo(eventOne) > 0);
		
		eventOne.setEndDate(new Date(currTime2));
		eventTwo.setEndDate(new Date(currTime2));
		eventTwo.setName("Event Two");
		// event two starts later alphabetically
		assertTrue(eventTwo.compareTo(eventOne) > 0);	
			
	}
	
	private EventImpl newEvent(String name, Date startDate, Date endDate)
	{
		EventImpl event = new EventImpl();
		event.setName(name);
		event.setStartDate(startDate);
		event.setEndDate(endDate);
		
		return event;
		
	}
	
	private void compareEvents(Event eventOne, Event eventTwo, int compareOne, boolean equals)
	{
		assertTrue(eventOne.compareTo(eventTwo) > compareOne);
		
		assertTrue(eventTwo.compareTo(eventOne) < compareOne);
		
		assertEquals(equals, eventTwo.equals(eventOne));
	}
}
