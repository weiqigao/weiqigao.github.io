package xpclass;

import xpclass.Validator;
import xpclass.ui.AddInput;

public class MockValidator implements Validator {

	public boolean validateReturn;
	public boolean validateCalled;
	
	public boolean validate(AddInput form) {
		// TODO Auto-generated method stub
		validateCalled = true;
		return validateReturn;
		
	}

}
