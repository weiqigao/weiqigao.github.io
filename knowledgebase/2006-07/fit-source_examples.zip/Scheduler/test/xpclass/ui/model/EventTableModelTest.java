package xpclass.ui.model;

import java.util.Date;

import xpclass.Event;
import xpclass.MockEvent;
import junit.framework.TestCase;

public class EventTableModelTest extends TestCase {

	public EventTableModel createTableModel() {
		Event[] events = new Event[2];
		
		events[0] = new MockEvent();
		events[0].setName("Test1");
		events[0].setStartDate( new Date() );
		events[0].setEndDate( new Date() );
		
		events[1] = new MockEvent();
		events[1].setName("Test2");
		events[1].setStartDate( new Date() );
		events[1].setEndDate( new Date() );
		
		EventTableModel model = new EventTableModel(events);
		
		return model;
	}
	
	/*
	 * Test method for 'xpclass.ui.model.EventTableModel.EventTableModel(Event[])'
	 */
	public void testEventTableModel() {
		EventTableModel model = createTableModel();
	}

	/*
	 * Test method for 'xpclass.ui.model.EventTableModel.getColumnCount()'
	 */
	public void testGetColumnCount() {
		EventTableModel model = createTableModel();

		assertTrue("We should have 3 columns", model.getColumnCount() == 3 );
	}

	/*
	 * Test method for 'xpclass.ui.model.EventTableModel.getRowCount()'
	 */
	public void testGetRowCount() {
		EventTableModel model = createTableModel();

		assertTrue("We should have 2 rows", model.getRowCount() == 2 );
	}

	/*
	 * Test method for 'xpclass.ui.model.EventTableModel.getValueAt(int, int)'
	 */
	public void testGetValueAt() {
		EventTableModel model = createTableModel();

		assertTrue("Cell 0,0 should be name of first row.", model.getValueAt(0,0).equals("Test1"));
		assertTrue("Cell 0,1 should be name of first row.", model.getValueAt(1,0).equals("Test2"));
	}

}
