package xpclass.ui;

import xpclass.Controller;


public class MockAddInput implements AddInput {

	public String name = null;
	public String startDate = null;
	public String startTime = null;
	public String endDate = null;
	public String endTime = null;
	
	public boolean showCalled;
	public boolean hideCalled;
	
	
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	public String getStartDate() {
		// TODO Auto-generated method stub
		return startDate;
	}

	public String getStartTime() {
		// TODO Auto-generated method stub
		return startTime;
	}

	public String getEndDate() {
		// TODO Auto-generated method stub
		return endDate;
	}

	public String getEndTime() {
		// TODO Auto-generated method stub
		return endTime;
	}

	public void handleNameError(String msg) {
		// TODO Auto-generated method stub

	}

	public boolean handleStartDateErrorCalled;
	public void handleStartDateError(String msg) {
		handleStartDateErrorCalled = true;
	}

	public boolean handleStartTimeErrorCalled;
	public String handleStartTimeErrorMsg;
	public void handleStartTimeError(String msg) {
		handleStartTimeErrorCalled = true;
		handleStartTimeErrorMsg = msg;
	}

	public boolean handleEndDateErrorCalled;
	public String handleEndDateErrorMsg;	
	public void handleEndDateError(String msg) {
		handleEndDateErrorCalled = true;
		handleEndDateErrorMsg = msg;
	}

	public boolean handleEndTimeErrorCalled;
	public String handleEndTimeErrorMsg;
	public void handleEndTimeError(String msg) {
		handleEndTimeErrorCalled = true;
		handleEndTimeErrorMsg = msg;
	}

	public void display() {
		// TODO Auto-generated method stub
		setShowCalled(true);
	}

	public boolean isShowCalled() {
		return showCalled;
	}

	public void setShowCalled(boolean showCalled) {
		this.showCalled = showCalled;
	}

	public void destroy()
	{
		hideCalled = true;		
	}
	
	public boolean setControllerCalled;
	public Controller setControllerController;	
	public void setController(Controller ctrl) {
		setControllerCalled = true;
		setControllerController = ctrl;
	}
}
