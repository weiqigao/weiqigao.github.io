
public class ParseDelegate implements Parser {
    private final Parser parser;

    public ParseDelegate(Parser parser) {
        this.parser = parser;
    }

    public Object parse(String value) throws Exception {
        return parser.parse(value);
    }
}
