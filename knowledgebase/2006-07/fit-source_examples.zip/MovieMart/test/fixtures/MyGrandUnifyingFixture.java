
import fit.ColumnFixture;
import fit.RowFixture;
import fitlibrary.SetUpFixture;

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class MyGrandUnifyingFixture extends fitlibrary.DoFixture {
    private ApplicationUnderTest app = new ApplicationUnderTest();
    private Customer activeCustomer;
    private List<Movie> selectedMovies;

    public MyGrandUnifyingFixture() {
        setSystemUnderTest(app);
        registerParseDelegates();
    }

    private void registerParseDelegates() {
        final Parser customerDelegate = new Parser() {
            public Object parse(String customerName) throws CustomerNotFoundException
            {
                return app.getCustomerByName(customerName);
            }
        };
        registerParseDelegate(Customer.class, new ParseDelegate(customerDelegate));

        final Parser movieDelegate = new Parser() {
            public Object parse(String movieTitle) throws TitleNotFoundException
            {
                return app.getMovieByTitle(movieTitle);
            }
        };
        registerParseDelegate(Movie.class, new ParseDelegate(movieDelegate));

        final Parser releaseCategoryDelegate = new Parser() {
            public Object parse(String category) throws Exception
            {
                return category.equals("new release") ? ReleaseCategory.NewRelease :
                        ReleaseCategory.NonNewRelease;
            }
        };
        registerParseDelegate(ReleaseCategory.class, new ParseDelegate(releaseCategoryDelegate));

        final Parser moneyDelegate = new Parser() {
            public Object parse(String value) throws Exception
            {
                return new Money(value);
            }
        };
        registerParseDelegate(Money.class, new ParseDelegate(moneyDelegate));
    }

    public SetUpFixture movieSetups() {
        return new AddMovies(app);
    }

    public SetUpFixture customerSetups() {
        return new AddCustomers(app);
    }

    public void selectCustomer(Customer customer) {
        activeCustomer = customer;
    }

    public void selectMovies(Movie[] movies) {
        selectedMovies = new ArrayList<Movie>(Arrays.asList(movies));
    }

    public boolean completeCheckout() {
        try {
            app.checkOutTitles(selectedMovies, activeCustomer);
        } catch (InvalidRentalException ire) {
            return false;
        }
        return true;
    }

    public RowFixture customerRentalList(Customer customer) {
        return new ViewActiveRentals(app, customer);
    }

    public ColumnFixture lateFeeCalculator() {
        return new LateRentalFeeCalculator();
    }

    public void removeFromCheckout(Movie movie) {
        selectedMovies.remove(movie);
    }

    public Money amountDue() {
        return app.amountDueForCheckout(selectedMovies, activeCustomer);
    }

    public void returnMovies(Movie[] movies) {
        app.returnTitles(Arrays.asList(movies), activeCustomer);
    }
}