
public class LateRentalFeeCalculator extends fit.ColumnFixture {
    public ReleaseCategory releaseCategory;
    public int numberOfDaysLate;

    public Money feeAmount() {
        return LateFeeCalculator.calculateLateFee(releaseCategory, numberOfDaysLate);
    }

    @Override public Object parse(String value, Class aClass) throws Exception
    {
        if (ReleaseCategory.class.isAssignableFrom(aClass)) {
            return value.equals("new release") ? ReleaseCategory.NewRelease :
                ReleaseCategory.NonNewRelease;
        } else if (Money.class.isAssignableFrom(aClass)) {
            return new Money(value);
        }
        return super.parse(value, aClass);
    }
}
