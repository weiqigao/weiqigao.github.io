
public interface Parser {
    Object parse(String value) throws Exception;
}
