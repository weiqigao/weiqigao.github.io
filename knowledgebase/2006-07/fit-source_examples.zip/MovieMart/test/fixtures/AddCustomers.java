
import fitlibrary.SetUpFixture;

public class AddCustomers extends SetUpFixture {

    public AddCustomers(Object sut) {
        super(sut);
    }

    public void customerIdName(int customerId, String name) {
        ((ApplicationUnderTest)systemUnderTest).addCustomer(new Customer(name, customerId));
    }
}
