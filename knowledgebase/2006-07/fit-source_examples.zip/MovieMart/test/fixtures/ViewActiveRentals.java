
import java.util.List;

public class ViewActiveRentals extends fit.RowFixture {
    private final ApplicationUnderTest app;
    private final Customer selectedCustomer;

    public ViewActiveRentals(ApplicationUnderTest app, Customer customer) {
        this.app = app;
        this.selectedCustomer = customer;
    }

    public Object[] query() throws Exception {
        final List<Movie> rentedTitlesByCustomer = app.getRentedTitlesByCustomer(selectedCustomer);
        RentalDetail[] details = new RentalDetail[rentedTitlesByCustomer.size()];
        int index = 0;
        for(Movie movie : rentedTitlesByCustomer) {
            final RentalDetail rentalDetail = new RentalDetail();
            rentalDetail.checkedOutMovie = movie;
            rentalDetail.dueBack = movie.getReleaseCategory().getRentalDurationDays() + " days";
            details[index++] = rentalDetail;
        }
        return details;
    }

    public Class getTargetClass() {
        return RentalDetail.class;
    }

    @Override public Object parse(String value, Class aClass) throws Exception {
        if (Movie.class.isAssignableFrom(aClass)) {
            return app.getMovieByTitle(value);
        } else if (Customer.class.isAssignableFrom(aClass)) {
            return app.getCustomerByName(value);
        }
        return super.parse(value, aClass);
    }

    public static class RentalDetail {
        public Movie checkedOutMovie;
        public String dueBack;
    }
}
