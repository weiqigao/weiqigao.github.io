public class AddMovies extends fitlibrary.SetUpFixture {

    public AddMovies(Object systemUnderTest) {
        super(systemUnderTest);
    }

    public void titleReleaseCategoryQuantity(String title, ReleaseCategory category, int quantity) {
        for (int i = 0; i < quantity; i++) {
            ((ApplicationUnderTest)systemUnderTest).addMovie(new Movie(title, category));
        }
    }
}
