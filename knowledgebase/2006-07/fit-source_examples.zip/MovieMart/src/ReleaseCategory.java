public enum ReleaseCategory {
    NewRelease(3, new Money("$3.99")),
    NonNewRelease(5, new Money("$2.99"));

    private final int rentalDurationDays;
    private final Money rentalDurationRate;

    ReleaseCategory(int rentalDurationDays, Money money) {
        this.rentalDurationDays = rentalDurationDays;
        this.rentalDurationRate = money;
    }

    public int getRentalDurationDays() {
        return rentalDurationDays;
    }
    
    public Money getRentalDurationRate() {
		return rentalDurationRate;
	}
}
