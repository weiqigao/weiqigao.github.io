
import java.util.*;

public class ApplicationUnderTest {
    //All titles left in the store
	private final Map<Movie, Integer> movieVault = new HashMap<Movie, Integer>();
    private final List<Customer> customers = new ArrayList<Customer>();
    //All titles currently out to a customer
    private final Map<Customer, List<Movie>> activeRentals = new HashMap<Customer, List<Movie>>();
    //Count of total rentals by customer
    private final Map<Customer, Integer> rentalCounter = new HashMap<Customer, Integer>();

    public void addMovie(Movie movie) {
        Integer count = movieVault.get(movie);
        movieVault.put(movie,  count != null ? ++count : 1);
    }

    public void addCustomer(Customer customer) {
        customers.add(customer);
    }

    public Set<Movie> getAvailableTitles() {
        return movieVault.keySet();
    }

    public int getAvailableCopiesOfTitle(Movie movie) {
        final Integer copiesAvailable = movieVault.get(movie);
        return copiesAvailable == null ? 0 : copiesAvailable;
    }

    public Movie getMovieByTitle(String title) throws TitleNotFoundException {
        final Set<Movie> movies = getAvailableTitles();
        for(Movie movie : movies) {
            if (movie.getTitle().equals(title)) {
                return movie;
            }
        }
        throw new TitleNotFoundException(title + " is not available");
    }

    public Customer getCustomerByName(String customerName) throws CustomerNotFoundException {
        for(Customer customer : customers) {
            if (customer.getName().equals(customerName)) {
                return customer;
            }
        }
        throw new CustomerNotFoundException(customerName + " was not found");
    }

    public void checkOutTitles(List<Movie> titles, Customer customer) throws InvalidRentalException {
        final int newReleaseCustomerRentals = getNewReleaseCountForCustomer(customer);

        int newReleasesOnCounter = 0;
        for(Movie movie : titles) {
            newReleasesOnCounter += isNewRelease(movie) ? 1 : 0;

            final int pendingNewReleaseCount = newReleasesOnCounter + newReleaseCustomerRentals;

            if (pendingNewReleaseCount > 3) {
                throw new InvalidRentalException("No more than 3 new releases out at a time");
            }
        }

        for(Movie movie : titles) {
            checkOutTitle(movie,  customer);
        }
    }

    private void checkOutTitle(Movie movie, Customer customer) {
        int countLeftInStore = movieVault.get(movie);

        List<Movie> movies = activeRentals.get(customer);
        if (movies == null) {
            movies = new ArrayList<Movie>();
            activeRentals.put(customer, movies);
        }
        movies.add(movie);
        movieVault.put(movie, --countLeftInStore);
        incrementRentalCount(customer);
    }

    private void incrementRentalCount(Customer customer)
    {
        rentalCounter.put(customer, getCustomerRentalCount(customer) + 1);
    }

    private int getCustomerRentalCount(Customer customer) {
        final Integer counter = rentalCounter.get(customer);
        return counter == null ? 0 : counter;
    }

    private int getNewReleaseCountForCustomer(Customer customer) {
        int newReleaseCount = 0;
        final List<Movie> rentedTitlesByCustomer = getRentedTitlesByCustomer(customer);
        if (rentedTitlesByCustomer != null) {
            for(Movie movie : rentedTitlesByCustomer) {
                newReleaseCount += isNewRelease(movie) ? 1 : 0;
            }
        }
        return newReleaseCount;
    }

    private boolean isNewRelease(Movie movie)
    {
        return movie.getReleaseCategory() == ReleaseCategory.NewRelease;
    }

    public List<Movie> getRentedTitlesByCustomer(Customer customer) {
        return activeRentals.get(customer);
    }

    public Money amountDueForCheckout(List<Movie> movies, Customer customer) {
        Money amountDue = new Money("$0.00");
        for(Movie movie : movies) {
            amountDue = amountDue.add(movie.getReleaseCategory().getRentalDurationRate());
        }
        return amountDue.subtract(discountRentalAmount(movies, customer));
    }

    private Money discountRentalAmount(List<Movie> movies, Customer customer)
    {
        Money rentalDiscount = new Money("$0.00");
        if (isEligibleForFreeRental(movies, customer)) {
            for(Movie movie : movies) {
                final Money rentalDurationRate = movie.getReleaseCategory().getRentalDurationRate();
                rentalDiscount = rentalDurationRate.isGreaterThan(rentalDiscount) ? rentalDurationRate : rentalDiscount;
            }
        }
        return rentalDiscount;
    }

    private boolean isEligibleForFreeRental(List<Movie> movies, Customer customer)
    {
        for(int i = 1; i < movies.size(); i++) {
            if ((getCustomerRentalCount(customer) + i) % 8 == 0) {
                return true;
            }
        }
        return false;
    }

    public void returnTitles(List<Movie> movies, Customer customer) {
        for(Movie movie : movies) {
            returnTitle(movie, customer);
        }
    }

    private void returnTitle(Movie movie, Customer customer) {
        int countLeftInStore = movieVault.get(movie);

        List<Movie> movies = activeRentals.get(customer);
        movies.remove(movie);
        movieVault.put(movie, ++countLeftInStore);
    }
}
