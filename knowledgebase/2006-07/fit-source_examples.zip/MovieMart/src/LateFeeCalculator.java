
public class LateFeeCalculator {
	private LateFeeCalculator() {}
	
	public static Money calculateLateFee(ReleaseCategory category, int numberOfDaysLate) {
		final int rentalDurationDays = category.getRentalDurationDays();
		final Money rentalDurationRate = category.getRentalDurationRate();
		return rentalDurationRate.divide(rentalDurationDays).multiply(numberOfDaysLate);
	}
}
