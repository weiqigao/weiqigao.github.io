public class Movie {
    private final String title;
    private ReleaseCategory releaseCategory;

    public Movie(String title, ReleaseCategory releaseCategory)
    {
        this.title = title;
        this.releaseCategory = releaseCategory;
    }

    public String getTitle()
    {
        return title;
    }

    public ReleaseCategory getReleaseCategory()
    {
        return releaseCategory;
    }

    public void setReleaseCategory(ReleaseCategory releaseCategory)
    {
        this.releaseCategory = releaseCategory;
    }

    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (!(o instanceof Movie)) return false;

        final Movie movie = (Movie) o;

        if (releaseCategory != null ? !releaseCategory.equals(movie.releaseCategory) : movie.releaseCategory != null) return false;
        if (title != null ? !title.equals(movie.title) : movie.title != null) return false;

        return true;
    }

    public int hashCode()
    {
        int result;
        result = (title != null ? title.hashCode() : 0);
        result = 29 * result + (releaseCategory != null ? releaseCategory.hashCode() : 0);
        return result;
    }

    @Override public String toString()
    {
        return title;
    }
}
