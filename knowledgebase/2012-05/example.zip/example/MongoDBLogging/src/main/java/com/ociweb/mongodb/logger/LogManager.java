package com.ociweb.mongodb.logger;

import java.net.UnknownHostException;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MapReduceCommand;
import com.mongodb.MapReduceCommand.OutputType;
import com.mongodb.MapReduceOutput;
import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.mongodb.WriteConcern;

public class LogManager {

    private static Logger logger = Logger.getLogger(LogManager.class.getName());

    private final String dbName = "loggingDB";
    private final String collectionName = "log";
    private final long cappedSize = 10000000; //in bytes
    private final String host = "127.0.0.1:27017";
    private DBCollection collection;
    
    public LogManager(boolean dropLog, WriteConcern writeConcern) {
        try{
            Mongo mongo = new Mongo(host);
            
            DB db = mongo.getDB(dbName);
            
            if (dropLog) {
                db.getCollection(collectionName).drop();//similar to drop table
            }
            
            if (db.collectionExists(collectionName)) {
                collection = db.getCollection(collectionName);
            } else {
                collection = buildCollection(db);
            }
            collection.setWriteConcern(writeConcern);//Safe should be used for testing.
        
        } catch (UnknownHostException e) {
            logger.log(Level.SEVERE, "Unable to start Mongo", e);
        } catch (MongoException e) {
            logger.log(Level.SEVERE, "Unable to start Mongo", e);
        }
    }
    
    public void addLogHandler() {
    	
        MongoDBHandler mongoDBHandler = new MongoDBHandler(collection);
        Logger.getLogger("").addHandler(mongoDBHandler);
        logger.info("added MongoDBHandler to root Logger");
        
    }

    public void removeAllHandlers() {
        Handler[] handlers = Logger.getLogger("").getHandlers();
        int h = handlers.length;
        while (--h>=0) {
            Logger.getLogger("").removeHandler(handlers[h]);
        }
    }
    
    private DBCollection buildCollection(DB db) {
        
        DBObject capped = new BasicDBObject("capped", true)
        .append("size", cappedSize);
        
        DBCollection collection = db.createCollection(collectionName, capped);
        
        //example of adding an index to a collection
        collection.ensureIndex(new BasicDBObject(DocumentKeys.LOG_MILLISECONDS,1));
        
        return collection;
    }
    
    public DBCollection getLogCollection() {
        return collection;
    }
    
    public DBObject findLastDocument(int skipLast) {
        DBObject query = new BasicDBObject();
        DBCursor cursor = collection.find(query).
        		                     sort(new BasicDBObject("$natural",-1)).
        		                     skip(skipLast);
        DBObject lastOne;
        if (cursor.hasNext()) {
            lastOne = cursor.next();
        } else {
            lastOne = new BasicDBObject();//empty document in unlikely case log is empty
        }
        cursor.close();
        return lastOne;
    }
    
    public DBObject buildQueryForNewDocuments(int includeLastDocs) {
        DBObject lastOne = findLastDocument(includeLastDocs);
        
        //{ "_id" : { "$gt" : { "$oid" : "4f9db27344ae6160ba4a36da"}}}
        DBObject testQuery = new BasicDBObject(DocumentKeys.MONGODB_DOC_ID,
                                               new BasicDBObject("$gt",lastOne.get(DocumentKeys.MONGODB_DOC_ID)));
        return testQuery;
    }

    public DBCursor findMostFrequentProblems(DBObject query) {
        
        //the emit key must be a simple object not a list or even contain a list.
        String mapJS = "function() {if(this.thro) {" +
                                   "     var cause = this.thro; " +
                                   "     while (cause.cause) {" +
                                   "       cause = cause.cause;" +
                                   "     } " +
                                   "     emit({cause:{summary:cause.stack[0].sum," +
                                   "                  class:cause.class," +
                                   "                  line:cause.stack[0].line}}," +
                                   "          1);" +
                                   "}}";
        String reduceJS = "function(k,vals) {return Array.sum(vals);}";
        
        MapReduceCommand mrc = new MapReduceCommand(collection, mapJS, reduceJS, "log.todo", OutputType.REPLACE, query);
        
        MapReduceOutput mro = collection.mapReduce(mrc);
        DBCollection outputCollection = mro.getOutputCollection();
        
        BasicDBObject sortBy = new BasicDBObject("value",-1);//value descending
        DBCursor todoCursor = outputCollection.find().sort(sortBy);
        return todoCursor;
    }

    //NOTE: this only works for a fixed one cause deep
    //this could be fixed by passing in the depth and adding the right number of cause. fragments
    public DBObject findExampleByLineNumber(Integer lineNumber) {
        
        String key = DocumentKeys.LOG_THROWN+"."+DocumentKeys.THROWN_CAUSE+"."+DocumentKeys.THROWN_STACK+"."+DocumentKeys.STACK_ELEMENT_LINE_NUMBER;
        //  { "thro.cause.stack.line" : 205}   an example of query by example
        BasicDBObject byExampleQuery = new BasicDBObject(key  ,lineNumber);
        return collection.findOne(byExampleQuery);
        
    }
    
}
