package com.ociweb.mongodb.logger;

import java.util.logging.Level;

import com.mongodb.BasicDBObject;
import static com.ociweb.mongodb.logger.DocumentKeys.*;

public class MongoLogDocument extends BasicDBObject {
    
    public String getMessage() {
        return getString(LOG_MESSAGE);
    }
    
    public Level getLevel() {
        return Level.parse(getString(LOG_LEVEL));
    }
    
    public MongoThrownDocument getThrown() {
        return (MongoThrownDocument)get(LOG_THROWN);
    }
        
    public String toString() {
        StringBuilder builder = new StringBuilder();
        
        builder.append(getLevel()).append(": ");
        builder.append(getMessage());
        
        if (containsField(LOG_THROWN)) {
            builder.append(" Cause: ").append(getThrown().toString());
        }
    
        if (containsField(LOG_PARAMETERS)) {
        	builder.append(" Params: ").append(get(LOG_PARAMETERS));
        }
        
        return builder.toString();
    }

}
