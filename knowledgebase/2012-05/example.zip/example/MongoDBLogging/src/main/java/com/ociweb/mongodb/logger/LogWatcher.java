package com.ociweb.mongodb.logger;

import com.mongodb.Bytes;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.WriteConcern;

public class LogWatcher {

    LogManager logManager;
    
    public LogWatcher() {
        logManager = new LogManager(false, WriteConcern.NONE);//read only, never drop
    }
    
    /**
     * @param args
     */
    public static void main(String[] args) {
        new LogWatcher().watch();
    }

    private void watch() {
        
        DBCollection logCollection = logManager.getLogCollection();
        
        //create this object instead of BasicDBObject
        logCollection.setObjectClass(MongoLogDocument.class);
        logCollection.setInternalClass(DocumentKeys.LOG_THROWN, MongoThrownDocument.class);
        
        DBObject newDocsQuery = logManager.buildQueryForNewDocuments(5);
        //must include at least one
        DBCursor cursor = logManager.getLogCollection().find(newDocsQuery);
        cursor.addOption(Bytes.QUERYOPTION_TAILABLE);
        cursor.addOption(Bytes.QUERYOPTION_AWAITDATA);
        cursor.addOption(Bytes.QUERYOPTION_NOTIMEOUT);
        
        //this will break out if the initial query does not contain any results, collection is dropped or
        //if the server goes down and it needs to fail over to the next when using replica sets.
        while (cursor.hasNext()) {
            DBObject obj = cursor.next();//this ONLY works for capped collections, and/or opLog
            System.out.println(obj);
        }
        
    }

}
