package com.ociweb.mongodb.logger;

public interface DocumentKeys {
    
    String MONGODB_DOC_ID           = "_id";
    String LOG_LEVEL                = "lvl";
    String LOG_MESSAGE              = "msg";
    String LOG_MILLISECONDS         = "time";
    String LOG_SEQUENCE_NUMBER      = "seq";
    String LOG_SOURCE_CLASS         = "clas";
    String LOG_SOURCE_METHOD        = "meth";
    String LOG_THREAD_ID            = "thrd";
    String LOG_RESOURCE_BUNDLE_NAME = "bndl";
    String LOG_THROWN               = "thro"; //for thrown exception document
    String LOG_PARAMETERS           = "parm"; //list of params
    
    //may or may not have a thrown exception
    String THROWN_CLASS            = "class";
    String THROWN_MESSAGE          = "msg"; 
    String THROWN_CAUSE            = "cause"; //another thrown exception document
    String THROWN_STACK            = "stack"; //list of stack elements
    
    //multiple stack trace element rows per single exception
    String STACK_ELEMENT_SUMMARY             = "sum";
    String STACK_ELEMENT_CLASS_NAME          = "class";
    String STACK_ELEMENT_FILE_NAME           = "file";
    String STACK_ELEMENT_LINE_NUMBER         = "line";
    String STACK_ELEMENT_METHOD              = "meth";
    
}
