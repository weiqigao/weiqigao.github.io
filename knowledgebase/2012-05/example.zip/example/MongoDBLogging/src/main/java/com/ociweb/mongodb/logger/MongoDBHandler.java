package com.ociweb.mongodb.logger;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import static com.ociweb.mongodb.logger.DocumentKeys.*;

/**
 * 
 * simple logging handler.
 * 
 * @author Nathan Tippy
 * 
 */
public class MongoDBHandler extends Handler {
    

    DBCollection loggingCollection;
    
        
    public MongoDBHandler(DBCollection loggingCollection) {
        this.loggingCollection = loggingCollection;
    }

    @Override
    public void close() throws SecurityException {
    }

    @Override
    public void flush() {
        loggingCollection.getDB().getLastError();
    }

    @Override
    public void publish(LogRecord record) {
                
        DBObject obj = new BasicDBObject();//this is a JSON object
        obj.put(LOG_LEVEL,                      record.getLevel().toString());
        obj.put(LOG_MESSAGE,                    record.getMessage());
        obj.put(LOG_MILLISECONDS,               record.getMillis());
        obj.put(LOG_SEQUENCE_NUMBER,            record.getSequenceNumber());
        obj.put(LOG_SOURCE_CLASS,               record.getSourceClassName());
        obj.put(LOG_SOURCE_METHOD,              record.getSourceMethodName());
        obj.put(LOG_THREAD_ID,                  record.getThreadID());
        if (record.getResourceBundleName()!=null) {
            obj.put(LOG_RESOURCE_BUNDLE_NAME,       record.getResourceBundleName());
        }
        
        //will auto convert to BSON/JSON of simple types Long,Int,Double,Date,String and DBObject        
        if (record.getParameters()!=null) {
            BasicDBList parametersList = new BasicDBList();
            for(Object parm : record.getParameters()) {
                parametersList.add(parm);
            }
            obj.put(LOG_PARAMETERS, parametersList);
        }
        
        
        Throwable t = record.getThrown();
        if (t!=null) {
            DBObject thrownObject = convertThrowableToDBObject(t);
            obj.put(LOG_THROWN,thrownObject);
        }
        try {
        	//write this new document to the collection
            loggingCollection.insert(obj);
        } catch (IllegalArgumentException iae) {
        	Logger logger = Logger.getLogger(MongoDBHandler.class.getName());
            logger.log(Level.SEVERE,"Unable to write log entry containing unsupported object type.",iae);
            //wiped out parameters and re-sent this to the logger
            record.setParameters(new Object[]{"Unknown"});
            publish(record);
        }
        
    }

    public DBObject convertThrowableToDBObject(Throwable t) {
        DBObject thrownObject = new BasicDBObject();
        thrownObject.put(THROWN_CLASS, t.getClass().getName());
        thrownObject.put(THROWN_MESSAGE,t.getMessage());

        //could have been BasicDBList
        List<DBObject> stackTrace = new ArrayList<DBObject>(); 
        for(StackTraceElement ste: t.getStackTrace()) {
            //array of easy to use object?
            
            DBObject element = new BasicDBObject();
            element.put(STACK_ELEMENT_SUMMARY,    ste.toString());
            element.put(STACK_ELEMENT_CLASS_NAME, ste.getClassName());
            element.put(STACK_ELEMENT_FILE_NAME,  ste.getFileName());
            element.put(STACK_ELEMENT_LINE_NUMBER,ste.getLineNumber());
            element.put(STACK_ELEMENT_METHOD,     ste.getMethodName());
            stackTrace.add(element);
        }
        thrownObject.put(THROWN_STACK,stackTrace);

        //for each cause we need to create another document within this one.
        Throwable cause = t.getCause();
        if (cause!=null) {
            DBObject dbObjectCause =  convertThrowableToDBObject(cause);
            thrownObject.put(THROWN_CAUSE,dbObjectCause);
        }
        
        return thrownObject;
    }
  

}
