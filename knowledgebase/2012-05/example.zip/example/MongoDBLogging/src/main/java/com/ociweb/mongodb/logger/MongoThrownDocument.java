package com.ociweb.mongodb.logger;

import static com.ociweb.mongodb.logger.DocumentKeys.*;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class MongoThrownDocument extends BasicDBObject {

    //this is the top of all things thrown.
    
    public String getMessage() {
        return getString(THROWN_MESSAGE);
    }
    
    public String getClassName() {
        return getString(THROWN_CLASS);
    }
    
    public String getCauseLine() {
        
        DBObject cause = this;
        while (cause.containsField(THROWN_CAUSE)) {
            cause =  (DBObject) cause.get(THROWN_CAUSE);
        }
        
        BasicDBList list = (BasicDBList)cause.get(THROWN_STACK);
        DBObject topRow = (DBObject) list.get(0);
        return topRow.get(STACK_ELEMENT_SUMMARY).toString();
    }
    
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(" ").append(getClassName());
        builder.append(" \"").append(getMessage()).append("\"");
        builder.append(" At: ").append(getCauseLine());
        return builder.toString();
    }
    
    public Throwable rebuild() {
        
        return null;
        
        
    }
    
}
