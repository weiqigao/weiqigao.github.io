package com.ociweb.mongodb.logger;

import static org.junit.Assert.*;

import java.util.Collections;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.BeforeClass;
import org.junit.Test;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.GroupCommand;
import com.mongodb.MapReduceCommand;
import com.mongodb.MapReduceCommand.OutputType;
import com.mongodb.MapReduceOutput;
import com.mongodb.WriteConcern;
//before running test startup a mongod server first with
//  ./mongod --dbpath ~/data

public class LogTester {

    static LogManager manager;
    static Logger logger;
    
    
    @BeforeClass
    public static void initLogger() {
        //do not drop old collection and use safe write concern.
        manager = new LogManager(false,WriteConcern.SAFE);
        manager.removeAllHandlers();
        manager.addLogHandler();
        logger = Logger.getLogger(LogTester.class.getName());
        
        //test with caution the logger uses a capped collection so some data will be dropped with use.
    }

    @Test
    public void logEventsTest() {
        
    	//because we are using a capped collection we want build a query for finding
    	//only the new documents that have been inserted
        DBObject testQuery = manager.buildQueryForNewDocuments(0);
        
        //add our event to the log
        String myMessage = "ejected the warp core!";
        logger.info(myMessage);
        
        //count of all new documents added since we started this test
        DBCollection logCollection = manager.getLogCollection();
        long count = logCollection.find(testQuery).count();
        assertEquals(1,count);
        
        //confirm message from last event matches
        DBObject testResult = manager.findLastDocument(0);
        String messageFromDB = (String)testResult.get(DocumentKeys.LOG_MESSAGE);
        assertEquals(myMessage,messageFromDB);
        
        notUglyPrint(testResult);
    }
    
    @Test
    public void unloggableTest() {
    	logger.log(Level.INFO, "failure", this);
    	notUglyPrint(manager.findLastDocument(1));
    	notUglyPrint(manager.findLastDocument(0));
    }
    

    @Test
    public void logExceptionTest() {
        
        DBObject testQuery = manager.buildQueryForNewDocuments(0);

        int thrownCount = badCodeThrowing();

        DBCollection logCollection = manager.getLogCollection();
        assertEquals(thrownCount,logCollection.find(testQuery).count());
        
        //findOne is a nice helper method when you do not want to deal with the cursor
        notUglyPrint(logCollection.findOne(testQuery));
        
       }
    
    @Test
    public void mapReduceTest() {
        
        DBObject testQuery = manager.buildQueryForNewDocuments(0);
        
        badCodeThrowing();
        
        DBObject query = testQuery;
        
        DBCursor todoCursor = manager.findMostFrequentProblems(query);
        
        assertEquals(3,todoCursor.count());
        
        //display list of problems in order of occurrence
        boolean isFirst = true;
        Number lineNumber = null;
        for(DBObject doc: todoCursor) {
            if (isFirst) {
                assertEquals(198,((Number)doc.get("value")).intValue());
                lineNumber = (Number)((DBObject)((DBObject)doc.get("_id")).get("cause")).get("line");
                isFirst=false;
            }
            notUglyPrint(doc);
        }
        
        //display a typical example of the most frequent problem
        System.out.println();
        DBObject exampleDoc = manager.findExampleByLineNumber(lineNumber.intValue());
        assertNotNull(exampleDoc);
        notUglyPrint(exampleDoc);
        
    }

    @Test
    public void groupTest() {
        
        DBObject testQuery = manager.buildQueryForNewDocuments(0);
        
        badCodeThrowing();
        
        DBObject query = testQuery;
        
        String reduceJS = "function(doc, out) {out.value++;}";

        DBCollection logCollection = manager.getLogCollection();
        GroupCommand gc = new GroupCommand(logCollection, new BasicDBObject(DocumentKeys.LOG_THROWN,1),query,new BasicDBObject("value",0),reduceJS, null );
        DBObject results = logCollection.group(gc);
        
        //group results are always returned and never kept in a new table
        //to sort after doing group MongoDB recommends doing this work client side.
        
        TreeMap<Number,DBObject> map = new TreeMap<Number,DBObject>();
        for(String key: results.keySet()) {
            DBObject doc = (DBObject)results.get(key);
            Number   value = (Number)doc.get("value");
            DBObject thrown = (DBObject)doc.get("thro");
            map.put(value,thrown);
            System.out.println("Count:"+value+" Thrown:"+thrown.toString());
        }
        
        Entry<Number, DBObject> lastEntry = map.lastEntry();
        System.out.println("Start with:"+lastEntry.getKey()+':'+lastEntry.getValue());
        assertEquals(198,lastEntry.getKey().intValue());
    }
    
    @Test
    public void queryDeepGeoTest() {
        
        //add our event to the log
        String myMessage = "found a Klingon.";
        
        //makes a simple diagonal line
        int c = 100;
        while (--c>=0) { 
            BasicDBList position = new BasicDBList();
            position.add(c);//x
            position.add(c);//y
            //  { "ICBM" : [ 42 , 42]}
            logger.log(Level.INFO, myMessage, new BasicDBObject("ICBM",position));
        }
        
        DBCollection logCollection = manager.getLogCollection();
        //add 2d index to the collection    { "parm.ICBM" : "2d"} 
        //this is a sparse index not all documents hold this key
        logCollection.ensureIndex(new BasicDBObject(DocumentKeys.LOG_PARAMETERS+".ICBM","2d"));
        
        //near query
        BasicDBList list = new BasicDBList();
        list.add(56.5);
        list.add(50);
        // { "parm.ICBM" : { "$near" : [ 56.5 , 50]}}
        DBObject nearQuery = new BasicDBObject(DocumentKeys.LOG_PARAMETERS+".ICBM",new BasicDBObject("$near",list));
                
        DBObject result = logCollection.findOne(nearQuery);
        BasicDBList expectedICBM = new BasicDBList();
        expectedICBM.add(53);
        expectedICBM.add(53);
        assertEquals(new BasicDBObject("ICBM",expectedICBM),((BasicDBList)result.get("parm")).get(0));
        notUglyPrint( result);
        
    }

    /**
     * Bad code throwing a bunch of exceptions and logging them.
     * 
     * @return total number of throws
     */
    public int badCodeThrowing() {
        int throwCount = 0;
        int loop = 100;
        while (--loop>0) {
            int[] data = {0, 0, 1, 2, 3, 5};
            int badLength = data.length+1;
            
            int c = badLength;
            while (--c>=0) {
                try{
                    int tempValue = 100/data[c];
                    int value = tempValue/(loop%10);
                } catch (Throwable t) {
                    throwCount++;
                    //just to make it hard to find the real cause
                    Throwable wrapped = new Throwable(t);
                    logger.log(Level.SEVERE, "unable to compute value", wrapped);
                }
            }
        }
        return throwCount;
    }
    
    public void notUglyPrint(DBObject dbObject) {
        //this is nice JSON however it has no line breaks and so it is hard to read
        String json = dbObject.toString();
        
        String tab = "  ";
        String indent = "";
        
        int i = 0;
        while (i<json.length()) {
            char ch = json.charAt(i++);
            switch (ch) {
                case ',':
                    System.out.println(ch);//new line
                    System.out.print(indent);
                    break;
                case '{':
                case '[':
                    System.out.print(ch);//new line
                    indent += tab;
                    //System.out.print(indent);
                    break;
                case '}':
                case ']':
                    System.out.print(ch);//new line
                    indent = indent.substring(0, indent.length()-tab.length());
                   // System.out.print(indent);
                    break;
                default:
                    System.out.print(ch);
            }
        }
        System.out.println();
    }
    
}
