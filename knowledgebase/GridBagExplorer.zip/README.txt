GridBagExplorer
README.txt

Written by Eric Burke
burke_e@ociweb.com

Overview
--------
GridBagLayout is the most powerful (and complex) layout 
manager included with Java.  GridBagExplorer is a programmer's
tool which is designed to simplify GridBagLayout.  This
tool can be used to experiment with and learn about 
GridBagLayout, as well as to generate source code which
can be embedded into any Java applet or application.

Requirements
------------
GridBagExplorer requires either JDK 1.2 or JDK 1.1.x with
Swing 1.1 installed.  This latest release was developed
using IBM's JDK 1.1.8 on Red Hat Linux 6.1.  It has also
been tested on numerous other platforms.

Java 2 Instructions
-------------------
- double click on GridBagExplorer.jar
- or type "java -jar GridBagExplorer.jar"

JDK 1.1.x Instructions
----------------------
1.  Include GridBagExplorer.jar in your CLASSPATH
2.  If you are using JDK 1.1.x, also include swingall.jar in 
    your CLASSPATH.
3.  Type: "java com.showmejava.gridbag.GridBagExplorer"


Once GridBagExplorer is running, you have to add new
components.  This is accomplished by typing in a component
name then clicking the "Add" button.  From there, you
select the component you want to modify in the list.
All fields in the GridBagConstraints for that component
can then be modified.

Selecting "Window...Preview" brings up the preview window.
This displays what your layout looks like, and is updated
whenever you modify one of the constraints.

Selecting "Window...Code" brings up the code window.
You must click "Generate" to manually update the code
after you make changes to the layout.


Revision History
----------------
2.0.4a - 24 March 2000
- Fixed instructions in this README.txt file

2.0.4 - 21 November 1999
- Renamed package to com.showmejava.gridbag
- Rebuilt using IBM's JDK 1.1.8 on Red Hat Linux 6.1

2.0.3 - 06 January 1999
- Added menu which allows the user to switch to a new L&F at runtime
- Made the generated code more efficient with insets.
  // old way:
  gbc.insets = new Insets(0,0,0,0);

  // new way:
  gbc.insets.top = 0;
  gbc.insets.bottom = 0;

- Fix a bug where the manifest file was referring to "gridbag" instead
  of "gridbag2".  This was preventing the executable JAR from
  working properly.
- Added the ability to save the generated source code to a file.  This
  is needed on platforms where "Copy to Clipboard" doesn't work because
  of bugs in various JDKs.

2.0.2 - 03 January 1999
- change package name from "com.ociweb.gridbag" to "com.ociweb.gridbag2".  
  This was done to avoid name conflicts with version 1 of GridBagExplorer,
  which was using the same package name.
- modify a few files to ensure that everything is compatible with
  JDK 1.1.x and Swing1.1, in addition to JDK 1.2.
- fix a bug where the version number was not correct in the comment
  at the top of generated code.
  

2.0.1
- add text to the component name text field so the user knows where
  to begin typing
- Slightly improved performance when typing in the component
  name field
- Add the ability to display a grid over the preview window
- Add the ability to specify the preferred size of each component
- Packaged the JAR file so it can be double-clicked on Windows
  systems to execute.
- Fixed bugs:
  BUG1 - constraints editor panel was not updating properly when 
         components were removed, or after a File..New
  BUG2 - after opening a file, the preview window was not updating
  BUG3 - file..open was not working for other directories

2.0
- Complete rewrite using JDK1.2 and Swing
- Add ability to load and save files
- Add ability to rename existing components
- Add shortcut buttons for RELATIVE and REMAINDER
- Add ability to control indentation of generated code
- Add ability to specify name of component that constraints
  are added to
- Fixed minor bugs in code generation when gridx, gridy 
  were set to RELATIVE or REMAINDER
- Eliminated the "update" button.  The display now automatically
  updates whenever a value is modified.
- Simplified the procedure for adding new components by removing
  the "add" dialog box.

1.0
- The original version of GridBagExplorer
- uses JDK 1.1, AWT
- lacks file open/save

License Agreement
-----------------
//////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2000, Eric M. Burke (ericb@showmejava.com)
// All rights reserved.
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions are met:
//
// - Redistributions of source code must retain the above copyright notice,
//   this list of conditions and the following disclaimer.
// 
// - Redistributions in binary form must reproduce the above copyright notice,
//   this list of conditions and the following disclaimer in the documentation
//   and/or other materials provided with the distribution.
// 
// - Neither name of the ShowMeJava.com nor the names of its contributors may 
//   be used to endorse or promote products derived from this software without
//   specific prior written permission. 
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
// TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE. 
/////////////////////////////////////////////////////////////////////////////


