/*
 * Sample code from a user group talk:
 * Direct Manipulation with Swing
 * 
 * Copyright 2005 Kyle Cordes
 * http://kylecordes.com
 * http://oasisdigital.com
 *
 * Feel free to mine this for ideas and snippets for your own projects.
 */
package swingtalk.hierarchy;

import java.awt.Color;
import java.awt.Component;
import java.awt.Point;

import javax.swing.BorderFactory;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

public class Ghost {

	private final JPanel ghostPanel = new JPanel();
	
	private final JLayeredPane layeredPane;

	private int grabXOffset, grabYOffset;

	public Ghost(JLayeredPane layeredPane) {
		this.layeredPane = layeredPane;
		ghostPanel.setOpaque(true);
		ghostPanel.setBackground(new Color(255, 255, 0, 80));
		ghostPanel.setBorder(BorderFactory.createRaisedBevelBorder());
	}

	public void show(Point mousePoint, Component toClone) {
		ghostPanel.setSize(toClone.getSize());
		layeredPane.add(ghostPanel, JLayeredPane.DRAG_LAYER);
		
		Point location = locationRelativeTo(toClone, layeredPane);
		ghostPanel.setLocation(location);

		grabXOffset = mousePoint.x - location.x;
		grabYOffset = mousePoint.y - location.y;
	}

	private static Point locationRelativeTo(Component target, Component reference) {
		Point loc = target.getLocationOnScreen();
		Point ref = reference.getLocationOnScreen();
		loc.translate(0 - ref.x, 0 - ref.y);
		return loc;
	}

	public void positionMouseLocation(Point upperLeftPoint) {
		upperLeftPoint.translate(-grabXOffset, -grabYOffset);
		ghostPanel.setLocation(upperLeftPoint);
	}

	public void hide() {
		layeredPane.remove(ghostPanel);
	}

}
