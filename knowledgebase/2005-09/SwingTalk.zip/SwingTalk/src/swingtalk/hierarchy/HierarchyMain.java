/*
 * Sample code from a user group talk:
 * Direct Manipulation with Swing
 * 
 * Copyright 2005 Kyle Cordes
 * http://kylecordes.com
 * http://oasisdigital.com
 *
 * Feel free to mine this for ideas and snippets for your own projects.
 */
package swingtalk.hierarchy;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;

import swingtalk.randomdata.RandomData;

public class HierarchyMain implements ActionListener {

	private JFrame frame = new JFrame("Organizational Hierarchy Demo");

	private JPanel panel = new JPanel();

	private HierarchyWidget hierWidget = new HierarchyWidget();

	private JLabel topLabel = new JLabel(	"Drag and drop the organizational hierachy");
	
	private JButton saveButton = new JButton("Save");

	private List<Unit> units = new ArrayList<Unit>();

	public HierarchyMain() {
		panel.setLayout(new BorderLayout());
		topLabel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
		panel.add(topLabel, BorderLayout.NORTH);
		panel.add(hierWidget.getComponent(), BorderLayout.CENTER);
		panel.add(saveButton, BorderLayout.SOUTH);
		saveButton.addActionListener(this);
	}

	private void createAndShowGUI() {
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		panel.setOpaque(true);
		frame.setContentPane(panel);
		frame.pack();
		frame.setVisible(true);

		// A real app may get the Units from a DB
		populateRandomSampleData();
	}

	private void populateRandomSampleData() {
		Random r = new Random();
		for (int i = 0; i < 55; i++) {
			Unit parent = null;
			if (!units.isEmpty()) {
				int range = Math.min(units.size(), 10);
				parent = units.get(r.nextInt(range));
			}
			Unit wo = new Unit(RandomData.makeName(), parent);
			units.add(wo);
		}

		hierWidget.load(units.get(0));
	}

	public static void main(String[] args) throws Exception {
		UIManager.setLookAndFeel("com.jgoodies.looks.plastic.PlasticXPLookAndFeel");

		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new HierarchyMain().createAndShowGUI();
			}
		});
	}

	public void actionPerformed(ActionEvent e) {
		// Gets called when user clicks Save
		// This could write back a DB, for example
		for (Unit unit : units) {
			if (unit.getInitialParent() != unit.getParent()) {
				System.out.println("" + unit + " changed parent from "
						+ unit.getInitialParent() + " to " + unit.getParent());
			}
		}
	}

}
