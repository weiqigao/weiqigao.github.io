/*
 * Sample code from a user group talk:
 * Direct Manipulation with Swing
 * 
 * Copyright 2005 Kyle Cordes
 * http://kylecordes.com
 * http://oasisdigital.com
 *
 * Feel free to mine this for ideas and snippets for your own projects.
 */
package swingtalk.hierarchy;

import java.util.ArrayList;
import java.util.List;

public class Unit {

	private String name;
	
	private List<Unit> kids = new ArrayList<Unit>();
	
	private Unit parent;
	
	private Unit initialParent;

	public Unit(String name, Unit parent) {
		this.name = name;
		this.initialParent = parent;
		if(parent!=null) {
			parent.addChild(this);
		}
	}

	public List<Unit> getKids() {
		return kids;
	}

	public String getName() {
		return name;
	}

	public Unit getParent() {
		return parent;
	}
	
	public Unit getInitialParent() {
		return initialParent;
	}

	public void removeChild(Unit unit) {
		kids.remove(unit);
		unit.parent = null;
	}

	public void addChild(Unit child) {
		kids.add(child);
		child.parent = this;
	}
	
	@Override
	public String toString() {
		return "[" + name + "]";
	}
	
}
