/*
 * Sample code from a user group talk:
 * Direct Manipulation with Swing
 * 
 * Copyright 2005 Kyle Cordes
 * http://kylecordes.com
 * http://oasisdigital.com
 *
 * Feel free to mine this for ideas and snippets for your own projects.
 */
package swingtalk.hierarchy;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JLayeredPane;

public class HierarchyWidget implements MouseListener, MouseMotionListener {

	private JLayeredPane layeredPane = new JLayeredPane();

	private UnitPanel dragging;

	private UnitPanel root;
	
	private Ghost ghost = new Ghost(layeredPane);

	public HierarchyWidget() {
		layeredPane.addMouseListener(this);
		layeredPane.addMouseMotionListener(this);
		layeredPane.setPreferredSize(new Dimension(800, 600));
		layeredPane.addComponentListener(new ComponentAdapter() {
			public void componentResized(ComponentEvent e) {
				resized();
			}
		});
	}

	private void resized() {
		// This is a "poor man's layout manager" for the JLayeredPane
		if (root != null) {
			root.setSize(layeredPane.getSize());
			root.validate();
		}
	}

	public Component getComponent() {
		return layeredPane;
	}

	public void load(Unit unit) {
		root = new UnitPanel(unit);
		root.populateChildPanels();
		layeredPane.removeAll();
		layeredPane.add(root, JLayeredPane.DEFAULT_LAYER);
		resized();
	}

	// ************** Event Handlers *****************
	
	public void mouseClicked(MouseEvent e) {
		if (e.getClickCount() == 2) {
			// double clicked, could go to a detail screen.
		}
	}

	public void mousePressed(MouseEvent e) {
		Component c = layeredPane.findComponentAt(e.getPoint());
		if (c != root && c instanceof UnitPanel) {
			dragging = (UnitPanel) c;
			dragging.highlight();
			ghost.show(e.getPoint(), dragging);
		}
	}

	public void mouseReleased(MouseEvent e) {
		if (dragging != null) {
			ghost.hide();
			dragging.unHighlight();
			layeredPane.validate();
			layeredPane.repaint();
		}
		dragging = null;
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mouseMoved(MouseEvent e) {
	}

	public void mouseDragged(MouseEvent e) {
		if (dragging == null)
			return;

		ghost.positionMouseLocation(e.getPoint());

		Component dragTarget = root.findComponentAt(e.getPoint());

		if (containsComponent(dragging, dragTarget))
			dragTarget = dragging.getParent();

		if (dragTarget instanceof UnitPanel)
			reParentUnder(dragTarget);
	}

	//	**********************************************
	
	private void reParentUnder(Component dragTarget) {
		UnitPanel targetPanel = (UnitPanel) dragTarget;
		Unit draggingUnit = dragging.getUnit();

		Unit currentParentUnit = draggingUnit.getParent();
		Unit newParentUnit = targetPanel.getUnit();

		if (currentParentUnit != newParentUnit) {
			dragging.removeFromParent();
			currentParentUnit.removeChild(draggingUnit);

			targetPanel.addChild(dragging);
			newParentUnit.addChild(draggingUnit);
			
			dragging.invalidate();
			layeredPane.validate();
		}
	}

	public static boolean containsComponent(Container container,
			Component target) {
		if (container == target)
			return true;

		for (Component c : container.getComponents()) {
			if (c == target)
				return true;
		}

		// Recurse in to subcontainers:
		for (Component c : container.getComponents()) {
			if (c instanceof Container) {
				if (containsComponent((Container) c, target))
					return true;
			}
		}

		return false;
	}

}
