/*
 * Sample code from a user group talk:
 * Direct Manipulation with Swing
 * 
 * Copyright 2005 Kyle Cordes
 * http://kylecordes.com
 * http://oasisdigital.com
 *
 * Feel free to mine this for ideas and snippets for your own projects.
 */
package swingtalk.hierarchy;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

public class UnitPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	private final Unit unit;
	
	private final GridLayout gridLayout = new GridLayout(0, 1);

	public UnitPanel(Unit unit) {
		this.unit = unit;
		setLayout(gridLayout);
		setName(unit.getName());
		unHighlight();
	}

	public void highlight() {
		setBorder(BorderFactory.createTitledBorder(BorderFactory
				.createLineBorder(Color.YELLOW, 3), unit.getName()));
		repaint();
	}

	public void unHighlight() {
		setBorder(BorderFactory.createTitledBorder(BorderFactory
				.createEtchedBorder(), unit.getName()));
		repaint();
	}

	public void removeFromParent() {
		UnitPanel parent = (UnitPanel) getParent();
		if (parent != null) {
			parent.remove(this);
			parent.adjustGrid();
		}
	}

	public void addChild(UnitPanel child) {
		add(child);
		adjustGrid();
	}

	private void adjustGrid() {
		int nKids = getComponentCount();
		int columns = (int) Math.ceil(Math.sqrt(nKids));
		if(columns==0) 
			columns = 1;
		gridLayout.setColumns(columns);
		invalidate();
	}

	public Unit getUnit() {
		return unit;
	}

	public void populateChildPanels() {
		for (Unit child : unit.getKids()) {
			UnitPanel childPanel = new UnitPanel(child);
			addChild(childPanel);
			childPanel.populateChildPanels();
		}
	}

}
