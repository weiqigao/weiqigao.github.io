These library jars are from JGoodies:

http://www.jgoodies.com/

which I recommend heartily.

Only "looks" is actually used here, and only for the PlasticXP
look&feel which makes the demo apps look better.

-Kyle Cordes
