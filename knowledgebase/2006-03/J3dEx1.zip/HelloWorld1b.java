import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.Font3D;
import javax.media.j3d.FontExtrusion;
import javax.media.j3d.GraphicsConfigTemplate3D;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Text3D;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.vecmath.Point3f;

import com.sun.j3d.utils.universe.SimpleUniverse;

public class HelloWorld1b extends JPanel {
	private SimpleUniverse u = null;
	
	public HelloWorld1b() throws IOException {
		setLayout(new BorderLayout());
		
	  Canvas3D canvas = createCanvas();
	  add("Center", canvas);
	  
	  u = new SimpleUniverse(canvas);
	  
	  BranchGroup bg = createContent();
	  bg.compile();
	  
	  u.addBranchGraph(bg);
	  
	  /*
	   * 
	   * The ViewPlatform is moved back along Z so that objects at 
	   * the origin spanning the normalized X range of -1.0 to +1.0 
	   * can be fully viewed across the width of the window. This is 
	   * done by setting a translation of 1/(tan(fieldOfView/2)) in the 
	   * ViewPlatform transform.
	   */
	  u.getViewingPlatform().setNominalViewingTransform();
	  
	}
	
	
  private Canvas3D createCanvas() {
		GraphicsConfigTemplate3D graphicsTemplate = new GraphicsConfigTemplate3D();
		
		GraphicsConfiguration gc1 = GraphicsEnvironment.getLocalGraphicsEnvironment()
		    .getDefaultScreenDevice().getBestConfiguration(graphicsTemplate);
		
		return new Canvas3D(gc1);
  }

  
  private BranchGroup createContent() throws IOException  {
    BranchGroup bg = new BranchGroup();
    bg.addChild(getHelloWorldText());

  		return bg;
  }
  
  private Shape3D getHelloWorldText() {
    Font font = new Font("Arial", Font.PLAIN, 1);
    FontExtrusion extrusion = new FontExtrusion();
    
    Font3D font3d = new Font3D(font, extrusion);
    Text3D helloWorldGeometry = new Text3D(font3d, "Hello World", new Point3f(0.0f,0.0f,0.0f),
    		Text3D.ALIGN_CENTER, Text3D.PATH_RIGHT);

    Shape3D helloWorldShape = new Shape3D(helloWorldGeometry, new Appearance());
    
    return helloWorldShape;
  }

  public static void main(String[] args) throws Exception {
  		HelloWorld1b hello = new HelloWorld1b();
  		
  		JFrame frame = new JFrame("Hello World");
  		frame.setSize(1024,768);
  		
  		frame.getContentPane().add(hello);
  		frame.setVisible(true);
  		
  		frame.addWindowListener(new WindowAdapter() {
				public void windowClosing(WindowEvent arg0) {
					System.exit(0);
				}
  			
  		});
  }
}
