import java.awt.BorderLayout;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.media.j3d.Alpha;
import javax.media.j3d.AmbientLight;
import javax.media.j3d.Background;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.Bounds;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.GraphicsConfigTemplate3D;
import javax.media.j3d.Group;
import javax.media.j3d.PointLight;
import javax.media.j3d.PositionInterpolator;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3d;

import com.mnstarfire.loaders3d.Loader3DS;
import com.sun.j3d.loaders.Scene;
import com.sun.j3d.utils.universe.SimpleUniverse;

public class Load3ds2 extends JPanel {
	private SimpleUniverse u = null;
	
	public Load3ds2() throws IOException {
		setLayout(new BorderLayout());
		
	  Canvas3D canvas = createCanvas();
	  add("Center", canvas);
	  
	  u = new SimpleUniverse(canvas);
	  
	  BranchGroup bg = createContent();
	  bg.compile();
	  
	  u.addBranchGraph(bg);
	  u.getViewingPlatform().setNominalViewingTransform();
	}
	
	
  private Canvas3D createCanvas() {
		GraphicsConfigTemplate3D graphicsTemplate = new GraphicsConfigTemplate3D();
		
		GraphicsConfiguration gc1 = GraphicsEnvironment.getLocalGraphicsEnvironment()
		    .getDefaultScreenDevice().getBestConfiguration(graphicsTemplate);
		
		return new Canvas3D(gc1);
  }

  
  private BranchGroup createContent() throws IOException  {
    BranchGroup bg = new BranchGroup();
    bg.addChild(createWorld());

    addLights(bg);
    addBackground(bg);
  	return bg;
  }
  
  protected void addBackground(BranchGroup bg) {
  	
  	// Add a nice blue background to add some color
  	Background back = new Background(new Color3f(0.0f, 0.3f, 0.9f));
  	back.setApplicationBounds(new BoundingSphere(new Point3d(0,0,0), 150.0));
  	  	
  	bg.addChild(back);
  }
  
  protected void addLights(BranchGroup bg) {
  	Bounds infBounds = new BoundingSphere(new Point3d(0,0,0), 100.0);
  	
  	PointLight blueLight = new PointLight(true, new Color3f(0.9f,0.9f,0.9f),
  			new Point3f(-3.0f, 1.0f, -4.0f), new Point3f(0.5f, 0.0f,0.0f));
  	blueLight.setInfluencingBounds(infBounds);
    bg.addChild(blueLight);

  	PointLight redLight = new PointLight(true, new Color3f(0.9f,0.9f,0.9f),
  			new Point3f(3.0f, 1.0f, -4.0f), new Point3f(0.5f, 0.0f,0.0f));
  		redLight.setInfluencingBounds(infBounds);
    bg.addChild(redLight);

    
    AmbientLight l1 = new AmbientLight(new Color3f(0.9f, 0.9f, 0.9f));
    l1.setInfluencingBounds(infBounds);
    l1.setEnable(true);
 
    bg.addChild(l1);
  }

  
  private TransformGroup createWorld() {
    TransformGroup spinningGroup = createMovingGroup();
    spinningGroup.addChild(loadModel());
    
    TransformGroup relocatedGroup = new TransformGroup();
		Transform3D transform = new Transform3D();
		transform.set(new Vector3d(0,0,-5));
		transform.setScale(0.4d);
		
		relocatedGroup.setTransform(transform);
    
    relocatedGroup.addChild(spinningGroup);
  		return relocatedGroup;
  }

  private TransformGroup createMovingGroup() {
		TransformGroup tg = new TransformGroup();
		tg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		
		Transform3D zAxis = new Transform3D();
		zAxis.rotY(-Math.PI / 2.0f);
		
    Alpha positionAlpha = new Alpha(-1, 4000);
    positionAlpha.setIncreasingAlphaRampDuration(1000);
    BoundingSphere bounds = new BoundingSphere(new Point3d(0, 0, 0), 150.0);
    
    
    // Let's try a new one, a position interpolator for moving our car along 
    // We will move it from 3 to -15 over the 4 second period
    PositionInterpolator mover =
      new PositionInterpolator(positionAlpha, tg, zAxis,
      			3.0f, -150.0f );
   
    mover.setSchedulingBounds(bounds);
    tg.addChild(mover);

    
		return tg;
}

  private Group loadModel() {
		Loader3DS loader = new Loader3DS(Loader3DS.LOAD_ALL);
		Group g = null;
		try {
			Scene scene = loader.load("./55porsmx.3ds");
			g = scene.getSceneGroup();
		} catch (FileNotFoundException e) {
			// I hate checked exceptions
			System.out.println("Unable to load the car");
			throw new RuntimeException("Unable to load the car");
		}
		
  return g;
}

 

  public static void main(String[] args) throws Exception {
  		Load3ds2 hello = new Load3ds2();
  		
  		JFrame frame = new JFrame("Hello World");
  		frame.setSize(1024,768);
  		
  		frame.getContentPane().add(hello);
  		frame.setVisible(true);
  		
   		frame.addWindowListener(new WindowAdapter() {
				public void windowClosing(WindowEvent arg0) {
					System.exit(0);
				}
  			
  		});
  }
}
