import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import javax.media.j3d.Alpha;
import javax.media.j3d.Appearance;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.ColoringAttributes;
import javax.media.j3d.Font3D;
import javax.media.j3d.FontExtrusion;
import javax.media.j3d.GraphicsConfigTemplate3D;
import javax.media.j3d.RotationInterpolator;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Text3D;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3d;

import com.sun.j3d.utils.universe.SimpleUniverse;

public class HelloWorld4a extends JPanel {
	private SimpleUniverse u = null;
	
	public HelloWorld4a() throws IOException {
		setLayout(new BorderLayout());
		
	  Canvas3D canvas = createCanvas();
	  add("Center", canvas);
	  
	  u = new SimpleUniverse(canvas);
	  
	  BranchGroup bg = createContent();
	  bg.compile();
	  
	  u.addBranchGraph(bg);
	  u.getViewingPlatform().setNominalViewingTransform();
	}
	
	
  private Canvas3D createCanvas() {
		GraphicsConfigTemplate3D graphicsTemplate = new GraphicsConfigTemplate3D();
		
		GraphicsConfiguration gc1 = GraphicsEnvironment.getLocalGraphicsEnvironment()
		    .getDefaultScreenDevice().getBestConfiguration(graphicsTemplate);
		
		return new Canvas3D(gc1);
  }

  
  private BranchGroup createContent() throws IOException  {
    BranchGroup bg = new BranchGroup();
    bg.addChild(createSpinningHelloWorld());

 		return bg;
  }
  
  private TransformGroup createSpinningHelloWorld() {
    TransformGroup spinningGroup = createSpinningGroup();
    spinningGroup.addChild(getHelloWorldText());
    
    TransformGroup relocatedGroup = new TransformGroup();
		Transform3D transform = new Transform3D();
		transform.set(new Vector3d(0,0,-5));
		relocatedGroup.setTransform(transform);
    
    relocatedGroup.addChild(spinningGroup);
  		return relocatedGroup;
  }

  private TransformGroup createSpinningGroup() {
		TransformGroup tg = new TransformGroup();
		tg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		
		Transform3D yAxis = new Transform3D();
		
    Alpha rotationAlpha = new Alpha(-1, 8000);
    BoundingSphere bounds = new BoundingSphere(new Point3d(0, 0, 0), 5.0);
    RotationInterpolator rotator =
      new RotationInterpolator(rotationAlpha, tg, yAxis,
                             0.0f, (float) Math.PI * 2.0f);
   
    rotator.setSchedulingBounds(bounds);
    tg.addChild(rotator);

		return tg;
}

  private Shape3D getHelloWorldText() {
    Font font = new Font("Arial", Font.PLAIN, 1);
    FontExtrusion extrusion = new FontExtrusion();
    
    Font3D font3d = new Font3D(font, extrusion);
    Text3D helloWorldGeometry = new Text3D(font3d, "Hello World", new Point3f(0.0f,0.0f,0.0f),
    		Text3D.ALIGN_CENTER, Text3D.PATH_RIGHT);

    Appearance app = createAppearance();
    Shape3D helloWorldShape = new Shape3D(helloWorldGeometry, app);
    
    return helloWorldShape;
  }
  
  /* Let's gussy up the appearance a little bit.  We will add some coloring attributes
   * and set it to green.
   * 
   */
  
  private Appearance createAppearance() {
  		Appearance app = new Appearance();
  		ColoringAttributes ca = new ColoringAttributes(
  				new Color3f(0.0f, 0.7f, 0.0f), ColoringAttributes.SHADE_GOURAUD);
  		
  		app.setColoringAttributes(ca);
  		
   		return app;
  	
  }

  public static void main(String[] args) throws Exception {
  		HelloWorld4a hello = new HelloWorld4a();
  		
  		JFrame frame = new JFrame("Hello World");
  		frame.setSize(1024,768);
  		
  		frame.getContentPane().add(hello);
  		frame.setVisible(true);
  		
   		frame.addWindowListener(new WindowAdapter() {
				public void windowClosing(WindowEvent arg0) {
					System.exit(0);
				}
  			
  		});
  }
}
