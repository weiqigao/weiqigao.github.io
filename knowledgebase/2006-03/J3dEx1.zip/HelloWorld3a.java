import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import javax.media.j3d.Alpha;
import javax.media.j3d.AmbientLight;
import javax.media.j3d.Appearance;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.Font3D;
import javax.media.j3d.FontExtrusion;
import javax.media.j3d.GraphicsConfigTemplate3D;
import javax.media.j3d.RotationInterpolator;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Text3D;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Point3f;
import javax.vecmath.Vector3d;

import com.sun.j3d.utils.universe.SimpleUniverse;

public class HelloWorld3a extends JPanel {
	private SimpleUniverse u = null;
	
	public HelloWorld3a() throws IOException {
		setLayout(new BorderLayout());
		
	  Canvas3D canvas = createCanvas();
	  add("Center", canvas);
	  
	  u = new SimpleUniverse(canvas);
	  
	  BranchGroup bg = createContent();
	  bg.compile();
	  
	  u.addBranchGraph(bg);
	  u.getViewingPlatform().setNominalViewingTransform();
	}
	
	
  private Canvas3D createCanvas() {
		GraphicsConfigTemplate3D graphicsTemplate = new GraphicsConfigTemplate3D();
		
		GraphicsConfiguration gc1 = GraphicsEnvironment.getLocalGraphicsEnvironment()
		    .getDefaultScreenDevice().getBestConfiguration(graphicsTemplate);
		
		return new Canvas3D(gc1);
  }

  
  private BranchGroup createContent() throws IOException  {
    BranchGroup bg = new BranchGroup();
    bg.addChild(createSpinningHelloWorld());

    addLights(bg);
  		return bg;
  }
  
  protected void addLights(BranchGroup bg) {
    AmbientLight l1 = new AmbientLight(new Color3f(0.9f, 0.9f, 0.9f));
    l1.setInfluencingBounds(new BoundingSphere(new Point3d(0,0,0), 100.0));
    l1.setEnable(true);
    
    bg.addChild(l1);
  }

  
  private TransformGroup createSpinningHelloWorld() {
    TransformGroup spinningGroup = createSpinningGroup();
    spinningGroup.addChild(getHelloWorldText());
    
    TransformGroup relocatedGroup = new TransformGroup();
		Transform3D transform = new Transform3D();
		transform.set(new Vector3d(0,0,-5));
		relocatedGroup.setTransform(transform);
    
    relocatedGroup.addChild(spinningGroup);
  		return relocatedGroup;
  }
  
  /* Create a TransforGroup, that has a RotationalInterpolator.
   * This is used to rotate the contents of the group.
   * 
   * I wonder if we will run into any problems?
   */

  private TransformGroup createSpinningGroup() {
		TransformGroup tg = new TransformGroup();
		
		/*
		 * Create a Tranform3D object, with the default constructor is
		 * the identity transformation, which means keep it the same.
		 */
		Transform3D yAxis = new Transform3D();
		
		/*
		 * Create an Alpha object.  This object will generate numbers in between
		 * 0 and 1 over 8000msec.  The -1 indicates the number of times it should do
		 * this is infinite.
		 */
    Alpha rotationAlpha = new Alpha(-1, 8000);
    
    /*
     * The bounds over which the tranformation should occur.  We create a bounding
     * sphere with relative location of 0,0,0 and a radius of 5.
     * 
     */
    BoundingSphere bounds = new BoundingSphere(new Point3d(0, 0, 0), 5.0);
    
    /*
     * RotationInterpolator rotates along the local y axis.  In between a minimum and maximum angle.
     * We tell it to rotate all the way around in radians.
     * 
     */
    RotationInterpolator rotator =
      new RotationInterpolator(rotationAlpha, tg, yAxis,
                             0.0f, (float) Math.PI * 2.0f);
   
    rotator.setSchedulingBounds(bounds);
    tg.addChild(rotator);

		return tg;
}

  private Shape3D getHelloWorldText() {
    Font font = new Font("Arial", Font.PLAIN, 1);
    FontExtrusion extrusion = new FontExtrusion();
    
    Font3D font3d = new Font3D(font, extrusion);
    Text3D helloWorldGeometry = new Text3D(font3d, "Hello World", new Point3f(0.0f,0.0f,0.0f),
    		Text3D.ALIGN_CENTER, Text3D.PATH_RIGHT);

    Shape3D helloWorldShape = new Shape3D(helloWorldGeometry, new Appearance());
    
    return helloWorldShape;
  	
  }

  public static void main(String[] args) throws Exception {
  		HelloWorld3a hello = new HelloWorld3a();
  		
  		JFrame frame = new JFrame("Hello World");
  		frame.setSize(1024,768);
  		
  		frame.getContentPane().add(hello);
  		frame.setVisible(true);
  		
   		frame.addWindowListener(new WindowAdapter() {
				public void windowClosing(WindowEvent arg0) {
					System.exit(0);
				}
  			
  		});
  }
}
