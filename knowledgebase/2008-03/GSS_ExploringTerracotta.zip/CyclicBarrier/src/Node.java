import java.util.concurrent.*;

public class Node {

  public static void main(String[] args) throws Exception {
    int parties = Integer.parseInt(args[0]);
    Node node = new Node(parties);
    node.run();
  }

  private final CyclicBarrier barrier;

  public Node(int parties) {
    barrier = new CyclicBarrier(parties);
  }
  
  public void run() throws Exception {
    System.out.println("Waiting for other node to join...");
    int joined = barrier.await();
    System.out.println("Started: " + joined);
    
    barrier.await();
    System.out.println("Ended: " + joined);
  }

}