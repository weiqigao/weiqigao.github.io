public class Counter {
	// Create single static Main instance
	public static Counter instance = new Counter();

	// Main - just count the instance
	public static void main(String[] args) throws InterruptedException {
		for (int i = 0; i < 100; i++) {
			instance.count();
			Thread.sleep(1000);
		}
	}

	// Main state - a simple counter
	private int counter = 0;

	// Synchronize access to make Main thread-safe
	public synchronized void count() {
		counter++;
		System.out.println("Counter is: " + counter);
	}
}