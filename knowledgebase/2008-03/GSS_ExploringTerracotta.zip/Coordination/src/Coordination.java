import java.io.*;
import java.util.concurrent.atomic.*;

public class Coordination {
  public static final Coordination instance = new Coordination();
  
  public static void main(String[] args) throws Exception {
    instance.run();
  }
  
  
  public AtomicInteger     counter  = new AtomicInteger(0);
  public String            msg;

  public void run() throws Exception {
    int node = counter.getAndIncrement() % 2;

    switch (node) {
      case 0:   // These nodes will receive messages and report
        System.out.println("Waiting for input...");
        while (true) {
          printInput();
        }
      case 1:   // These nodes will send messages 
        while (true) {
          getInput();
        }
    }
  }

  private synchronized void getInput() throws IOException {
    System.out.print("Enter a message> ");
    System.out.flush();
    msg = new BufferedReader(new InputStreamReader(System.in)).readLine();
    notify();
  }

  private synchronized void printInput() throws InterruptedException {
    while (msg == null) {
      wait();
    }
    System.out.println(msg);
    msg = null;
  }


}