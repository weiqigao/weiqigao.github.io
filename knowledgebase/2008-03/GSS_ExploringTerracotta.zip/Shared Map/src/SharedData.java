import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class SharedData {

  private final Map<String, Date> data = new HashMap<String, Date>();

  public synchronized void addName(String name) {
    data.put(name, new Date());
  }

  public synchronized void removeName(String name) {
    data.remove(name);
  }

  public synchronized Date getJoined(String name) {
    return data.get(name);
  }

  public synchronized Set<String> getNames() {
    return data.keySet();
  }
}
