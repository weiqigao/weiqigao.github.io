import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

  public static void main(String arg[]) throws IOException {
    new Main().run();
  }
  
  private final SharedData data = new SharedData();

  public void run() throws IOException {
    while(true) {
      String[] command = readCommand();
      if(command[0].equals("add")) {
        data.addName(command[1]);
        
      } else if(command[0].equals("remove")) {
        data.removeName(command[1]);
        
      } else if(command[0].equals("list")) {
        for(String name : data.getNames()) {
          System.out.println("  " + name + " : " + data.getJoined(name));
        }
        
      } else if(command[0].equals("quit")) {
        return;
      }
    }
  }
  
  private String[] readCommand() throws IOException {
    System.out.print("Command> ");
    System.out.flush();
    String line = new BufferedReader(new InputStreamReader(System.in)).readLine();
    return line.split(" ");
  }
}
