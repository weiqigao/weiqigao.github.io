package net.bosatsu.foo;

public class OtherMessage {
    public static String getValue() {
       return "Stuart Halloway is my hero too!";
    }
}
