{
    "items" : [
        {   type : 		"Zepheira Team",
            label : 		" Eric Miller",
            Name : 		" Eric Miller",
            FN : 		"Eric",
            LN : 		"Miller",
            Email : 		"em@zepheira.com",
            Title : 		"President",
            Location : 		"Columbus, Ohio",
            Skill:	  	[ "Project Management", "Semantic Web", "Social Engineering", "Business Development" ],
	    Service:		[ "Education", "Analysis", "Mentoring", "Modeling", "Software Design" ],	
	    Domain:		[ "Enterprise", "Government", "Financial Services", "Energy", "Health Care", "Life Sciences", "Library Sciences" ],
            ImageURL : 		"../images/team/eric_thumb.jpg",
            MoreURL : 		"http://zepheira.com/team/eric/",
	    Briefbio: 		"Eric Miller is the President of Zepheira.  Prior to founding Zepheira, Eric led the Semantic Web Initiative for the World Wide Web Consortium (W3C) at MIT where he led the architectural and technical leadership in the design and evolution of the Semantic Web.  Eric is a frequent and sought after international speaker in areas of International Web standards, knowledge management, collaboration, development and deployment. (<a href='http://zepheira.com/team/eric'>more</a>)"
        }
    ]
}
