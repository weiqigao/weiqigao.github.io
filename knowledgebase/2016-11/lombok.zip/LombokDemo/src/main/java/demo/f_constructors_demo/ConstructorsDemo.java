package demo.f_constructors_demo;

/**
 * Created by denny on 07/11/16.
 */
public class ConstructorsDemo {

    public static void demo() {
        ConstructorsUser user1 = new ConstructorsUser(1L, "Denny", "Slover", "DSlover", "Team");
        System.out.println("All Constructor User: " + user1.toString());

        ConstructorsUser user2 = new ConstructorsUser();
        System.out.println("");
        user2.setFirstName("Danny");
        user2.setLastName("Stover");
        user2.setUserId(29L);
        user2.setUserName("DSlover");
        user2.setTeam("Team1");
        System.out.println("No Constructor User: " + user2.toString());

    }
}
