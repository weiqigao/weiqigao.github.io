package demo.c_equals_hash_demo;


import lombok.*;

/**
 * Created by denny on 07/11/16.
 */

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class EqualsHashCodeUser {


    private Long userId;


    private String firstName;


    private String lastName;


    private String userName;
}
