package demo.h_builder_demo;

import demo.e_data_demo.DataUser;
import lombok.extern.java.Log;

import java.util.Arrays;

/**
 * Created by denny on 07/11/16.
 */

@Log
public class BuilderDemo {

    public static void demo() {
        BuilderUser user1 = BuilderUser
                .builder()
                .firstName("Denny")
                .lastName("Slover")
                .userId(2L)
                .userName("DSlover")
                .box("HR")
                .build();

        log.info("Builder User with single App: " + user1.toString());


        BuilderUser user2 = BuilderUser
                .builder()
                .firstName("Denny")
                .lastName("Slover")
                .userId(2L)
                .userName("DSlover")
                .boxes(Arrays.asList("HR", "IT"))
                .build();


        log.info("Builder User with single App: " + user2.toString());

    }
}
