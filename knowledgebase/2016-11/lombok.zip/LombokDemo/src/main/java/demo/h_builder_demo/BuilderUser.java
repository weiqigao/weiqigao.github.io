package demo.h_builder_demo;


import lombok.Builder;
import lombok.Data;
import lombok.NonNull;
import lombok.Singular;

import java.util.List;

/**
 * Created by denny on 07/11/16.
 */

@Builder
@Data
public class BuilderUser {

    private Long userId;

    private String firstName;

    private String lastName;

    private String userName;

    @Singular
    private List<String> boxes;

}
