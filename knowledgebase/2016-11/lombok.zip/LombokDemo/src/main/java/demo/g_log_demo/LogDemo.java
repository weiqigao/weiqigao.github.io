package demo.g_log_demo;

import java.util.logging.Logger;

/**
 * Created by denny on 07/11/16.
 */

public class LogDemo {

    private static final Logger log = Logger.getLogger(LogDemo.class.getName());

    public static void demo() {
        LogUser user = new LogUser();
        user.setFirstName("Denny");
        user.setLastName("Slover");
        user.setUserId(1L);
        user.setUserName("DSlover"); // cant set since it is final

        log.info("Log User: " + user.toString());



    }
}
