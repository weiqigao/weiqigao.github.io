package demo.e_data_demo;

/**
 * Created by denny on 07/11/16.
 */
public class DataDemo {

    public static void demo() {
        DataUser user = new DataUser(1L, "Denny", "Slover", "DSlover");
        System.out.println("Req Constructor User: " + user.toString());

        System.out.println("");
        user.setFirstName("Danny");
        user.setLastName("Stover");
        user.setUserId(29L);
//        user.setUserName("DSlover"); // cant set since it is final
        System.out.println("Setter User: " + user.toString());

        System.out.println("");
        System.out.println("Print using Getters");
        System.out.println("FirstName = " + user.getFirstName());
        System.out.println("LastName = " + user.getLastName());
        System.out.println("UserId = " + user.getUserId());
        System.out.println("UserName = " + user.getUserName());

        System.out.println("");
        System.out.println("Print using ToString");
        System.out.println("ToString output --> " + user.toString());
    }
}
