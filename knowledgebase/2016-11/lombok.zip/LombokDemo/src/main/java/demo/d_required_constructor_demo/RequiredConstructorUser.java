package demo.d_required_constructor_demo;


import lombok.*;

/**
 * Created by denny on 07/11/16.
 */

@Getter
@Setter
@ToString
@RequiredArgsConstructor
public class RequiredConstructorUser {

    @NonNull
    private Long userId;

    @NonNull
    private String firstName;

    @NonNull
    private String lastName;


    private final String userName;
}
