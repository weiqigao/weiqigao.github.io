package demo.c_equals_hash_demo;

/**
 * Created by denny on 07/11/16.
 */
public class EqualsHashCodeDemo {

    public static void demo() {
        EqualsHashCodeUser user1 = new EqualsHashCodeUser();
        user1.setFirstName("Denny");
        user1.setLastName("Slover");
        user1.setUserId(1L);
        user1.setUserName("DSlover");
        System.out.println(user1.toString());

        EqualsHashCodeUser user2 = new EqualsHashCodeUser();
        user2.setFirstName("Denny");
        user2.setLastName("Slover");
        user2.setUserId(1L);
        user2.setUserName("DSlover");
        System.out.println(user2.toString());

        System.out.println("Are the users equal? " + user2.equals(user1));

        System.out.println("User1 hashcode = " + user1.hashCode());
        System.out.println("User2 hashcode = " + user2.hashCode());

        System.out.println("");
        EqualsHashCodeUser user3 = new EqualsHashCodeUser();
        user3.setFirstName("Denny");
        user3.setLastName("Slover");
        user3.setUserId(1L);
        user3.setUserName("DSlover");
        System.out.println(user3.toString());

        EqualsHashCodeUser user4 = new EqualsHashCodeUser();
        user4.setFirstName("Denny");
        user4.setLastName("Slover");
        user4.setUserId(2L);
        user4.setUserName("DSlover");
        System.out.println(user4.toString());

        System.out.println("Are the users equal? " + user3.equals(user4));

        System.out.println("User3 hashcode = " + user3.hashCode());
        System.out.println("User4 hashcode = " + user4.hashCode());
    }
}
