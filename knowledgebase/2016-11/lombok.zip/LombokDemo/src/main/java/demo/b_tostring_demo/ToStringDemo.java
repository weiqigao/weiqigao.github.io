package demo.b_tostring_demo;

/**
 * Created by denny on 07/11/16.
 */
public class ToStringDemo {

    public static void demo() {
        ToStringUser user = new ToStringUser();
        user.setFirstName("Denny");
        user.setLastName("Slover");
        user.setUserId(1L);
        user.setUserName("DSlover");
        System.out.println(user.toString());
    }
}
