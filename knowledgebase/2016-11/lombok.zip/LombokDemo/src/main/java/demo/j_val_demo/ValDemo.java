package demo.j_val_demo;

import lombok.val;

import java.util.ArrayList;

/**
 * Created by denny on 09/11/16.
 */
public class ValDemo {

    public static void demo(){
        val example = new ArrayList<String>();
        val str = new String();
        val count = 1;


    }
}
