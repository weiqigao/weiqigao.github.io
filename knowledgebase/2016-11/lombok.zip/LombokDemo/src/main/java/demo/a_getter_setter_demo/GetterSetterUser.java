package demo.a_getter_setter_demo;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by denny on 07/11/16.
 */

@Getter
@Setter
public class GetterSetterUser {


    private Long userId;


    private String firstName;


    private String lastName;


    private String userName;
}
