package demo.b_tostring_demo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by denny on 07/11/16.
 */

@Getter
@Setter
@ToString
public class ToStringUser {


    private Long userId;

    private String firstName;

    private String lastName;

    private String userName;
}
