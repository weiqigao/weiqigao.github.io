package demo.g_log_demo;


import lombok.Data;

/**
 * Created by denny on 07/11/16.
 */

@Data
public class LogUser {

    private Long userId;

    private String firstName;

    private String lastName;

    private String userName;
}
