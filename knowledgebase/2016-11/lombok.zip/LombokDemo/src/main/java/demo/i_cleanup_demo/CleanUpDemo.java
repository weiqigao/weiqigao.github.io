package demo.i_cleanup_demo;

import lombok.Cleanup;

import java.io.*;

/**
 * Created by denny on 07/11/16.
 */
public class CleanUpDemo {

 public static void demo() throws IOException {
     @Cleanup InputStream in = new FileInputStream("FileIn");
     @Cleanup OutputStream out = new FileOutputStream("FileOut");
     byte[] b = new byte[10000];
     while (true) {
         int r = in.read(b);
         if (r == -1) break;
         out.write(b, 0, r);
     }
 }

 public static void genenerateCode() throws IOException {
     InputStream in = new FileInputStream("FileIn");
          try {
                OutputStream out = new FileOutputStream("FileOut");
                try {
                      byte[] b = new byte[10000];
                      while (true) {
                            int r = in.read(b);
                            if (r == -1) break;
                            out.write(b, 0, r);
                          }
                    } finally {
                      if (out != null) {
                            out.close();
                          }
                    }
              } finally {
                if (in != null) {
                      in.close();
                    }
              }
 }
}
