package demo.a_getter_setter_demo;

/**
 * Created by denny on 06/11/16.
 */
public class  GetterSetterDemo {

    public static void demo(){
        GetterSetterUser user = new GetterSetterUser();
        user.setFirstName("Denny");
        user.setLastName("Slover");
        user.setUserId(1L);
        user.setUserName("DSlover");


        System.out.println("FirstName = " + user.getFirstName());
        System.out.println("LastName = " + user.getLastName());
        System.out.println("UserId = " + user.getUserId());
        System.out.println("UserName = " + user.getUserName());
        System.out.println("ToString output --> " + user.toString());
    }

}
