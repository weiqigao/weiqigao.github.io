package demo.f_constructors_demo;


import lombok.*;

/**
 * Created by denny on 07/11/16.
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConstructorsUser {

    private Long userId;

    private String firstName;

    private String lastName;

    private String userName;

    private  String team;
}
