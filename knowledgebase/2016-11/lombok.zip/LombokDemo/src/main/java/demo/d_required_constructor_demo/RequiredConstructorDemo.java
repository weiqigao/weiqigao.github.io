package demo.d_required_constructor_demo;

/**
 * Created by denny on 07/11/16.
 */
public class RequiredConstructorDemo {

    public static void demo() {
        RequiredConstructorUser user = new RequiredConstructorUser(1L, "Denny", "Slover", "DSlover");
        System.out.println(user.toString());
    }
}
