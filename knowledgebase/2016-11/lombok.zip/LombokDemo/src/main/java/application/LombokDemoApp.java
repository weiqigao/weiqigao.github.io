package application;

import demo.a_getter_setter_demo.GetterSetterDemo;
import demo.c_equals_hash_demo.EqualsHashCodeDemo;
import demo.d_required_constructor_demo.RequiredConstructorDemo;
import demo.b_tostring_demo.ToStringDemo;
import demo.e_data_demo.DataDemo;
import demo.g_log_demo.LogDemo;
import demo.f_constructors_demo.ConstructorsDemo;
import demo.h_builder_demo.BuilderDemo;
import demo.i_cleanup_demo.CleanUpDemo;

import java.io.IOException;


/**
 * Created by denny on 06/11/16.
 */


public class LombokDemoApp {

    enum Demo {
        Getter,
        ToString,
        EqualsAndHash,
        RequiredConstructor,
        Data,
        Constructors,
        Log,
        Builder

    };

    public static void main(String[] args) {

        Demo currentDemo = Demo.Builder;

        switch(currentDemo) {

            case Getter:
                System.out.println("Getter and Setter Demo");
                GetterSetterDemo.demo();
                break;

            case ToString:
                System.out.println("ToString Demo");
                ToStringDemo.demo();
                break;

            case EqualsAndHash:
                System.out.println("EqualsAndHashCode Demo");
                EqualsHashCodeDemo.demo();
                break;

            case RequiredConstructor:
                System.out.println("RequiredArgsConstructor Demo");
                RequiredConstructorDemo.demo();
                break;

            case Data:
                System.out.println("Data Demo");
                DataDemo.demo();
                break;

            case Constructors:
                System.out.println("Constructor Demo");
                ConstructorsDemo.demo();
                break;

            case Log:
                System.out.println("Log Demo");
                LogDemo.demo();
                break;

            case Builder:
                System.out.println("Builder Demo");
                BuilderDemo.demo();
                break;
        }
    }
}
