package foo.client;

import foo.server.*;

import java.util.*;
import javax.naming.*;

public class Main {
    public static void main(String[] args) throws Exception {
        Context context = new InitialContext();
        HelloHome home = (HelloHome) context.lookup("Hello");
        Hello hello = home.create();
        System.out.println("From server: " + hello.sayHello("Hi"));

        ItemHome itemHome = (ItemHome) context.lookup("Item");
        Item item1 = itemHome.create(new Integer(100));
        item1.setName("An Item");
        Item item2 = itemHome.findByPrimaryKey(new Integer(100));
        System.out.println("Item: " + item2.getName());
        for (int i = 0; i < 1024; i++) {
            itemHome.create(new Integer(1000 + i));
        }
        Collection items = itemHome.findAll();
        System.out.println(items);
        Iterator iter = items.iterator();
        while (iter.hasNext()) {
            ((Item) iter.next()).remove();
        }
    }
}
