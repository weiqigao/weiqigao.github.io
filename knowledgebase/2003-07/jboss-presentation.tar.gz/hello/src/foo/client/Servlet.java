package foo.client;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.ejb.*;
import javax.naming.*;
import java.rmi.*;
import java.io.*;
import foo.server.*;

public class Servlet extends HttpServlet {
    public void doGet(HttpServletRequest req,
        HttpServletResponse resp) throws IOException, ServletException {
        String str = req.getParameter("str");
        String newStr = null;
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        try {
            Context context = new InitialContext();
            HelloHome helloHome = (HelloHome) context.lookup("Hello");
            Hello hello = helloHome.create();
            newStr = hello.sayHello(str);
            if (newStr == null) {
                newStr = "";
            }
        } catch (NamingException e) {
        } catch (CreateException e) {
        } catch (RemoteException e) {
        }
        out.println("<html><body><form><input type='textfield' width='20'" +
            " name='str' /> <input type='submit' value='Send'/><br/>" +
            newStr + "</body></html>");
    }
}
