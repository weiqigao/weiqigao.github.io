package foo.client;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.naming.*;
import javax.ejb.*;
import java.rmi.*;
import foo.server.*;

public class GUI extends JFrame implements ActionListener {
    private JTextField textField= new JTextField(10);
    private JTextField textField2 = new JTextField(10);
    private JButton button = new JButton("Send");
    private JPanel panel = new JPanel();

    public GUI() {
        super("St. Louis Java Users Group");
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException e) {
        } catch (InstantiationException e) {
        } catch (IllegalAccessException e) {
        } catch (UnsupportedLookAndFeelException e) {
        }
        textField.setFont(new Font("Helvetica", Font.BOLD, 36));
        textField2.setFont(new Font("Helvetica", Font.BOLD, 36));
        button.setFont(new Font("Helvetica", Font.BOLD, 24));
        getContentPane().setLayout(new BorderLayout());
        button.addActionListener(this);
        textField.addActionListener(this);
        getContentPane().add(textField, BorderLayout.CENTER);
        getContentPane().add(button, BorderLayout.EAST);
        getContentPane().add(textField2, BorderLayout.SOUTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
        setLocation(200, 200);
        setVisible(true);
    }


    public void actionPerformed(ActionEvent e) {
        String str = textField.getText();
        String newStr = "";
        try {
            Context context = new InitialContext();
            HelloHome helloHome = (HelloHome) context.lookup("Hello");
            Hello hello = helloHome.create();
            newStr = hello.sayHello(str);
        } catch (NamingException ne) {
        } catch (CreateException ce) {
        } catch (RemoteException re) {
        }
        textField.setText("");
        textField2.setText(newStr);
    }

    public static void main(String[] args) {
        new GUI();
    }
}
