package foo.tests;

import javax.naming.*;
import javax.ejb.*;
import java.rmi.*;
import junit.framework.*;
import foo.server.*;

public class TestItem extends TestCase {
    private Context context;
    private ItemHome itemHome;
    private Item item;

    public void setUp() throws NamingException, CreateException,
        RemoteException {
        context = new InitialContext();
        itemHome = (ItemHome) context.lookup("Item");
        try {
            item = itemHome.findByPrimaryKey(new Integer(1));
        } catch (FinderException e) {
            item = itemHome.create(new Integer(1));
        }
    }

    public void tearDown() throws RemoteException, RemoveException {
        item.remove();
    }

    public void testHome() {
        assertNotNull("itemHome should be non-null", itemHome);
    }

    public void testItem() throws NamingException, CreateException {
        assertNotNull("item should be non-null", item);
    }

    public void testGetItem() throws RemoteException {
        Integer i = item.getItem();
        assertEquals("The item property of the entity bean is 1",
            1, i.intValue());
    }
}
