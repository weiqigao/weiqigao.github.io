package foo.tests;

import junit.framework.*;
import javax.naming.*;
import javax.ejb.*;
import java.rmi.*;
import foo.server.*;

public class TestHello extends TestCase {
    private Context context;
    private HelloHome helloHome;

    public void setUp() throws NamingException {
        Context context = new InitialContext();
        helloHome = (HelloHome) context.lookup("Hello");
    }

    public void testHome() throws NamingException {
        assertNotNull("helloHome should be non-null", helloHome);
    }

    public void testHello() throws RemoteException, CreateException {
        Hello hello = helloHome.create();
        assertNotNull("hello should be non-null", hello);
    }

    public void testSayHello() throws RemoteException, CreateException {
        Hello hello = helloHome.create();
        assertTrue("Hello.sayHello(String) returns a String",
            hello.sayHello("Hi") instanceof String);
    }
}
