package foo.server;

import java.util.*;
import javax.ejb.*;
import javax.naming.*;
import javax.jms.*;

/**
 * @ejb.bean type="Stateless" view-type="remote" name="Hello"
 * @ejb.transaction      type="Required"
 * @ejb.transaction-type type="Container"
 */
public abstract class HelloBean implements SessionBean {
    /**
     * @ejb.interface-method view-type="remote"
     */
    public String sayHello(String message) {
        try {
            Context context = new InitialContext();
            // Using entity bean
            ItemLocalHome itemLocalHome =
                (ItemLocalHome) context.lookup("ItemLocal");
            Integer pk = new Integer(1);
            ItemLocal itemLocal = null;
            try {
                itemLocal = itemLocalHome.create(pk);
            } catch (CreateException e) {
                itemLocal = itemLocalHome.findByPrimaryKey(pk);
            }
            String newStr = itemLocal.getName();
            itemLocal.setName(message);
            // Using message-driven bean
            QueueConnectionFactory factory = (QueueConnectionFactory)
                context.lookup("ConnectionFactory");
            QueueConnection connection = factory.createQueueConnection();
            Queue queue = (Queue) context.lookup("queue/Note");
            QueueSession session = connection.createQueueSession(false,
                QueueSession.AUTO_ACKNOWLEDGE);
            connection.start();
            QueueSender sender = session.createSender(queue);
            TextMessage textMessage = session.createTextMessage(
                "Message is: " + message);
            sender.send(textMessage);
            connection.stop();
            // Return new message
            return newStr;
        } catch (NamingException e) {
        } catch (FinderException eee) {
        } catch (JMSException eee) {
        }
        return "Error";
    }
}
