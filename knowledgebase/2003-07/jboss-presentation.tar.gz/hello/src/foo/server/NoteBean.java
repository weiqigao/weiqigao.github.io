package foo.server;

import javax.ejb.*;
import javax.jms.*;
import javax.naming.*;
import javax.jms.Message;

/**
 * @ejb.bean name="Note" destination-type="javax.jms.Queue"
 *    acknowledge-mode="Auto-acknowledge"
 *    subscription-durability="NonDurable"
 *    transaction-type="Container"
 *
 * @jboss.destination-jndi-name name="Note"
 */
public class NoteBean implements MessageDrivenBean, MessageListener {
    private Context context;

    public void onMessage(Message message) {
        if (message instanceof TextMessage) {
            try {
                TextMessage textMessage = (TextMessage) message;
                System.out.println("Note: " + textMessage.getText());
            } catch (JMSException e) {
            }
        }
    }

    public void setMessageDrivenContext(MessageDrivenContext context) {}

    public void ejbCreate() {
    }
    public void ejbRemove() {}
}
