package foo.server;

import javax.ejb.*;

/**
 * @ejb.bean type="CMP" view-type="both"
 *     name="Item" primkey-field="item"
 *
 * @ejb.transaction      type="Required"
 *
 * @ejb.transaction-type type="Container"
 *
 * @ejb.pk
 *
 * @ejb.finder signature "java.util.Collection findAll()"
 *
 * @jboss.persistence datasource="java:/PostgresDS"
 *    datasource-mapping="PostgreSQL"
 */
public abstract class ItemBean implements EntityBean {
    /**
     * @ejb.create-method
     */
    public Integer ejbCreate(Integer item) throws CreateException {
        setItem(item);
        return null;
    }

    /**
     * @ejb.interface-method view-type="both"
     * @ejb.persistence
     * @ejb.pk-field
     */
    public abstract Integer getItem();

    /**
     * @ejb.interface-method view-type="both"
     * @ejb.persistence
     * @ejb.pk-field
     */
    public abstract void setItem(Integer number);

    /**
     * @ejb.interface-method view-type="both"
     * @ejb.persistence
     */
    public abstract String getName();

    /**
     * @ejb.interface-method view-type="both"
     * @ejb.persistence
     */
    public abstract void setName(String name);
}
