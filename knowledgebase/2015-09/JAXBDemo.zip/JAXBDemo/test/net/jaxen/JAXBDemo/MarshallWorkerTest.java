/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.jaxen.JAXBDemo;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.jaxen.stljug.data.JugMember;
import net.jaxen.stljug.data.MemberSkill;
import net.jaxen.stljug.data.Skill;
import net.jaxen.stljug.data.Skills;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author Jackson
 */
public class MarshallWorkerTest {

    MarshallWorker instance;

    public MarshallWorkerTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        instance = new MarshallWorker();
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of marshallSkill method, of class MarshallWorker.
     */
    @Test
    public void testMarshallSkill() {
        System.out.println("marshallSkill");
        
        // Create a skill
        Skill skill = new Skill();
        skill.setSkillId(1);
        skill.setSkillName("Java SE");

        // Marshall it and 
        String skillXml = instance.marshallSkill(skill);
        
        // Print out XML
        System.out.println(skillXml);
        
        Assert.assertFalse(skillXml.contains("<skill><skilId>"));
    }

    @Test
    public void testMarshallSkillArray() {
        System.out.println("marshallSkillArray");
        List<Skill> skills = buildSkillList();
        String skillXml = instance.marshallSkillArray(skills);
        System.out.println(skillXml);
        Assert.assertNotNull(skillXml);
        Assert.assertFalse(skillXml.contains("<skill><skilId>"));
    }

    @Test
    public void testMarshallSkills() {

        System.out.println("marshallSkillArray");
        List<Skill> skillList = buildSkillList();
        Skills skills = new Skills();
        skills.setSkillList(skillList);
        String skillXml = instance.marshallSkills(skills);
        System.out.println(skillXml);
        Assert.assertNotNull(skillXml);
        Assert.assertFalse(skillXml.contains("<skill><skilId>"));
    }
    
    @Test
    public void testMember() {
        System.out.println("testMember");
        JugMember jugM = buildMember();
        String jugMXML = instance.marshallJugMember(jugM);
        System.out.println(jugMXML);
        Assert.assertNotNull(jugMXML);
        Assert.assertFalse(jugMXML.contains("<skill><skilId>"));
    }

    private JugMember buildMember() {
        JugMember jugM = new JugMember();        
        try {
            String dateStr = "09/10/2010";
            DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
            Date date = df.parse(dateStr);
            jugM.setDateJoined(date);
        } catch (ParseException ex) {
            Logger.getLogger(MarshallWorkerTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        jugM.setFirstName("Jackson");
        jugM.setFirstName("Thompson");
        jugM.setMemberId(77);
        jugM.setZipCode(63385);
        List<MemberSkill> skillList = new ArrayList<>();
        MemberSkill ms1 = new MemberSkill();
        ms1.setMemberId(77);
        ms1.setSkillLevel(4);
        ms1.setSkillId(1);
        ms1.setMemberSkilId(14);
        MemberSkill ms2 = new MemberSkill();
        ms2.setMemberId(77);
        ms2.setSkillLevel(4);
        ms2.setSkillId(1);
        ms2.setMemberSkilId(14);
        skillList.add(ms1);
        skillList.add(ms2);
        jugM.setMemberSkillList(skillList);
        jugM.setEmail("jaxen@jaxen.net");

        return jugM;
    }

    private List<Skill> buildSkillList() {
        List<Skill> skills = new ArrayList<>();
        Skill skill1 = new Skill();
        skill1.setSkillId(1);
        skill1.setSkillName("Java SE");
        skills.add(skill1);
        Skill skill2 = new Skill();
        skill2.setSkillId(2);
        skill2.setSkillName("Java EE");
        skills.add(skill2);
        return skills;
    }

}
