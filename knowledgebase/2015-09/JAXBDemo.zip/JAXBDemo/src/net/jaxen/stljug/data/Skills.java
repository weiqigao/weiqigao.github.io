/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.jaxen.stljug.data;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlList;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Jackson
 */
@XmlRootElement (name="My_Skill_List")
@XmlAccessorType(XmlAccessType.FIELD)
public class Skills {
    
    @XmlElementWrapper(name="What_Can_They_Do")
    @XmlElement(name="Expertise")
    private List<Skill> skillList;
    
    @XmlTransient
    private List<String> skillStringList;
    
    public Skills(){
        skillStringList = new ArrayList<>();
    }

    /**
     * @return the skillList
     */
    public List<Skill> getSkillList() {
        return skillList;
    }

    /**
     * @param skillList the skillList to set
     */
    public void setSkillList(List<Skill> skillList) {
        this.skillList = skillList;
        
    }
    
    @XmlList
    //@XmlAttribute
    public List<String> getSkillStringList() { 
        
        for(Skill skill : skillList) {
            skillStringList.add(skill.getSkillName());            
        }
        return skillStringList; 
    }

    /**
     * @param skillStringList the skillStringList to set
     */
    public void setSkillStringList(List<String> skillStringList) {
        this.skillStringList = skillStringList;
    }
    
}
