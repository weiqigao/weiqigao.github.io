/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.jaxen.stljug.data;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Jackson
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class MemberSkill implements Serializable {
    private Integer memberSkilId;
    private int skillLevel;
    @XmlTransient
    private int memberId;
    private int skillId;

    public MemberSkill() {
    }

    public MemberSkill(Integer memberSkilId) {
        this.memberSkilId = memberSkilId;
    }

    public MemberSkill(Integer memberSkilId, int skillLevel) {
        this.memberSkilId = memberSkilId;
        this.skillLevel = skillLevel;
    }

    public Integer getMemberSkilId() {
        return memberSkilId;
    }

    public void setMemberSkilId(Integer memberSkilId) {
        this.memberSkilId = memberSkilId;
    }

    public int getSkillLevel() {
        return skillLevel;
    }

    public void setSkillLevel(int skillLevel) {
        this.skillLevel = skillLevel;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public int getSkillId() {
        return skillId;
    }

    public void setSkillId(int skillId) {
        this.skillId = skillId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (memberSkilId != null ? memberSkilId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MemberSkill)) {
            return false;
        }
        MemberSkill other = (MemberSkill) object;
        if ((this.memberSkilId == null && other.memberSkilId != null) || (this.memberSkilId != null && !this.memberSkilId.equals(other.memberSkilId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "net.jaxen.stljug.entities.MemberSkill[ memberSkilId=" + memberSkilId + " ]";
    }
    
}
