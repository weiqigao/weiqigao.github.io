/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.jaxen.stljug.data;

import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import net.jaxen.JAXBDemo.DateAdapter;

/**
 *
 * @author Jackson
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class JugMember {
    
    private Integer memberId;
    private String firstName;
    private String lastName;
    private String email;
    private int zipCode;
    @XmlJavaTypeAdapter(DateAdapter.class)
    private Date dateJoined;
    @XmlElementWrapper(name="What_Can_They_Do")
    private List<MemberSkill> memberSkillList;

    /**
     * @return the memberId
     */
    public Integer getMemberId() {
        return memberId;
    }

    /**
     * @param memberId the memberId to set
     */
    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the zipCode
     */
    public int getZipCode() {
        return zipCode;
    }

    /**
     * @param zipCode the zipCode to set
     */
    public void setZipCode(int zipCode) {
        this.zipCode = zipCode;
    }

    /**
     * @return the dateJoined
     */
    public Date getDateJoined() {
        return dateJoined;
    }

    /**
     * @param dateJoined the dateJoined to set
     */
    public void setDateJoined(Date dateJoined) {
        this.dateJoined = dateJoined;
    }

    /**
     * @return the memberSkillList
     */
    public List<MemberSkill> getMemberSkillList() {
        return memberSkillList;
    }

    /**
     * @param memberSkillList the memberSkillList to set
     */
    public void setMemberSkillList(List<MemberSkill> memberSkillList) {
        this.memberSkillList = memberSkillList;
    }
}
