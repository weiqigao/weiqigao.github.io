/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.jaxen.JAXBDemo;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.xml.bind.annotation.adapters.XmlAdapter;

/**
 *
 * @author Jackson
 */
public class DateAdapter extends XmlAdapter<String, Date> {
    
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
    
    public Date unmarshal(final String xml) throws Exception {
      return this.dateFormat.parse(xml);
   }

   public String marshal(final Date object) throws Exception {
      return this.dateFormat.format(object);
   }
    
}
