/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.jaxen.JAXBDemo;

import java.io.StringWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import net.jaxen.stljug.data.JugMember;
import net.jaxen.stljug.data.Skill;
import net.jaxen.stljug.data.Skills;


/**
 *
 * @author Jackson
 */
public class MarshallWorker {

    Marshaller marshaller;

    public MarshallWorker() {
        try {          
            JAXBContext context = JAXBContext.newInstance("net.jaxen.stljug.data");
            marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        } catch (JAXBException ex) {
            Logger.getLogger(MarshallWorker.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public String marshallSkill(Skill skill) {
        String ret = null;
        try {
            StringWriter sw = new StringWriter();
            marshaller.marshal(skill, sw);
            ret = sw.toString();
        } catch (JAXBException ex) {
            ex.printStackTrace();
        }
        return ret;
    }

    public String marshallSkillArray(List<Skill> skills) {
        String ret = null;
        try {
            StringWriter sw = new StringWriter();
            marshaller.marshal(skills, sw);
            ret = sw.toString();
        } catch (JAXBException ex) {
            ex.printStackTrace();
        }
        return ret;
    }

    public String marshallSkills(Skills skills) {
        String ret = null;
        try {
            StringWriter sw = new StringWriter();
            marshaller.marshal(skills, sw);
            ret = sw.toString();
        } catch (JAXBException ex) {
            ex.printStackTrace();
        }
        return ret;
    }

    public String marshallJugMember(JugMember jMember) {
        String ret = null;
        try {
            StringWriter sw = new StringWriter();
            marshaller.marshal(jMember, sw);
            ret = sw.toString();
        } catch (JAXBException ex) {
            ex.printStackTrace();
        }
        return ret;
    }
}
