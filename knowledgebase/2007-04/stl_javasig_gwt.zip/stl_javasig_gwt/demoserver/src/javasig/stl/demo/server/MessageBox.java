/***************************************************************************
 * Copyright 2007 Andrew Prunicki <prunand@iit.edu>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **************************************************************************/
package javasig.stl.demo.server;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javasig.stl.demo.client.Message;

/**
 * @author Andrew Prunicki
 *
 */
public class MessageBox {
	
	private List<Message> _messages;
	private MessageComparator _comparator;
	
	public MessageBox() {
		_messages = new ArrayList<Message>();
		_comparator = new MessageComparator();
	}
	
	public synchronized void addMessage(Message message) {
		_messages.add(message);
		//TODO Choose a more efficient collection for sorting
		Collections.sort(_messages, _comparator);
	}
	
	public synchronized List collectMessages() {
		List<Message> currentMessages = new ArrayList<Message>();
		currentMessages.addAll(_messages);
		_messages.clear();
		
		return currentMessages;
	}
	
	private class MessageComparator implements Comparator {
		//TODO Fix this to properly use generics.

		public int compare(Object arg0, Object arg1) {
			int retval = 0;
			
			Message leftMessage = (Message) arg0;
			Message rightMessage = (Message) arg1;
			
			if (leftMessage.getTime() < rightMessage.getTime()) {
				retval = -1;
			} else if (leftMessage.getTime() > rightMessage.getTime()) {
				retval = 1;
			}
			
			return retval;
		}
		
	}

}
