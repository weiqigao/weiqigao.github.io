/**
 * 
 */
package javasig.stl.demo.server;

import java.util.Date;

import javasig.stl.demo.client.User;

/**
 * @author Andrew Prunicki
 *
 */
public class UserState {
	
	private User _user;
	
	private Date _lastAccessTime;

	public UserState(User user, Date accessTime) {
		_user = user;
		_lastAccessTime = accessTime;
	}
	
	/**
	 * @return the user
	 */
	public User getUser() {
		return _user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		_user = user;
	}

	/**
	 * @return the lastAccessTime
	 */
	public Date getLastAccessTime() {
		return _lastAccessTime;
	}

	/**
	 * @param lastAccessTime the lastAccessTime to set
	 */
	public void setLastAccessTime(Date lastAccessTime) {
		_lastAccessTime = lastAccessTime;
	}
}
