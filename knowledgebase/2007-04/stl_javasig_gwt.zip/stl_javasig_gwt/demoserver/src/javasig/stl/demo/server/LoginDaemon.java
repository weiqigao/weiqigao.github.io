/**
 * 
 */
package javasig.stl.demo.server;

import java.util.List;

import javasig.stl.demo.client.ChatService;
import javasig.stl.demo.client.User;

/**
 * @author andy
 *
 */
public class LoginDaemon implements Runnable {
	
	private static final int INACTIVE_SIGNOUT_TIME = 15 * 1000;

	private List<UserState> _loggedInUsers;
	
	private ChatService _chatService;
	
	public LoginDaemon(List<UserState> loggedInUsers, ChatService chatService) {
		_loggedInUsers = loggedInUsers;
		_chatService = chatService;
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		while (true) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("Woken from sleep, stopping.");
				break;
			}
			
			checkForInActivity();
		}
	}

	private void checkForInActivity() {
		long now = System.currentTimeMillis();
		
		for (UserState userState : _loggedInUsers) {
			if (userState.getUser().isActive()) {
				long lastAccess = userState.getLastAccessTime().getTime();
				
				if (now - lastAccess > INACTIVE_SIGNOUT_TIME) {
					User user = userState.getUser();
					System.out.println("Signing out user '" + user + "' due to inactivity.");
					System.out.println("last access was " + lastAccess);
					System.out.println("time is " + now);
					_chatService.signout(user);
				}
			}
		}
	}

}
