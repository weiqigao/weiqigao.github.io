package javasig.stl.demo.server;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;

import javasig.stl.demo.client.ChatService;
import javasig.stl.demo.client.Friend;
import javasig.stl.demo.client.Message;
import javasig.stl.demo.client.User;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

/**
 * Servlet implementation class for Servlet: ChatServiceImpl
 * 
 * @web.servlet name="ChatServiceImpl" display-name="ChatServiceImpl" load-on-startup="1" 
 * 
 * @web.servlet-mapping url-pattern="/service/Chat"
 * 
 * @author Andrew Prunicki <prunand@iit.edu>
 * @author Brad Busch <brad.busch@gmail.com>
 */
public class ChatServiceImpl extends RemoteServiceServlet implements
		ChatService {

	private static final long serialVersionUID = 1L;

	private static final Log LOG = LogFactory.getLog(ChatServiceImpl.class);

	private ConcurrentMap<String, MessageBox> _inboxes;

	private List<UserState> _loggedInUsers;
	
	public ChatServiceImpl() {
		_inboxes = new ConcurrentHashMap<String, MessageBox>();
		_loggedInUsers = new CopyOnWriteArrayList<UserState>();
		
		LoginDaemon daemon = new LoginDaemon(_loggedInUsers, this);
		
		String startDaemonStr = System.getProperty("javasig.startdaemon");
		
		if (Boolean.TRUE.toString().equalsIgnoreCase(startDaemonStr)) {
			//TODO Fix the logout daemon to not be coupled directly to the RPC servlet.
			Thread t = new Thread(daemon);
			t.setDaemon(true);
			
			t.start();
		}
	}
	
	public User signin(String userName) {
		User user = null;

		UserState friendState = findLoggedInFriend(userName);

		if (friendState == null) {
			user = createUser(userName);
			user.setActive(true);
			friendState = new UserState(user, user.getLoginTime());
			_loggedInUsers.add(friendState);
		} else {
			if (!friendState.getUser().isActive()) {
				//User was logged in before, re-activate
				user = friendState.getUser();
				_inboxes.put(userName, new MessageBox());
				user.setActive(true);
				friendState.setLastAccessTime(new Date());
			}
		}

		return user;
	}
	
	private User createUser(String userName) {
		User user = new User(userName, new Date());
		_inboxes.put(userName, new MessageBox());
		return user;
	}

	public void signout(User user) {
		_inboxes.remove(user.getName());

		UserState userState = findLoggedInFriend(user.getName());
		if (userState != null) {
			userState.getUser().setActive(false);
		}
	}

	private UserState findLoggedInFriend(String name) {
		UserState found = null;
		
		for (UserState userState : _loggedInUsers) {
			if (userState.getUser().getName().equals(name)) {
				found = userState;
			}
		}
		
		return found;
	}

	public List getFriends(User user) {
		List<Friend> friends = new ArrayList<Friend>();
		
		for (UserState userState : _loggedInUsers) {
			friends.add(userState.getUser());
		}

		return friends;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javasig.stl.demo.client.ChatService#sendMessage(javasig.stl.demo.client.Friend,
	 *      java.lang.String)
	 */
	public int sendMessage(User user, Friend friend, String messageStr) {
		LOG.debug("Server received message from user " + user + " for friend "
				+ friend + ", message: '" + messageStr + "'");
		int retval = MESSAGE_SEND_SUCCESS;

		MessageBox inbox = (MessageBox) _inboxes.get(friend.getName());
		MessageBox outbox = (MessageBox) _inboxes.get(user.getName());

		if (inbox != null && outbox != null) {
			Message message = new Message(user, friend, messageStr, System
					.currentTimeMillis());
			inbox.addMessage(message);
			outbox.addMessage(message);
		} else {
			LOG.debug("Could not get both mailboxes");
			if (inbox == null) {
				LOG.debug("Could not get inbox for " + friend);
				// The friend has logged off, send message.
				retval = MESSAGE_SEND_FAILURE_NO_RECIPIENT;
			} else if (outbox == null) {
				LOG.error("Could not get outbox for user " + user);
				// This should never happen
				throw new RuntimeException(
						"Server error - no message box found for user " + user);
			}
		}

		return retval;
	}

	public List getMessages(User user) {
		LOG.debug("Looking up messages for user " + user);

		MessageBox messageBox = (MessageBox) _inboxes.get(user.getName());

		if (messageBox == null) {
			throw new RuntimeException(
					"Server error - no message box found for user " + user);
		} else {
			UserState userState = findLoggedInFriend(user.getName());
			userState.setLastAccessTime(new Date());
			
			return messageBox.collectMessages();
		}
	}
}