/***************************************************************************
 * Copyright 2007 Andrew Prunicki <prunand@iit.edu>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **************************************************************************/
package javasig.stl.demo.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

/**
 * @author Andrew Prunicki
 * 
 */
public class ChatDialogPanel extends Composite {
	
	private User _user;
	private Friend _friend;
	private TextBox _textBox;
	private VerticalPanel _messagePanel;
	private ScrollPanel _scroll;

	public ChatDialogPanel(User user, Friend friend) {
		_user = user;
		_friend = friend;
		
		_messagePanel = new VerticalPanel();
		_messagePanel.setWidth("100%");
		
		_scroll = new ScrollPanel(_messagePanel);
		_scroll.setWidth("100%");
		_scroll.setSize("250px", "200px");
		
		HorizontalPanel box = new HorizontalPanel();
		box.setWidth("100%");
		box.setBorderWidth(1);
		box.add(_scroll);
		
		VerticalPanel panel = new VerticalPanel();
		panel.add(box);
		_textBox = new TextBox();
		_textBox.setWidth("100%");
		panel.add(_textBox);
		
		HorizontalPanel buttonPanel = new HorizontalPanel();
		buttonPanel.setWidth("100%");
		Button sendButton = new Button("Send");
		buttonPanel.add(sendButton);
		buttonPanel.setCellHorizontalAlignment(sendButton, HasHorizontalAlignment.ALIGN_CENTER);
		
		panel.add(buttonPanel);
		
		initWidget(panel);
		
		sendButton.addClickListener(new ClickListener() {

			public void onClick(Widget sender) {
				String message = _textBox.getText();
				if (message != null && message.length() > 0) {
					_textBox.setText("");
					sendMessage(message);
				}
			}
			
		});
		
		MessageTimer timer = ChatRegistry.getInstance().getTimer();
		timer.addDialogPanel(this);
	}
	
	public void addMessage(Message message) {
		Label label = new Label(message.toString());
		_messagePanel.add(label);
		_scroll.ensureVisible(label);
	}
	
	/**
	 * @return the friend
	 */
	public Friend getFriend() {
		return _friend;
	}

	/**
	 * @param friend the friend to set
	 */
	public void setFriend(Friend friend) {
		_friend = friend;
	}

	private void sendMessage(String message) {
		ServiceLocator serviceLocator = ChatRegistry.getInstance().getServiceLocator();
		ChatServiceAsync service = serviceLocator.locateChatService();
		
		AsyncCallback callback = new AsyncCallback() {
	
			public void onFailure(Throwable caught) {
				GWT.log("Problem sending message (" + caught.getMessage() + ")", null);
			}
	
			public void onSuccess(Object result) {
				int retCode = ((Integer) result).intValue();
				
				if (retCode == ChatService.MESSAGE_SEND_FAILURE_NO_RECIPIENT) {
					//TODO Change friend status to inactive and dispose of window.
					System.out.println("Change friend status to inactive.");
				}
			}
			
		};
		
		service.sendMessage(_user, _friend, message, callback);
	}

}
