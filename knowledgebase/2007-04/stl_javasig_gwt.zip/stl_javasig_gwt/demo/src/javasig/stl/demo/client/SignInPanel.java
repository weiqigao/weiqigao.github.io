/***************************************************************************
 * Copyright 2007 Andrew Prunicki <prunand@iit.edu>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **************************************************************************/
package javasig.stl.demo.client;


import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.DockPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;

/**
 * @author Anrew Prunicki
 * 
 */
public class SignInPanel extends Composite {

	private TextBox _textBox;
	private RootPanelManager _rootPanelManager;

	/**
	 * 
	 */
	public SignInPanel(RootPanelManager rootPanel) {
		_rootPanelManager = rootPanel;
		Label label = new Label("loginName");
		_textBox = new TextBox();
		Button button = new Button("Signin");
		addLoginNameListener(button);

		HorizontalPanel panel2 = new HorizontalPanel();
		panel2.add(label);
		panel2.add(_textBox);

		DockPanel panel = new DockPanel();
		panel.add(button, DockPanel.SOUTH);
		panel.add(panel2, DockPanel.CENTER);

		initWidget(panel);
	}

	private void addLoginNameListener(Button button) {
		button.addClickListener(new ClickListener() {

			public void onClick(Widget sender) {
				String loginName = _textBox.getText();
				signin(loginName);
			}

		});
	}
	
	private void signin(String loginName) {
		//Usually you won't create a service locator, but here you must since
		// we don't have a user yet, and the registry needs a user to be
		// initialized.
		ServiceLocator serviceLocator = new ServiceLocator();
		ChatServiceAsync service = serviceLocator.locateChatService();
		
		AsyncCallback callback = new AsyncCallback() {
	
			public void onFailure(Throwable caught) {
				GWT.log("Problem signing in (" + caught.getMessage() + ")", null);
				caught.printStackTrace();
			}
	
			public void onSuccess(Object result) {
				User user = (User) result;
				ChatRegistry.init(user);
				
				ChatPanel chatPanel = new ChatPanel(_rootPanelManager, SignInPanel.this, ChatRegistry.getInstance().getUser());
				ServiceHelper.getFriends(user, chatPanel, _rootPanelManager);
				ChatRegistry.getInstance().getTimer().setChatPanel(chatPanel);
			}
		};
		
		service.signin(loginName, callback);
	}
}
