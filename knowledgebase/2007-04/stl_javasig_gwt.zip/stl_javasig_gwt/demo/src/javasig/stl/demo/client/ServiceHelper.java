/**
 * 
 */
package javasig.stl.demo.client;

import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * @author Andrew Prunicki
 *
 */
public class ServiceHelper {
	
	public static void getFriends(User user, ChatPanel chatPanel, RootPanelManager rootPanelManager) {
		ChatRegistry registry = ChatRegistry.getInstance();
		
		ServiceLocator serviceLocator = registry.getServiceLocator();
		ChatServiceAsync service = serviceLocator.locateChatService();
		
		FriendsCallback callback = new FriendsCallback(rootPanelManager, chatPanel);
		
		service.getFriends(user, callback);
	}
	
	private static class FriendsCallback implements AsyncCallback {
		
		private RootPanelManager _rootPanelManager;
		private ChatPanel _chatPanel;
		
		public FriendsCallback(RootPanelManager rootPanelManager, ChatPanel chatPanel) {
			_rootPanelManager = rootPanelManager;
			_chatPanel =  chatPanel;
		}
		
		public void onFailure(Throwable caught) {
			GWT.log("Problem getting friends (" + caught.getMessage() + ")", null);
			caught.printStackTrace();
		}

		public void onSuccess(Object result) {
			List friends = (List) result;
			
			_chatPanel.setFriends(friends);
			
			if (_rootPanelManager != null) {
				//Call the rootpanel mgr to set the chat panel as root if it's not already
				_rootPanelManager.setPanel(_chatPanel);
			}
		}
	}

}
