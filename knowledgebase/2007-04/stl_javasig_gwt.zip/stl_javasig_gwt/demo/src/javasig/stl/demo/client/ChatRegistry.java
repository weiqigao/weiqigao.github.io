/***************************************************************************
 * Copyright 2007 Andrew Prunicki <prunand@iit.edu>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **************************************************************************/
package javasig.stl.demo.client;

/**
 * @author Andrew Prunicki
 *
 */
public class ChatRegistry {

	private static ChatRegistry _instance;
	
	private User _user;
	private MessageTimer _timer;
	private ServiceLocator _serviceLocator;
	
	private ChatRegistry(User user) {
		_user = user;
		_timer = new MessageTimer(user);
		_serviceLocator = new ServiceLocator();
	}
	
	public static void init(User user) {
		_instance = new ChatRegistry(user);
	}
	
	public static ChatRegistry getInstance() {
		return _instance;
	}
	
	/**
	 * @return the user
	 */
	public User getUser() {
		return _user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		_user = user;
	}

	/**
	 * @return the timer
	 */
	public MessageTimer getTimer() {
		return _timer;
	}

	/**
	 * @param timer the timer to set
	 */
	public void setTimer(MessageTimer timer) {
		_timer = timer;
	}

	/**
	 * @return the serviceLocator
	 */
	public ServiceLocator getServiceLocator() {
		return _serviceLocator;
	}

	/**
	 * @param serviceLocator the serviceLocator to set
	 */
	public void setServiceLocator(ServiceLocator serviceLocator) {
		_serviceLocator = serviceLocator;
	}
}
