/***************************************************************************
 * Copyright 2007 Andrew Prunicki <prunand@iit.edu>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **************************************************************************/
package javasig.stl.demo.client;

import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.FocusPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;

/**
 * @author Andrew Prunicki <prunand@iit.edu>
 * @author Brad Busch <brad.busch@gmail.com>
 */
public class FriendListItem extends Composite {
	
	private static final String ACTIVE_IMAGE_URL = "metacontact_online.png";
	private static final String INACTIVE_IMAGE_URL = "metacontact_offline.png";
	private static final String ACTIVE_CONVERSATION = "metaconversation_active.png";

	private static final String SHADED_STYLE_NAME = "chat-frienditem-shaded";
	private static final String UNSHADED_STYLE_NAME = "chat-frienditem-unshaded";
	private static final String NEW_MESSAGE_STYLE_NAME = "chat-frienditem-newmessage";
	
	private boolean _shaded;
	private HorizontalPanel _panel;
	private ChatDialog _chatDialog;

	private Friend _friend;
	private User _user;
	private Image _image;
	private Image _activeImage;
	private String _backgroundStyle;

	public FriendListItem(User user, Friend friend) {
		_user = user;
		_friend = friend;
		
		Label name = new Label(friend.getName());
		_image = new Image(getActiveImageUrl());

		_panel = new HorizontalPanel();

		if (_friend.isActiveChat()) {
			_activeImage = new Image(getActiveConversationUrl());
			_panel.add(_activeImage);
			_panel.setCellWidth(_activeImage, "30px");
		}
		
		_panel.add(_image);
		_panel.add(name);
		_panel.setCellWidth(_image, "30px");
		_panel.setCellWidth(name, "200px");
		
		FocusPanel focusPanel = new FocusPanel(_panel);
		
		focusPanel.addClickListener(new ClickListener() {

			public void onClick(Widget sender) {
				if (_friend.isActive()) {
					
					_friend.setMessageWaiting(false);
					_friend.setActiveChat(true);
					_friend.setMessageWaiting(false);
					
					System.out.println("You clicked " + _friend.getName());
					if (_chatDialog == null) {
						createChatDialog();
					}
					_chatDialog.show();
				}
			}

			
		});

		initWidget(focusPanel);
	}
	
	public void createChatDialog() {
		_chatDialog = new ChatDialog(_user, _friend);
	}
	
	private String getActiveImageUrl() {
		String url = null;
		
		if (_friend.isActive()) {
			url = ACTIVE_IMAGE_URL;
		} else {
			url = INACTIVE_IMAGE_URL;
		}
		
		return url;
	}
	
	private String getActiveConversationUrl() {
		String url = "";
		if (_friend.isActiveChat()) {
			url = ACTIVE_CONVERSATION;
		} 
		return url;
	}
	
	private void setShadedBackground() {
		if (isShaded()) {
			_backgroundStyle = SHADED_STYLE_NAME;
		} else {
			_backgroundStyle = UNSHADED_STYLE_NAME;
		}
		_panel.setStyleName(_backgroundStyle);
	}

	public void setNewMessageBackground(boolean newMessage) {
		if (newMessage) {
			_panel.setStyleName(NEW_MESSAGE_STYLE_NAME);	
		} else {
			_panel.setStyleName(_backgroundStyle);
		}
	}

	/**
	 * @return
	 */
	public Friend getFriend() {
		return _friend;
	}

	/**
	 * @param friend
	 */
	public void setFriend(Friend friend) {
		_friend = friend;
	}

	public boolean isShaded() {
		return _shaded;
	}

	public void setShaded(boolean shaded) {
		if (_shaded != shaded) {
			_shaded = shaded;
			setShadedBackground();
		}
	}

	public boolean isActive() {
		return _friend.isActive();
}
	public void setActive(boolean active) {
		if (active != _friend.isActive()) {
			_friend.setActive(active);
			
			_image.setUrl(getActiveImageUrl());
		}
	}

	/**
	 * @return the chatDialog
	 */
	public ChatDialog getChatDialog() {
		return _chatDialog;
	}

	/**
	 * @param chatDialog the chatDialog to set
	 */
	public void setChatDialog(ChatDialog chatDialog) {
		_chatDialog = chatDialog;
	}
}
