/***************************************************************************
 * Copyright 2007 Andrew Prunicki <prunand@iit.edu>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **************************************************************************/
package javasig.stl.demo.client;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

/**
 * The timer to fetch the latest start from the server. This includes messages
 * and friends.
 * 
 * @author Andrew Prunicki <prunand@iit.edu>
 * @author Brad Busch <brad.busch@gmail.com>
 */
public class MessageTimer extends Timer {

	private static final int CHECK_FRIENDS_THRESHOLD = 4;

	private User _user;

	private Map _chatDialogPanels;

	private int failCount;

	private int checkFriends;

	private ChatPanel _chatPanel;

	/**
	 * Constructor.
	 * 
	 * @param user
	 */
	public MessageTimer(User user) {
		_user = user;

		_chatDialogPanels = new HashMap();

		scheduleRepeating(1000);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.google.gwt.user.client.Timer#run()
	 */
	public void run() {
		ChatServiceAsync service = (ChatServiceAsync) GWT
				.create(ChatService.class);

		ServiceDefTarget target = (ServiceDefTarget) service;
		target.setServiceEntryPoint(GWT.getModuleBaseURL() + "/service/Chat");

		AsyncCallback messagesCallback = createGetMessagesCallback();
		service.getMessages(_user, messagesCallback);

		if (++checkFriends > CHECK_FRIENDS_THRESHOLD) {
			checkFriends = 0;

			if (_chatPanel != null) {
				System.out.println("getting friends");
				ServiceHelper.getFriends(_user, _chatPanel, null);
			}
		}
	}

	/**
	 * Creates the callback for the getMessages RPC call.
	 * 
	 * @return
	 */
	private AsyncCallback createGetMessagesCallback() {
		AsyncCallback callback = new AsyncCallback() {

			public void onFailure(Throwable caught) {
				failCount++;
				String errorMessage = "Could not receive messages ("
						+ caught.getMessage() + ")";

				if (failCount > 5) {
					MessageTimer.this.cancel();
					errorMessage += " - stopping retrieval.";
				}
				GWT.log(errorMessage, null);
			}

			public void onSuccess(Object result) {
				List messages = (List) result;
				System.out
						.println("Received " + messages.size() + " messages.");

				for (Iterator iter = messages.iterator(); iter.hasNext();) {
					Message message = (Message) iter.next();

					System.out.println("Received message " + message);

					String fromName = message.getFrom().getName();

					ChatDialogPanel panel = (ChatDialogPanel) _chatDialogPanels
							.get(fromName);
					if (panel == null) {
						String toName = message.getTo().getName();

						// No active chat. Check to make sure it was not from
						// me.
						if (fromName.equals(_user.getName())) {
							// It was from me
							panel = (ChatDialogPanel) _chatDialogPanels
									.get(toName);

							if (panel == null) {
								GWT.log("Unknown message received: " + message,
										null);
							} else {
								panel.addMessage(message);
							}
						} else {
							// From someone else, and there is no active chat
							FriendList friends = _chatPanel.getFriendList();
							Friend f = friends.getFriend(fromName);
							if (f == null) {
								GWT.log("Unknown message received: " + message,
										null);
							} else {
								// highlight name in _chatPanel
								f.setMessageWaiting(true);
								_chatPanel.createChatDialog(f);
								panel = (ChatDialogPanel) _chatDialogPanels
										.get(fromName);

								if (panel != null) {
									panel.addMessage(message);
								}
							}
						}
					} else {
						// There already was an active chat with the friend,
						// just add the message
						panel.addMessage(message);
					}
				}
			}

		};
		return callback;
	}

	public void addDialogPanel(ChatDialogPanel panel) {
		System.out.println("adding chat panel for friend "
				+ panel.getFriend().getName());
		_chatDialogPanels.put(panel.getFriend().getName(), panel);
	}

	/**
	 * @return the chatPanel
	 */
	public ChatPanel getChatPanel() {
		return _chatPanel;
	}

	/**
	 * @param chatPanel
	 *            the chatPanel to set
	 */
	public void setChatPanel(ChatPanel chatPanel) {
		_chatPanel = chatPanel;
	}
}
