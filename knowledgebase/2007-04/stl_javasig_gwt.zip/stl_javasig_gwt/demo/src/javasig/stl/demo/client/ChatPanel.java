/***************************************************************************
 * Copyright 2007 Andrew Prunicki <prunand@iit.edu>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **************************************************************************/
package javasig.stl.demo.client;

import java.util.Date;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

/**
 * 
 * @author Andrew Prunicki <prunand@iit.edu>
 * @author Brad Busch <brad.busch@gmail.com>
 */
public class ChatPanel extends Composite {

	private SignInPanel _signInPanel;
	private User _user;
	private RootPanelManager _rootPanelManager;
	private FriendList _friendList;

	/**
	 * Constructor.
	 * 
	 * @param rootPanelManager
	 * @param signInPanel
	 * @param user
	 */
	public ChatPanel(RootPanelManager rootPanelManager, SignInPanel signInPanel, User user) {
		_rootPanelManager = rootPanelManager;
		_signInPanel = signInPanel;
		_user = user;
		HorizontalPanel panel = new HorizontalPanel();

		_friendList = new FriendList(_user);

		panel.add(createLeftPanel(_user, 100, 33));
		panel.add(_friendList);

		initWidget(panel);
	}

	/**
	 * Set the friends into the chat panel.
	 * 
	 * @param friends
	 */
	public void setFriends(List friends) {
		_friendList.mergeFriends(friends);
	}

	/**
	 * Create the left panel.
	 * 
	 * @param user
	 * @param totalFriends
	 * @param onlineFriends
	 * @return the left panel widget
	 */
	private Widget createLeftPanel(User user, int totalFriends,
			int onlineFriends) {
		Button signOut = new Button("Signout");
		addSignOutListener(signOut);
		
		VerticalPanel panel = new VerticalPanel();
		panel.add(new Label("Welcome " + user));
		panel.add(new Label(" "));
		
		Button logButton = new Button("Log to console");
		logButton.addClickListener(new ClickListener() {

			public void onClick(Widget sender) {
				GWT.log("Console log " + new Date(), null);
			}
			
		});
		
		Button jsniButton = new Button("JSNI");
		jsniButton.addClickListener(new ClickListener() {

			public void onClick(Widget sender) {
				alert("Who's buying?");
			}
			
		});
		
		panel.add(logButton);
		panel.add(new Label(" "));
		panel.add(jsniButton);
		panel.add(new Label(" "));
		panel.add(signOut);
		
		panel.setSpacing(10);
		return panel;
	}
	
	/**
	 * Add listener to signout.
	 * 
	 * @param signOut
	 */
	private void addSignOutListener(Button signOut) {
		signOut.addClickListener(new ClickListener() {

			public void onClick(Widget sender) {
				ServiceLocator serviceLocator = ChatRegistry.getInstance().getServiceLocator();
				ChatServiceAsync chatService = serviceLocator.locateChatService();
				
				AsyncCallback callback = new AsyncCallback() {
					
					public void onFailure(Throwable caught) {
						GWT.log("Problem signing out (" + caught.getMessage() + ")", null);
						MessageTimer messageTimer = ChatRegistry.getInstance().getTimer();
						messageTimer.cancel();
						_rootPanelManager.setPanel(_signInPanel);
					}
			
					public void onSuccess(Object result) {
						MessageTimer messageTimer = ChatRegistry.getInstance().getTimer();
						messageTimer.cancel();
						_rootPanelManager.setPanel(_signInPanel);
					}
				};
				
				chatService.signout(_user, callback);
			}
			
		});
	}

	/**
	 * Creates a chat dialog.
	 * 
	 * @param friend
	 */
	public void createChatDialog(Friend friend) {
		FriendListItem friendListItem = _friendList.getFriendListItem(friend);
		
		if (friendListItem.getChatDialog() == null) {
			friendListItem.createChatDialog();
		}
	}
	
	/**
	 * Return the friend list.
	 * 
	 * @return the friend list
	 */
	public FriendList getFriendList() {
		return _friendList;
	}

	/**
	 * Set the friend list
	 * 
	 * @param list
	 */
	public void setFriendList(FriendList list) {
		_friendList = list;
	}

	/**
	 * An example of a JSNI method.  Issues a simple alert.
	 * 
	 * @param msg
	 */
	private static native void alert(String msg) /*-{
	  $wnd.alert(msg);
	}-*/;
}
