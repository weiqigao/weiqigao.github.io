/***************************************************************************
 * Copyright 2007 Andrew Prunicki <prunand@iit.edu>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **************************************************************************/
package javasig.stl.demo.client;

import com.google.gwt.user.client.rpc.IsSerializable;

/**
 * @author Andrew Prunicki <prunand@iit.edu>
 * @author Brad Busch <brad.busch@gmail.com>
 */
public class Friend implements IsSerializable {

	private String _name;
	
	private boolean _active;

	private boolean _messageWaiting;
	
	private boolean _activeChat;
	
	public Friend() {
	}

	public Friend(String name, boolean active) {
		_name = name;
		_active = active;
	}

	public String getName() {
		return _name;
	}

	public void setName(String name) {
		_name = name;
	}

	public boolean isActive() {
		return _active;
	}

	public void setActive(boolean active) {
		_active = active;
	}
	
	public boolean equals(Object o) {
		if (o == this) {
			return true;
		}
		if (!(o instanceof Friend)) {
			return false;
		}
		
		Friend that = (Friend) o;
		
		if (_name == null && that._name == null) {
			return true;
		}
		
		if (_name == null) {
			return false;
		}
		
		return (_name.equals(that._name));
	}
	
	public int hashCode() {
		return _name.hashCode();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return _name + (_active ? "(active)" : "(inactive)") +
			"messageWaiting:" + String.valueOf(_messageWaiting);
	}

	public boolean isMessageWaiting() {
		return _messageWaiting;
	}

	public void setMessageWaiting(boolean messageWaiting) {
		_messageWaiting = messageWaiting;
	}

	public boolean isActiveChat() {
		return _activeChat;
	}

	public void setActiveChat(boolean activeChat) {
		_activeChat = activeChat;
	}
	
}
