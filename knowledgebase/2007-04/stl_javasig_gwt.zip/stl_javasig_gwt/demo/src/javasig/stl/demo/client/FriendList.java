/***************************************************************************
 * Copyright 2007 Andrew Prunicki <prunand@iit.edu>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **************************************************************************/
package javasig.stl.demo.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * @author Andrew Prunicki <prunand@iit.edu>
 * @author Brad Busch <brad.busch@gmail.com>
 * 
 */
public class FriendList extends Composite {

	private VerticalPanel _contentPanel;
	
	private User _user;
	
	private List _friends;
	
	
	public FriendList(User user) {
		_user = user;
		HorizontalPanel outerPanel = new HorizontalPanel();
		outerPanel.setBorderWidth(1);
		_contentPanel = new VerticalPanel();
		ScrollPanel scroll = new ScrollPanel(_contentPanel);
		scroll.setSize("250px", "200px");

		_friends = new ArrayList();
		
		outerPanel.add(scroll);

		initWidget(outerPanel);
	}
	
	public void mergeFriends(List friends) {
		Map sessionFriends = new HashMap();
		for (Iterator iter2 = _friends.iterator(); iter2.hasNext();) {
			Friend friend = (Friend) iter2.next();
			sessionFriends.put(friend.getName(), friend);
		}
		
		//cleaning tempFriend list to maintain client code
		//such as swapping in/out the correct icons
		for (Iterator iter = friends.iterator(); iter.hasNext();) {
			Friend friend = (Friend) iter.next();
			
			Friend sessionFriend = (Friend) sessionFriends.get(friend.getName());
		
			if (sessionFriend == null) {
				sessionFriends.put(friend.getName(), friend);
			} else {
				sessionFriend.setActive(friend.isActive());
			}
		}
		
		_friends.clear();
		_friends.addAll(sessionFriends.values());
		
		int i = 0;
		for (Iterator iter = _friends.iterator(); iter.hasNext();) {
			Friend tempFriend = (Friend) iter.next();
					
			if (!tempFriend.getName().equals(_user.getName())) {
				
				FriendListItem friendListItem = getFriendListItem(tempFriend);
				if (friendListItem == null) {
					friendListItem = addFriend(tempFriend);
				}
				friendListItem.setShaded(i % 2 == 0);

				friendListItem.setActive(tempFriend.isActive());
				friendListItem.setNewMessageBackground(tempFriend.isMessageWaiting());
				
				i++;
			}
		}
		
	}

	/**
	 * This method is not used, but may be a more efficient implementation if
	 * it were updated with the necessary features.
	 * 
	 * @param friends
	 */
	private void mergeFriends2(List friends) {
		//TODO Delete friends no longer on the server
		int i = 0;
		
		for (Iterator iter = friends.iterator(); iter.hasNext();) {
			Friend friend = (Friend) iter.next();
			if (!friend.getName().equals(_user.getName())) {
				FriendListItem findFriend = getFriendListItem(friend);
				
				if (findFriend == null) {
					FriendListItem friendListItem = addFriend(friend);
					friendListItem.setShaded(i % 2 == 0);
				} else {
					findFriend.setActive(friend.isActive());
				}
				i++;
			}
		}
	}

	private FriendListItem addFriend(Friend friend) {
		FriendListItem friendListItem = new FriendListItem(_user, friend);
		_contentPanel.add(friendListItem);
		
		return friendListItem;
	}
	
	public Friend getFriend(String searchName) {
		Friend ret = null;
		
		if (_friends != null) {
			for (Iterator iter = _friends.iterator(); iter.hasNext();) {
				Friend friend = (Friend) iter.next();
				if (friend.getName().equals(searchName)) {
					ret = friend;
				}
			}
		}
		
		return ret;
	}
	
	public FriendListItem getFriendListItem(Friend friend) {
		if (friend == null) {
			throw new IllegalArgumentException("friend cannot be null");
		}
		
		FriendListItem retval = null;
		
		for (int i = 0; i < _contentPanel.getWidgetCount(); i++) {
			FriendListItem friendListItem = (FriendListItem) _contentPanel.getWidget(i);
			Friend currentFriend = friendListItem.getFriend();
			
			if (friend.equals(currentFriend)) {
				retval = friendListItem;
				break;
			}
		}
		
		return retval;
	}
}
