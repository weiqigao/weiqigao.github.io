package com.weiqigao.stlouisjug.earthrise;

import javafx.animation.Interpolator;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.animation.TranslateTransitionBuilder;
import javafx.application.Application;
import javafx.geometry.VPos;
import javafx.scene.GroupBuilder;
import javafx.scene.Scene;
import javafx.scene.SceneBuilder;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPaneBuilder;
import javafx.scene.image.Image;
import javafx.scene.image.ImageViewBuilder;
import javafx.scene.paint.Color;
import javafx.scene.shape.RectangleBuilder;
import javafx.scene.text.*;
import javafx.stage.Stage;
import javafx.util.Duration;

import javax.swing.plaf.metal.MetalBorders;

public class HelloEarthriseWithPannableScrollPane extends Application {
    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        String message = "Earthrise at Christmas: " +
            "[Forty] years ago this Christmas, a turbulent world " +
            "looked to the heavens for a unique view of our home " +
            "planet.  This photo of Earthrise over the lunar horizon " +
            "was taken by the Apollo 8 crew in December 1968, showing " +
            "Earth for the first time as it appears from deep space.  " +
            "Astronauts Frank Borman, Jim Lowell and William Anders " +
            "had become the first humans to leave Earth orbit, " +
            "entering lunar orbit on Christmas Eve.  In a historic live " +
            "broadcast that night, the crew took turns reading from " +
            "the book of Genesis, closing with holiday wish from " +
            "Commander Borman: \"We close with good night, good luck, " +
            "a Merry Christmas, and God bless all of you -- all of " +
            "you on the good Earth.\"";

        Text text = TextBuilder.create()
            .layoutY(100)
            .textOrigin(VPos.TOP)
            .textAlignment(TextAlignment.JUSTIFY)
            .wrappingWidth(400)
            .text(message)
            .fill(Color.rgb(187, 195, 107))
            .font(Font.font("SansSerif", FontWeight.BOLD, 24))
            .build();

        TranslateTransition translateTransition = TranslateTransitionBuilder.create()
            .duration(Duration.seconds(75))
            .node(text)
            .toY(-820)
            .interpolator(Interpolator.LINEAR)
            .cycleCount(Timeline.INDEFINITE)
            .build();

        Scene scene = SceneBuilder.create()
            .width(516)
            .height(387)
            .root(GroupBuilder.create()
                .children(
                    ImageViewBuilder.create()
                        .image(new Image("http://projavafx.com/images/earthrise.jpg"))
                        .build(),
                    ScrollPaneBuilder.create()
                        .layoutX(50)
                        .layoutY(180)
                        .prefWidth(440)
                        .prefHeight(85)
                        .hbarPolicy(ScrollPane.ScrollBarPolicy.NEVER)
                        .vbarPolicy(ScrollPane.ScrollBarPolicy.NEVER)
                        .pannable(true)
                        .content(text)
                        .style("-fx-background-color: transparent;")
                        .build()
                )
                .build())
            .build();

        stage.setScene(scene);
        stage.setTitle("Hello Earthrise");
        stage.show();

        translateTransition.play();

    }
}
