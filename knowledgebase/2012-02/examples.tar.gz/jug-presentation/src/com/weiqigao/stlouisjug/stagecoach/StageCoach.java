package com.weiqigao.stlouisjug.stagecoach;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Rectangle2D;
import javafx.geometry.VPos;
import javafx.scene.Group;
import javafx.scene.GroupBuilder;
import javafx.scene.Scene;
import javafx.scene.SceneBuilder;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBoxBuilder;
import javafx.scene.layout.VBoxBuilder;
import javafx.scene.paint.Color;
import javafx.scene.shape.RectangleBuilder;
import javafx.scene.text.Text;
import javafx.scene.text.TextBuilder;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;

import java.util.Map;

public class StageCoach extends Application {
    StringProperty title = new SimpleStringProperty();

    Text stageX;
    Text stageY;
    Text stageW;
    Text stageH;
    Text stageF;
    CheckBox resizable;
    CheckBox fullScreen;

    double dragAnchorX;
    double dragAnchorY;

    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        StageStyle stageStyle = StageStyle.DECORATED;
        Map<String, String> namedParameters = getParameters().getNamed();
        String stageStyleString = namedParameters.get("stageStyle");
        if (stageStyleString != null) {
            StageStyle style = StageStyle.valueOf(stageStyleString);
            stageStyle = style;
        }

        final Stage stageRef = stage;
        final Group root;
        final TextField titleField;

        Scene scene = SceneBuilder.create()
            .width(270)
            .height(370)
            .fill(Color.TRANSPARENT)
            .root(root = GroupBuilder.create()
                .children(
                    RectangleBuilder.create()
                        .layoutX(10)
                        .layoutY(10)
                        .width(250)
                        .height(350)
                        .arcWidth(50)
                        .arcHeight(50)
                        .fill(Color.SKYBLUE)
                        .build(),
                    VBoxBuilder.create()
                        .layoutX(30)
                        .layoutY(20)
                        .spacing(10)
                        .children(
                            stageX = TextBuilder.create()
                                .textOrigin(VPos.TOP)
                                .build(),
                            stageY = TextBuilder.create()
                                .textOrigin(VPos.TOP)
                                .build(),
                            stageW = TextBuilder.create()
                                .textOrigin(VPos.TOP)
                                .build(),
                            stageH = TextBuilder.create()
                                .textOrigin(VPos.TOP)
                                .build(),
                            stageF = TextBuilder.create()
                                .textOrigin(VPos.TOP)
                                .build(),
                            resizable = CheckBoxBuilder.create()
                                .text("resizable")
                                .disable(stageStyle == StageStyle.TRANSPARENT ||
                                    stageStyle == StageStyle.UNDECORATED)
                                .build(),
                            fullScreen = CheckBoxBuilder.create()
                                .text("fullScreen")
                                .build(),
                            HBoxBuilder.create()
                                .spacing(10)
                                .children(
                                    new Label("title: "),
                                    titleField = TextFieldBuilder.create()
                                        .text("Stage Coach")
                                        .prefColumnCount(15)
                                        .build()
                                )
                                .build(),
                            ButtonBuilder.create()
                                .text("toBack()")
                                .onAction(new EventHandler<ActionEvent>() {
                                    @Override
                                    public void handle(ActionEvent actionEvent) {
                                        stageRef.toBack();
                                    }
                                })
                                .build(),
                            ButtonBuilder.create()
                                .text("toFront()")
                                .onAction(new EventHandler<ActionEvent>() {
                                    @Override
                                    public void handle(ActionEvent actionEvent) {
                                        stageRef.toFront();
                                    }
                                })
                                .build(),
                            ButtonBuilder.create()
                                .text("close()")
                                .onAction(new EventHandler<ActionEvent>() {
                                    @Override
                                    public void handle(ActionEvent actionEvent) {
                                        stageRef.close();
                                    }
                                })
                                .build()
                        )
                        .build()
                )
                .build()
            ).build();
        root.setOnMousePressed(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                dragAnchorX = mouseEvent.getScreenX() - stageRef.getX();
                dragAnchorY = mouseEvent.getScreenY() - stageRef.getY();
            }
        });

        root.setOnMouseDragged(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                stageRef.setX(mouseEvent.getScreenX() - dragAnchorX);
                stageRef.setY(mouseEvent.getScreenY() - dragAnchorY);
            }
        });

        stageX.textProperty().bind(new SimpleStringProperty("x: ").concat(stageRef.xProperty().asString()));
        stageY.textProperty().bind(new SimpleStringProperty("y: ").concat(stageRef.yProperty().asString()));
        stageW.textProperty().bind(new SimpleStringProperty("width: ").concat(stageRef.widthProperty().asString()));
        stageH.textProperty().bind(new SimpleStringProperty("height: ").concat(stageRef.heightProperty().asString()));
        stageF.textProperty().bind(new SimpleStringProperty("focused: ").concat(stageRef.focusedProperty().asString()));

        stage.setResizable(true);
        resizable.selectedProperty().bindBidirectional(stage.resizableProperty());
        fullScreen.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean oldValue, Boolean newValue) {
                stageRef.setFullScreen(fullScreen.selectedProperty().get());
            }
        });

        title.bind(titleField.textProperty());

        stage.setScene(scene);
        stage.titleProperty().bind(title);
        stage.initStyle(stageStyle);
        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                System.out.println("Stage is closing");
            }
        });
        stage.show();

        Rectangle2D primScreenBounds = Screen.getPrimary().getVisualBounds();
        stage.setX((primScreenBounds.getWidth() - stage.getWidth()) / 2);
        stage.setY((primScreenBounds.getHeight() - stage.getHeight()) / 4);
    }
}
