package com.weiqigao.stlouisjug.audioconfig;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.SingleSelectionModel;

public class AudioConfigModel {
    public double minDecibels = 0.0;
    public double maxDecibels = 160.0;
    public ObservableList<String> genres = FXCollections.observableArrayList(
        "Chamber",
        "Country",
        "Cowbell",
        "Mental",
        "Polka",
        "Rock"
    );
    public IntegerProperty selectedDbs = new SimpleIntegerProperty(0);
    public BooleanProperty muting = new SimpleBooleanProperty(false);
    public SingleSelectionModel<String> genreSelectionModel;

    public void addListenerToGenreSelectionModel() {
        genreSelectionModel.selectedIndexProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number oldValue, Number newValue) {
                int selectedIndex = genreSelectionModel.selectedIndexProperty().get();
                switch (selectedIndex) {
                    case 0:
                        selectedDbs.set(80);
                        break;
                    case 1:
                        selectedDbs.set(100);
                        break;
                    case 2:
                        selectedDbs.set(150);
                        break;
                    case 3:
                        selectedDbs.set(140);
                        break;
                    case 4:
                        selectedDbs.set(120);
                        break;
                    case 5:
                        selectedDbs.set(130);
                        break;
                    default:
                        selectedDbs.set(100);
                }
            }
        });
    }
}
