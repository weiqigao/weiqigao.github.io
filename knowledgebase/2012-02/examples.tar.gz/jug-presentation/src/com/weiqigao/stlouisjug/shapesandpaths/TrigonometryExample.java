package com.weiqigao.stlouisjug.shapesandpaths;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.animation.TimelineBuilder;
import javafx.application.Application;
import javafx.beans.binding.DoubleBinding;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * @author Weiqi Gao
 */
public class TrigonometryExample extends Application {
    private DoubleProperty angle = new SimpleDoubleProperty(0.0);

    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("Trigonometry Example");
        stage.setScene(makeScene());
        stage.show();
        animate();
    }

    private void animate() {
        TimelineBuilder.create()
            .cycleCount(Timeline.INDEFINITE)
            .autoReverse(false)
            .keyFrames(
                new KeyFrame(Duration.seconds(60), new KeyValue(angle, 2 * Math.PI))
            )
            .build()
            .play();
    }

    private Scene makeScene() {
        Group group = new Group();

        Line xAxis = LineBuilder.create()
            .startX(-320.0)
            .startY(0.0)
            .endX(320.0)
            .endY(0.0)
            .stroke(Color.GRAY)
            .build();
        
        Line yAxis = LineBuilder.create()
            .startX(0.0)
            .startY(-240)
            .endX(0.0)
            .endY(240.0)
            .stroke(Color.GRAY)
            .build(); 
            
        Circle unitCircle = CircleBuilder.create()
            .centerX(0.0)
            .centerY(0.0)
            .radius(200.0)
            .stroke(Color.GRAY)
            .fill(Color.TRANSPARENT)
            .build();

        Arc arc = ArcBuilder.create()
            .centerX(0.0)
            .centerY(0.0)
            .radiusX(200.0)
            .radiusY(200.0)
            .startAngle(0.0)
            .length(0.0)
            .type(ArcType.OPEN)
            .strokeWidth(5)
            .stroke(Color.STEELBLUE)
            .fill(Color.TRANSPARENT)
            .build();

        Line tangentLine =LineBuilder.create()
            .startX(200.0)
            .startY(-240.0)
            .endX(200.0)
            .endY(240.0)
            .stroke(Color.GRAY)
            .build(); 
            
        Line cotangentLine = LineBuilder.create()
            .startX(-320.0)
            .startY(200.0)
            .endX(320.0)
            .endY(200.0)
            .stroke(Color.GRAY)
            .build(); 
            
        Line ray = LineBuilder.create()
            .startX(-320.0)
            .startY(0.0)
            .endX(320.0)
            .endY(0.0)
            .stroke(Color.GRAY)
            .build();

        Line radius = LineBuilder.create()
            .startX(0.0)
            .startY(0.0)
            .endX(200.0)
            .endY(0.0)
            .strokeWidth(3)
            .stroke(Color.PURPLE)
            .build();

        Line sine = LineBuilder.create()
            .startX(200.0)
            .startY(0.0)
            .endX(200.0)
            .endY(0.0)
            .strokeWidth(3)
            .stroke(Color.RED)
            .build();

        Line cosine = LineBuilder.create()
            .startX(0.0)
            .startY(0.0)
            .endX(200.0)
            .endY(0.0)
            .strokeWidth(3)
            .stroke(Color.BLUE)
            .build();

        Line tangent = LineBuilder.create()
            .startX(200.0)
            .startY(0.0)
            .endX(200.0)
            .endY(0.0)
            .strokeWidth(3)
            .stroke(Color.GREEN)
            .build();

        group.getChildren().addAll(xAxis, yAxis, unitCircle, arc, tangentLine, cotangentLine, ray, radius, sine, cosine, tangent);
        group.setTranslateX(320);
        group.setTranslateY(240);
        group.setScaleY(-1);

        ray.startYProperty().bind(new DoubleBinding() {
            {
                super.bind(angle);
            }

            @Override
            protected double computeValue() {
                return -320 * Math.tan(angle.get());
            }
        });
        ray.endYProperty().bind(new DoubleBinding() {
            {
                super.bind(angle);
            }

            @Override
            protected double computeValue() {
                return 320 * Math.tan(angle.get());
            }
        });

        radius.endXProperty().bind(new DoubleBinding() {
            {
                super.bind(angle);
            }

            @Override
            protected double computeValue() {
                return 200.0 * Math.cos(angle.get());
            }
        });

        radius.endYProperty().bind(new DoubleBinding() {
            {
                super.bind(angle);
            }

            @Override
            protected double computeValue() {
                return 200.0 * Math.sin(angle.get());
            }
        });

        arc.lengthProperty().bind(new DoubleBinding() {
            {
                super.bind(angle);
            }

            @Override
            protected double computeValue() {
                return -angle.get() * 180 / Math.PI;
            }
        });

        sine.startXProperty().bind(new DoubleBinding() {
            {
                super.bind(angle);
            }

            @Override
            protected double computeValue() {
                return 200 * Math.cos(angle.get());
            }
        });

        sine.endXProperty().bind(new DoubleBinding() {
            {
                super.bind(angle);
            }

            @Override
            protected double computeValue() {
                return 200 * Math.cos(angle.get());
            }
        });

        sine.endYProperty().bind(new DoubleBinding() {
            {
                super.bind(angle);
            }

            @Override
            protected double computeValue() {
                return 200 * Math.sin(angle.get());
            }
        });

        cosine.endXProperty().bind(new DoubleBinding() {
            {
                super.bind(angle);
            }

            @Override
            protected double computeValue() {
                return 200 * Math.cos(angle.get());
            }
        });

        tangent.endYProperty().bind(new DoubleBinding() {
            {
                super.bind(angle);
            }

            @Override
            protected double computeValue() {
                return 200 * Math.tan(angle.get());
            }
        });

        return new Scene(group, 640, 480, Color.WHEAT);
    }
}
