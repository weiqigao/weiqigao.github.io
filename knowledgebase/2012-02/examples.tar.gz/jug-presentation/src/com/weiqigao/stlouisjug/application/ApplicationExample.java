package com.weiqigao.stlouisjug.application;

import javafx.application.Application;
import javafx.stage.Stage;

import java.util.List;
import java.util.Map;

/**
 * @author Weiqi Gao
 */
public class ApplicationExample extends Application {
    public static void main(String[] args) {
        Application.launch(ApplicationExample.class, args);
    }

    public ApplicationExample() {
        System.out.println("Constructor called in \"" + Thread.currentThread().getName() + "\" thread");
    }

    @Override
    public void init() throws Exception {
        System.out.println("init() called in \"" + Thread.currentThread().getName() + "\" thread");
        Parameters parameters = getParameters();
        Map<String, String> named = parameters.getNamed();
        System.out.println("named parameters = " + named);
        List<String> unnamed = parameters.getUnnamed();
        System.out.println("unnamed parameters = " + unnamed);
    }

    @Override
    public void start(Stage stage) throws Exception {
        System.out.println("start() called in \"" + Thread.currentThread().getName() + "\" thread");
        stage.setTitle("Application Example");
        stage.setWidth(640);
        stage.setHeight(480);
        stage.show();
    }

    @Override
    public void stop() throws Exception {
        System.out.println("stop() called in \"" + Thread.currentThread().getName() + "\" thread");
    }
}
