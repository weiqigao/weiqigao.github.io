package com.weiqigao.stlouisjug.reversi;

import javafx.application.Application;
import javafx.scene.SceneBuilder;
import javafx.scene.layout.StackPaneBuilder;
import javafx.stage.Stage;

public class ReversiSquareTest extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        stage.setScene(SceneBuilder.create()
            .root(StackPaneBuilder.create()
                .children(new ReversiSquare(0, 0))
                .build())
            .build());
        stage.show();
    }
}
