package com.weiqigao.stlouisjug.scene3d;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.animation.TimelineBuilder;
import javafx.application.Application;
import javafx.geometry.Point3DBuilder;
import javafx.scene.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.PolygonBuilder;
import javafx.scene.shape.RectangleBuilder;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.RotateBuilder;
import javafx.scene.transform.Transform;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * @author Weiqi Gao
 */
public class ThreeDSceneExample extends Application {
    private Rotate rotate;
    
    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("3D Scene Example");
        stage.setScene(makeScene());
        stage.show();
        TimelineBuilder.create()
            .cycleCount(Timeline.INDEFINITE)
            .autoReverse(false)
            .keyFrames(new KeyFrame(Duration.seconds(3), new KeyValue(rotate.angleProperty(), 360)))
                .build().play();
    }

    private Scene makeScene() {
        Scene scene = SceneBuilder.create()
            .depthBuffer(true)
            .camera(PerspectiveCameraBuilder.create()
                .build())
            .root(GroupBuilder.create()
                .children(
                    RectangleBuilder.create()
                        .x(0)
                        .y(0)
                        .width(640)
                        .height(480)
                        .fill(Color.WHITE)
                        .build(),
                    RectangleBuilder.create()
                        .x(100)
                        .y(100)
                        .width(50)
                        .height(50)
                        .transforms(rotate = RotateBuilder.create()
                            .axis(Point3DBuilder.create()
                                .x(100)
                                .y(100)
                                .z(0)
                                .build())
                            .build())
                        .build()
                )
                .build())
            .build();
        return scene;
    }
}
