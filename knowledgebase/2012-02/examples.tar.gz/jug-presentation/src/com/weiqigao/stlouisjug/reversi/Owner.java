package com.weiqigao.stlouisjug.reversi;


import javafx.scene.paint.Color;

public enum Owner {
    NONE,
    WHITE,
    BLACK;

    public Owner opposite() {
        return this == WHITE ? BLACK : this == BLACK ? WHITE : NONE;
    }

    public Color getColor() {
        return this == WHITE ? Color.WHITE : Color.BLACK;
    }

    public String getColorStyle() {
        return this == WHITE ? "white" : "black";
    }

}
