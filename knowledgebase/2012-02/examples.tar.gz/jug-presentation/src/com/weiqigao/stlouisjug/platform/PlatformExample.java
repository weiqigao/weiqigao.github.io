package com.weiqigao.stlouisjug.platform;

import com.sun.javafx.scene.control.behavior.TextAreaBehavior;
import javafx.application.Application;
import javafx.application.ConditionalFeature;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.GroupBuilder;
import javafx.scene.Scene;
import javafx.scene.SceneBuilder;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextAreaBuilder;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderPaneBuilder;
import javafx.scene.layout.StackPaneBuilder;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.util.List;
import java.util.Map;

/**
 * @author Weiqi Gao
 */
public class PlatformExample extends Application implements EventHandler<WindowEvent> {
    private TextArea textArea;

    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("Platform Example");
        stage.setScene(makeScene());
        stage.setOnCloseRequest(this);
        stage.show();
    }

    private Scene makeScene() {
        Scene scene = SceneBuilder.create()
            .root(BorderPaneBuilder.create()
                .center(textArea = TextAreaBuilder.create()
                    .text(resultStringOfCallingPlatformMethods())
                    .build())
                .build())
            .build();
        return scene;
    }

    private String resultStringOfCallingPlatformMethods() {
        StringBuilder sb = new StringBuilder("Platform.isFxApplicationThread() = ")
            .append(Platform.isFxApplicationThread())
            .append("\n");
        for (ConditionalFeature conditionalFeature : ConditionalFeature.values()) {
            if (Platform.isSupported(conditionalFeature)) {
                sb.append(conditionalFeature.toString() + " is supported\n");
            } else {
                sb.append(conditionalFeature.toString() + " is not supported\n");
            }
        }
        return sb.toString();
    }

    @Override
    public void handle(WindowEvent windowEvent) {
        Platform.exit();
    }
}
