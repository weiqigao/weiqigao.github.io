package com.weiqigao.stlouisjug.charts;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.SceneBuilder;
import javafx.scene.chart.*;
import javafx.scene.layout.StackPaneBuilder;
import javafx.stage.Stage;
import javafx.util.StringConverter;

/**
 * @author Weiqi Gao
 */
public class BubbleChartExample extends Application {
    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("Bubble Chart");
        stage.setScene(nameScene());
        stage.show();
    }

    private Scene nameScene() {
        NumberAxis xAxis = new NumberAxis();
        xAxis.setAutoRanging(false);
        xAxis.setLowerBound(0);
        xAxis.setUpperBound(10);
        
        NumberAxis yAxis = new NumberAxis();
        xAxis.setAutoRanging(false);
        xAxis.setLowerBound(0);
        xAxis.setUpperBound(10);

        BubbleChart bubbleChart = new BubbleChart(xAxis, yAxis);
        
        Scene scene = SceneBuilder.create()
            .width(480)
            .height(480)
            .root(StackPaneBuilder.create()
                .children(bubbleChart)
                .build())
            .build();
        bubbleChart.setData(getChartData());
        return scene;
    }

    public ObservableList<XYChart.Series> getChartData() {
        XYChart.Series series1 = new XYChart.Series();
        series1.setName("First Series");
        series1.getData().add(new XYChart.Data(2, 2, 0.5));
        series1.getData().add(new XYChart.Data(4, 4, 0.6));
        series1.getData().add(new XYChart.Data(6, 6, 0.7));
        series1.getData().add(new XYChart.Data(8, 8, 0.8));

        XYChart.Series series2 = new XYChart.Series();
        series2.setName("Second Series");
        series2.getData().add(new XYChart.Data(2, 8, 0.5));
        series2.getData().add(new XYChart.Data(4, 6, 0.6));
        series2.getData().add(new XYChart.Data(6, 4, 0.7));
        series2.getData().add(new XYChart.Data(8, 2, 0.8));

        XYChart.Series series3 = new XYChart.Series();
        series3.setName("Third Series");
        series3.getData().add(new XYChart.Data(2, 5, 0.5));
        series3.getData().add(new XYChart.Data(4, 5, 0.6));
        series3.getData().add(new XYChart.Data(6, 5, 0.7));
        series3.getData().add(new XYChart.Data(8, 5, 0.8));

        return FXCollections.observableArrayList(series1, series2, series3);

    }
}
