package com.weiqigao.stlouisjug.onthescene;


import com.sun.javafx.scene.control.behavior.SliderBehavior;
import javafx.application.Application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.VPos;
import javafx.scene.Cursor;
import javafx.scene.ParallelCamera;
import javafx.scene.Scene;
import javafx.scene.SceneBuilder;
import javafx.scene.control.*;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.FlowPaneBuilder;
import javafx.scene.layout.HBoxBuilder;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextBuilder;
import javafx.scene.transform.Affine;
import javafx.scene.transform.Transform;
import javafx.stage.Stage;

public class OnTheScene extends Application {
    private DoubleProperty fillVals = new SimpleDoubleProperty(255.0);
    private Scene scene;
    private ObservableList<Cursor> cursors = FXCollections.observableArrayList(
        Cursor.DEFAULT,
        Cursor.CROSSHAIR,
        Cursor.WAIT,
        Cursor.TEXT,
        Cursor.HAND,
        Cursor.OPEN_HAND,
        Cursor.CLOSED_HAND,
        Cursor.MOVE,
        Cursor.N_RESIZE,
        Cursor.NE_RESIZE,
        Cursor.E_RESIZE,
        Cursor.SE_RESIZE,
        Cursor.S_RESIZE,
        Cursor.SW_RESIZE,
        Cursor.W_RESIZE,
        Cursor.NW_RESIZE,
        Cursor.NONE,
        Cursor.DISAPPEAR
    );

    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        Slider slider;
        ChoiceBox<Cursor> choiceBox;
        Text sceneX;
        Text sceneY;
        Text sceneW;
        Text sceneH;
        Label stageX;
        Label stageY;
        Label stageW;
        Label stageH;

        final ToggleGroup toggleGroup = new ToggleGroup();

        FlowPane root = FlowPaneBuilder.create()
            .layoutX(20)
            .layoutY(40)
            .padding(new Insets(0, 20, 40, 0))
            .orientation(Orientation.VERTICAL)
            .vgap(10)
            .hgap(20)
            .columnHalignment(HPos.LEFT)
            .children(
                HBoxBuilder.create()
                    .spacing(10)
                    .children(
                        slider = SliderBuilder.create()
                            .min(0)
                            .max(255)
                            .value(255)
                            .orientation(Orientation.VERTICAL)
                            .build(),
                        choiceBox = ChoiceBoxBuilder.<Cursor>create()
                            .items(cursors)
                            .build())
                    .build(),
                sceneX = TextBuilder.create()
                    .styleClass("emphasized-text")
                    .build(),
                sceneY = TextBuilder.create()
                    .styleClass("emphasized-text")
                    .build(),
                sceneW = TextBuilder.create()
                    .styleClass("emphasized-text")
                    .build(),
                sceneH = TextBuilder.create()
                    .styleClass("emphasized-text")
                    .id("sceneHeightText")
                    .build(),
                HyperlinkBuilder.create()
                    .text("lookup()")
                    .onAction(new EventHandler<ActionEvent>() {
                        @Override
                        public void handle(ActionEvent actionEvent) {
                            System.out.println("scene: " + scene);
                            Text text = (Text) scene.lookup("#sceneHeightText");
                            System.out.println(text.getText());
                        }
                    })
                    .build(),
                RadioButtonBuilder.create()
                    .text("onTheScene.css")
                    .toggleGroup(toggleGroup)
                    .selected(true)
                    .build(),
                RadioButtonBuilder.create()
                    .text("changeOfScene.css")
                    .toggleGroup(toggleGroup)
                    .build(),
                stageX = LabelBuilder.create()
                    .id("stageX")
                    .build(),
                stageY = LabelBuilder.create()
                    .id("stageY")
                    .build(),
                stageW = new Label(),
                stageH = new Label()
            )
            .build();

        ParallelCamera parallelCamera = new ParallelCamera();
        scene = SceneBuilder.create()
            .width(600)
            .height(250)
            .root(root)
            .build();
        
        scene.getStylesheets().addAll(OnTheScene.class.getResource("onTheScene.css").toExternalForm());
        
        stage.setScene(scene);
        
        choiceBox.getSelectionModel().selectFirst();
        
        sceneX.textProperty().bind(new SimpleStringProperty("Scene x: ").concat(scene.xProperty().asString()));
        sceneY.textProperty().bind(new SimpleStringProperty("Scene y: ").concat(scene.yProperty().asString()));
        sceneW.textProperty().bind(new SimpleStringProperty("Scene width: ").concat(scene.widthProperty().asString()));
        sceneH.textProperty().bind(new SimpleStringProperty("Scene height: ").concat(scene.heightProperty().asString()));
        
        stageX.textProperty().bind(new SimpleStringProperty("Stage x: ").concat(scene.getWindow().xProperty().asString()));
        stageY.textProperty().bind(new SimpleStringProperty("Stage y: ").concat(scene.getWindow().yProperty().asString()));
        stageW.textProperty().bind(new SimpleStringProperty("Stage width: ").concat(scene.getWindow().widthProperty().asString()));
        stageH.textProperty().bind(new SimpleStringProperty("Stage height: ").concat(scene.getWindow().heightProperty().asString()));
        
        scene.cursorProperty().bind(choiceBox.getSelectionModel().selectedItemProperty());
        
        fillVals.bind(slider.valueProperty());
        fillVals.addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number oldValue, Number newValue) {
                double fillValue = newValue.doubleValue() / 256.0;
                scene.setFill(new Color(fillValue, fillValue, fillValue, 1.0));
            }
        });
        
        toggleGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
            @Override
            public void changed(ObservableValue<? extends Toggle> observableValue, Toggle oldValue, Toggle newValue) {
                String radioButtonText = ((RadioButton) newValue).getText();
                scene.getStylesheets().addAll(OnTheScene.class.getResource(radioButtonText).toExternalForm());
            }
        });

        stage.setTitle("On The Scene");
        stage.show();
        
        Text added = TextBuilder.create()
            .layoutX(0)
            .layoutY(-30)
            .textOrigin(VPos.TOP)
            .fill(Color.BLUE)
            .font(Font.font("SansSerif", FontWeight.BOLD, 16))
            .managed(false)
            .build();
        
        added.textProperty().bind(new SimpleStringProperty("Scene fill: ").concat(scene.fillProperty()));
        
        ((FlowPane) scene.getRoot()).getChildren().add(added);
        
    }
}
