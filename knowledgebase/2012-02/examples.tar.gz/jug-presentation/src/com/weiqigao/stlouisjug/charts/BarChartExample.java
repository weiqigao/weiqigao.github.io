package com.weiqigao.stlouisjug.charts;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 * @author Weiqi Gao
 */
public class BarChartExample extends Application {
    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        PieChart pieChart = new PieChart();
        pieChart.setData(getChartData());
        stage.setTitle("Pie Chart Example");
        StackPane root = new StackPane();
        root.getChildren().add(pieChart);
        stage.setScene(new Scene(root, 480, 480));
        stage.show();
    }

    public ObservableList<PieChart.Data> getChartData() {
        ObservableList<PieChart.Data> answer = FXCollections.observableArrayList();
        answer.addAll(
            new PieChart.Data("Java", 17.56),
            new PieChart.Data("C", 17.06),
            new PieChart.Data("C++", 8.25),
            new PieChart.Data("C#", 8.20),
            new PieChart.Data("Objective-C", 6.8),
            new PieChart.Data("PHP", 6.0),
            new PieChart.Data("(Visual)Basic", 4.76),
            new PieChart.Data("Other", 31.37)
        );
        return answer;
    }
}
