package com.weiqigao.stlouisjug.effects;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.effect.Light;
import javafx.scene.effect.Lighting;
import javafx.scene.effect.Reflection;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * @author Weiqi Gao
 */
public class EffectsExample extends Application {
    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("Scene Graph Example");
        stage.setScene(makeScene());
        stage.show();
    }

    private Scene makeScene() {
        Text text = new Text(70, 200, "Hello JavaFX");
        text.setFont(Font.font("SansSerif", FontWeight.BOLD, FontPosture.ITALIC, 72));
        text.setStroke(Color.ROYALBLUE);
        text.setFill(Color.ROYALBLUE);

        Light.Distant light = new Light.Distant();
        light.setAzimuth(-135.0f);
        Lighting l = new Lighting(light);
        l.setSurfaceScale(1.0f);

        text.setEffect(l);
        Group root = new Group(text);
        return new Scene(root, 640, 400, Color.LIGHTSLATEGRAY);
    }
}
