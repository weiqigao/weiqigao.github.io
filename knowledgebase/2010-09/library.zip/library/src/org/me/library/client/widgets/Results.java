package org.me.library.client.widgets;

import java.util.Arrays;
import java.util.Date;

import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.view.client.HasData;
import com.google.gwt.view.client.ListDataProvider;

import org.me.library.client.pojo.Book;
import org.me.library.client.pojo.SearchResult;

public final class Results implements ValueChangeHandler<SearchResult>{
	private final ListDataProvider<Book> provider;
	
	
	public Results() {
		super();
		this.provider = new ListDataProvider<Book>();
		Book book1 = new Book();
		book1.setAuthor("Scott Fines");
		book1.setTitle("The history of Dragons");
		book1.setDescription("This is a dramatic book detailing the history of Dragons through the ages");
		book1.setSubject("Dragons");
		book1.setPublicationDate(new Date());
		
		Book book2 = new Book();
		book2.setAuthor("Bob Lee");
		book2.setTitle("Programming Android");
		book2.setDescription("This is a book about programming in the Android SDK");
		book2.setSubject("Android");
		book2.setPublicationDate(new Date());
		provider.setList(Arrays.asList(book1,book2));
	}

	public void setView(View view){
		provider.addDataDisplay(view.getDataDisplay());
	}

	public void onValueChange(ValueChangeEvent<SearchResult> event) {
		SearchResult result = event.getValue();
		
		provider.setList(result.getBooks());
	}
	
	interface View{
		HasData<Book> getDataDisplay();
	}

}
