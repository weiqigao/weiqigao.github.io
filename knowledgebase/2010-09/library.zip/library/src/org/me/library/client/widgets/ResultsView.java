package org.me.library.client.widgets;

import org.me.library.client.pojo.Book;

import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.cellview.client.SimplePager;
import com.google.gwt.user.cellview.client.TextColumn;
import com.google.gwt.user.cellview.client.SimplePager.TextLocation;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.view.client.HasData;

public final class ResultsView extends Composite implements Results.View{
	private static DateTimeFormat dateFormatter = DateTimeFormat.getFormat(DateTimeFormat.PredefinedFormat.YEAR);
	private static ResultsViewUiBinder uiBinder = GWT
			.create(ResultsViewUiBinder.class);

	interface ResultsViewUiBinder extends UiBinder<Widget, ResultsView> {
	}

	@UiField CellTable<Book> cellTable;
	@UiField SimplePager cellPager;
	
	public ResultsView() {
		initWidget(uiBinder.createAndBindUi(this));
		TextColumn<Book> titleColumn = new TextColumn<Book>(){

			@Override
			public String getValue(Book object) {
				return object.getTitle();
			}
		};
		
		TextColumn<Book> authorColumn = new TextColumn<Book>(){

			@Override
			public String getValue(Book object) {
				return object.getAuthor();
			}
		};
		
		TextColumn<Book> pubDateColumn = new TextColumn<Book>(){

			@Override
			public String getValue(Book object) {
				return dateFormatter.format(object.getPublicationDate());
			}
		};
		
		cellTable.addColumn(titleColumn);
		cellTable.addColumn(authorColumn);
	}

	public HasData<Book> getDataDisplay() {
		return cellTable;
	}

}
