package org.me.library.client.widgets;

import com.google.gwt.core.client.GWT;
import com.google.gwt.resources.client.CssResource;

public interface LibraryCss extends CssResource {
	LibraryCss INSTANCE = GWT.create(LibraryCss.class);

	@ClassName("italic")
	String italic();

}
