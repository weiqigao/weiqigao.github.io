package org.me.library.client.widgets;

import com.google.gwt.core.client.GWT;
import com.google.gwt.resources.client.ClientBundle;

public interface LibraryClientBundle extends ClientBundle {
	public static final LibraryClientBundle INSTANCE = GWT.create(LibraryClientBundle.class);	
	

	@Source("library.css")
	LibraryCss library();

}
