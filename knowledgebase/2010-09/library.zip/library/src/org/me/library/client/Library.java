package org.me.library.client;

import org.me.library.client.widgets.LibraryClientBundle;
import org.me.library.client.widgets.LibraryCss;
import org.me.library.client.widgets.Results;
import org.me.library.client.widgets.ResultsView;


import com.google.gwt.app.place.PlaceController;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.event.shared.EventBus;
import com.google.gwt.event.shared.HandlerManager;
import com.google.gwt.user.client.ui.RootLayoutPanel;


/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class Library implements EntryPoint {
	/**
	 * The message displayed to the user when the server cannot be reached or
	 * returns an error.
	 */
	private static final String SERVER_ERROR = "An error occurred while "
			+ "attempting to contact the server. Please check your network "
			+ "connection and try again.";

	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		LibraryCss css = LibraryClientBundle.INSTANCE.library();
		css.ensureInjected();
		
		EventBus eventBus = new HandlerManager(null);
		PlaceController controller = new PlaceController(eventBus);
		
		Results results = new Results();
		
		ResultsView resultsView = new ResultsView();
		results.setView(resultsView);
		
		RootLayoutPanel.get().add(resultsView);
		
	}
}
