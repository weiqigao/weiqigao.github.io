package net.dangertree.unitconverter

class Lookup {
    
    static table = [
        meters: [
            kilometers: 'x / 1000'
        ],
        kilometers: [
            meters: 'x * 1000'
        ]
    ]
    
    def formula(toUnits, fromUnits) {
        if (!table[toUnits]) {
            throw new UnitConversionException("No units of type $toUnits!")
        }
        table[toUnits][fromUnits]
    }
    
}