package net.dangertree.unitconverter

class UnitConversionException extends Exception {
    UnitConversionException(String msg) {
        super(msg)
    }
}