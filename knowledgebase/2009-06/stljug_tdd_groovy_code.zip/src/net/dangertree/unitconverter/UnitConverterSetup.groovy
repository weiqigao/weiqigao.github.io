package net.dangertree.unitconverter

class UnitConverterSetup {
    static {
        
        def props = [:]
        
        def lookup = new Lookup()
        
        Number.metaClass.getUnits = { ->
            props[System.identityHashCode(delegate) + 'units']
        }
        
        Number.metaClass.getConverting = { ->
            props[System.identityHashCode(delegate) + 'converting'] ?: false
        }
        
        Number.metaClass.getTo = { ->
            props[System.identityHashCode(delegate) + 'converting'] = true
            delegate
        }
        
        Number.metaClass.propertyMissing = {String name ->
            if (delegate.converting) {
                def fromUnits = props[System.identityHashCode(delegate) + 'units']
                def formula = lookup.formula(fromUnits, name)
                return Eval.me('x', delegate, formula)
            }
            props[System.identityHashCode(delegate) + 'units'] = name
            delegate
        }
    }
}