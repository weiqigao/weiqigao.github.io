package net.dangertree.unitconverter

class UnitConverterTests extends GroovyTestCase {
    
    void setUp() {
        UnitConverterSetup.class
    }
    
    void testKilometers() {
        assertEquals 1, 1.kilometers
        assertEquals 10, 10.kilometers
    }
    
    void testMeters() {
        assertEquals 1, 1.meters
        assertEquals 10, 10.meters
        assertEquals 3.14, 3.14.meters
    }
    
    void testFromUnitsIsAccessible() {
        assertEquals 'meters', 1.meters.units
        assertEquals 'inches', 1.inches.units
        assertEquals 'inches', 1.5.inches.units
        def myMeters = 1.meters
        def myInches = 1.inches
        assertEquals 'meters', myMeters.units
        assertEquals 'inches', myInches.units
    }
    
    void testImpendingConversionOnTo() {
        assertFalse 1.converting
        assertFalse 1.miles.converting
        assertTrue 1.miles.to.converting
    }
    
    
    void testKilometersToMeters() {
        assertEquals 1000, 1.kilometers.to.meters
        assertEquals 1500, 1.5.kilometers.to.meters
    }
    
    
    void testMetersToKilometers() {
        assertEquals 1, 1000.meters.to.kilometers
        assertEquals 1.5, 1500.meters.to.kilometers
    }
    
    
    /*
    void testExceptionThrownOnBadUnit() {
        def msg = shouldFail(UnitConvertionException) {
            1.cheesecakes
        }
        assertEquals 'No units of type cheesecakes', msg
    }
    */
    
    
    
}