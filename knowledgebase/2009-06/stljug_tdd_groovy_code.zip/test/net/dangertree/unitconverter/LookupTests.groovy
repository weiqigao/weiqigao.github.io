package net.dangertree.unitconverter

class LookupTests extends GroovyTestCase {
    def lookup = new Lookup()
    
    void testMetersToKilometers() {
        assertEquals 'x / 1000', lookup.formula('meters', 'kilometers')
    }
    
    //
    void testKilometersToMeters() {
        assertEquals 'x * 1000', lookup.formula('kilometers', 'meters')
    }
    
    void testBadFromUnits() {
        def msg = shouldFail(UnitConversionException) {
            lookup.formula('cheesecakes', 'inches')   
        }
        assertEquals 'No units of type cheesecakes!', msg
    }
    
    // incompatible units
    
}