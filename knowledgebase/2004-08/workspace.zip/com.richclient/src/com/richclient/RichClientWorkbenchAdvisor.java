package com.richclient;

import org.eclipse.ui.application.WorkbenchAdvisor;

public class RichClientWorkbenchAdvisor extends WorkbenchAdvisor {

    public String getInitialWindowPerspectiveId() {
        return "com.richclient.RichClientPerspective";
    }
}
