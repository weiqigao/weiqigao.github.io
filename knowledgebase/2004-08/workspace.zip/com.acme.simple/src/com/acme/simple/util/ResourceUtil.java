/*
 * Created on Aug 11, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.acme.simple.util;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;

/**
 * @author rhauch
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ResourceUtil {

	/**
	 * 
	 */
	public ResourceUtil() {
		super();
	}
	
	public static void printStats( final IResource resource ) {
		// Create the visitor ...
		final ResourceCounter counter = new ResourceCounter();
		try {
			resource.accept(counter);
		} catch (CoreException e) {
			e.printStackTrace();
		}
		counter.printStats();
	}

	public static void printStats( final Object[] resources ) {
		if ( resources == null || resources.length == 0 ) {
			return;
		}
		
		// Create the visitor ...
		final ResourceCounter counter = new ResourceCounter();

		// Walk the selection ...
		for (int i = 0; i < resources.length; i++) {
			Object resource = resources[i];
			if ( resource instanceof IResource ) {
				try {
					((IResource)resource).accept(counter);
				} catch (CoreException e) {
					e.printStackTrace();
				}
			}
		}
		counter.printStats();
	}

}
