/*
 * Created on Aug 11, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.acme.simple.util;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.runtime.CoreException;

/**
 * @author rhauch
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ResourceCounter implements IResourceVisitor {

	private int numProjects;
	private int numFolders;
	private int numFiles;
	
	/**
	 * 
	 */
	public ResourceCounter() {
		super();
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see org.eclipse.core.resources.IResourceVisitor#visit(org.eclipse.core.resources.IResource)
	 */
	public boolean visit(final IResource resource) throws CoreException {
		final int type = resource.getType();
		switch(type) {
			case IResource.FILE : {
				++numFiles;
				break;
			}
			case IResource.FOLDER : {
				++numFolders;
				break;
			}
			case IResource.PROJECT : {
				++numProjects;
				break;
			}
		}
		return true;
	}

	/**
	 * @return Returns the numFiles.
	 */
	public int getNumFiles() {
		return numFiles;
	}
	/**
	 * @return Returns the numFolders.
	 */
	public int getNumFolders() {
		return numFolders;
	}
	/**
	 * @return Returns the numProjects.
	 */
	public int getNumProjects() {
		return numProjects;
	}
	
	public void printStats() {
		System.out.println("Number of instances of");
		System.out.println("  Projects:   " + this.numProjects);
		System.out.println("  Folders:    " + this.numFolders);
		System.out.println("  Files:      " + this.numFiles);
	}
}
