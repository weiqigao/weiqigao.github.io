package com.ociweb.corespring.helloworld.config.web;

import java.io.IOException;
import java.util.Properties;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;

public class MyContextInitializer implements ApplicationContextInitializer<AnnotationConfigApplicationContext> {

	@Override
	public void initialize(AnnotationConfigApplicationContext ac) {
		ConfigurableEnvironment env = ac.getEnvironment();
		env.setActiveProfiles("dev");
		
		ac.scan("com.ociweb.corespring.helloworld.config");
		
//		env.getPropertySources().addFirst(new MyPropertySource());
	}
}
