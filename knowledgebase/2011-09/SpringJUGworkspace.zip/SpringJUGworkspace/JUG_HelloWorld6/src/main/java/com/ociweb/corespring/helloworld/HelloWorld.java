package com.ociweb.corespring.helloworld;

import java.io.IOException;
import java.util.Properties;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;

public class HelloWorld {

	// Experiment with uncommenting different lines to see
	// how the different property sources get loaded and affect the output
	public static void main(String[] args) throws IOException {

//		System.setProperty("greeting", "Hello System World");
		
		AnnotationConfigApplicationContext ac = new AnnotationConfigApplicationContext();
		
//		ac.getEnvironment().setActiveProfiles("dev");
		ac.getEnvironment().setActiveProfiles("prod");
		
		ac.scan("com.ociweb.corespring.helloworld.config");
		
//		PropertySource<?> source = createPropertySource(ac);
//		ac.getEnvironment().getPropertySources().addFirst(source);

		ac.refresh();

		Service service = (Service) ac.getBean("greetingService");
		service.execute();
	}
	
	
	private static PropertySource<?> createPropertySource(ApplicationContext ac) throws IOException{
		final Properties props = new Properties();
		final Resource resource = ac.getResource("classpath:/com/ociweb/corespring/helloworld/config/hello.properties");
		props.load(resource.getInputStream());
		return new PropertySource<Properties>("hello", props) {
			@Override
			public Object getProperty(String key) {
				return props.getProperty(key);
			}
		};
	}
}
