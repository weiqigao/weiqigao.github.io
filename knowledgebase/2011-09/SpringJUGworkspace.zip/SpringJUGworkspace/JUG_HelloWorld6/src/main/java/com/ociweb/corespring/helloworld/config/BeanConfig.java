package com.ociweb.corespring.helloworld.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.ociweb.corespring.helloworld.GreetingDestination;
import com.ociweb.corespring.helloworld.GreetingDestinationImpl;
import com.ociweb.corespring.helloworld.GreetingSource;
import com.ociweb.corespring.helloworld.GreetingSourceImpl;
import com.ociweb.corespring.helloworld.config.profile.Dev;
import com.ociweb.corespring.helloworld.config.profile.Production;

@Configuration
public class BeanConfig {
	
	// Below are two equivalent ways of accessing environment properties.
	
	@Autowired
	 private Environment env;
	
	@Bean
	public GreetingSource source(){
		GreetingSourceImpl s =  new GreetingSourceImpl();
		s.setGreeting(env.getProperty("greeting"));
		return s;
	}
	
//	@Value("#{ environment.getProperty('greeting') }")
//	 private String greeting;
//	
//	@Bean
//	public GreetingSource source(){
//		GreetingSourceImpl s =  new GreetingSourceImpl();
//		s.setGreeting(greeting);
//		return s;
//	}
	
	@Bean
	public GreetingDestination destination(){
		return new GreetingDestinationImpl(){
			@Override
			protected GreetingDestination _this() {
				return destination();
			}
		};
	}
	
	@Configuration
	@Dev
	@PropertySource("classpath:/com/ociweb/corespring/helloworld/config/dev.properties")
	public static class PropertiesDev {
	}


	@Configuration
	@Production
	@PropertySource("classpath:/com/ociweb/corespring/helloworld/config/prod.properties")
	public static class PropertiesProd {
	}
}









