package com.ociweb.corespring.helloworld;



public abstract class GreetingDestinationImpl implements GreetingDestination {

	protected abstract GreetingDestination _this();
	

	public void shout(String greeting){
		_this().write(greeting.toUpperCase());
	}
	
	public void write(String greeting) {
		System.out.println(greeting);
	}

}