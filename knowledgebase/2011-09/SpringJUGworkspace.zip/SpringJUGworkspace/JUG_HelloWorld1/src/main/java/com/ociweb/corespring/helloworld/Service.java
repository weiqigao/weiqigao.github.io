package com.ociweb.corespring.helloworld;

public interface Service {
	public void execute();
}
