package com.ociweb.corespring.helloworld;

public interface GreetingDestination {
	public void write(String greeting);
}
