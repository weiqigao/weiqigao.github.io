package com.ociweb.corespring.helloworld;

public class GreetingService implements Service {
	
	private GreetingSource source;
	private GreetingDestination destination;
	
	
	public GreetingService(){}
	
	public GreetingService(GreetingSource source, GreetingDestination destination){
		this.source = source;
		this.destination = destination;
	}
	
	public void execute() {
		destination.write(source.getGreeting());
	}
	
}
