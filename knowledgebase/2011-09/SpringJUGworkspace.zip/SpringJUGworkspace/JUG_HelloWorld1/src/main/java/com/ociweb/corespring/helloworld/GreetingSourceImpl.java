package com.ociweb.corespring.helloworld;

public class GreetingSourceImpl implements GreetingSource {
	
	private String greeting;
	
	public GreetingSourceImpl(){}
	
	public GreetingSourceImpl(String greeting){
		this.greeting = greeting;
	}
	
	public void init(){
		System.out.println("init with value: " + greeting);
	}
	
	public void destroy() {
		System.out.println("destroy greeting");
	}
	
	public String getGreeting(){
		return greeting;
	}
	
	public void setGreeting(String greeting){
		this.greeting = greeting;
	}

}
