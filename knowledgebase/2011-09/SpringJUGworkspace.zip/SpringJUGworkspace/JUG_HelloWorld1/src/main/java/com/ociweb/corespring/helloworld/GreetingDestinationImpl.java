package com.ociweb.corespring.helloworld;


public class GreetingDestinationImpl implements GreetingDestination {
	
	public void write(String greeting) {
		System.out.println(greeting);
	}

}
