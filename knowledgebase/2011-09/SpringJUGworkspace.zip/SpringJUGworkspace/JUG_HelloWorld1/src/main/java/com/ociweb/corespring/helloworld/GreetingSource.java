package com.ociweb.corespring.helloworld;

public interface GreetingSource {
	public String getGreeting();	
}
