package com.ociweb.corespring.helloworld;

import static org.easymock.EasyMock.*;

import org.junit.Before;
import org.junit.Test;

public class GreetingServiceTest {

	private GreetingSource sourceMock;
	private GreetingDestination destinationMock;
	
	private GreetingService classUnderTest;
	
	@Before
	public void setUp() throws Exception {
		//create mocks
		sourceMock = createMock(GreetingSource.class);
		destinationMock = createMock(GreetingDestination.class);
		
		//create CUT and inject it with mocks
		classUnderTest = new GreetingService(sourceMock, destinationMock);
	}

	@Test
	public void testExecute() {
		String greeting = "Hello World";
		
		//program mocks
		expect(sourceMock.getGreeting()).andReturn(greeting);
		replay(sourceMock);
		
		destinationMock.write(greeting);
		replay(destinationMock);
		
		
		//call real method we are testing
		classUnderTest.execute();

		//verify mocks were used correctly
		verify(sourceMock);
		verify(destinationMock);
	}
}
