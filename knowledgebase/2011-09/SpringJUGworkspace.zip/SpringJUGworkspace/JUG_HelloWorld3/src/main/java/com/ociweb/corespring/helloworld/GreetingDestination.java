package com.ociweb.corespring.helloworld;

public interface GreetingDestination {
	public void write(String greeting);
	public void shout(String greeting);
}
