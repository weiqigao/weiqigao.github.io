package com.ociweb.corespring.helloworld.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

import com.ociweb.corespring.helloworld.GreetingDestination;

@Aspect
public class BobAspect {
	
	@Pointcut("execution(* com.ociweb.corespring.helloworld.GreetingDestination.write(java.lang.String)) && args(message) && target(dest)")
	public void write(String message, GreetingDestination dest){};
	
	@Around("write(message, dest)")
	public void makeItBob(ProceedingJoinPoint jp, String message, GreetingDestination dest){
			dest.write("Bob says: " + message);
	}
}
