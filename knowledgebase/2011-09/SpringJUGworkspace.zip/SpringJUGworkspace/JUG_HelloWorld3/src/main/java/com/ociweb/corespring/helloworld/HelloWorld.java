package com.ociweb.corespring.helloworld;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class HelloWorld {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext ac = new AnnotationConfigApplicationContext();
		ac.scan("com.ociweb.corespring.helloworld.config");
		ac.refresh();
	
		Service service = (Service) ac.getBean("greetingService");
		service.execute();
	}
}
