package com.ociweb.corespring.helloworld.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ociweb.corespring.helloworld.GreetingDestination;
import com.ociweb.corespring.helloworld.GreetingDestinationImpl;
import com.ociweb.corespring.helloworld.GreetingSource;
import com.ociweb.corespring.helloworld.GreetingSourceImpl;

@Configuration
public class BeanConfig {
	
	@Bean
	public GreetingSource source(){
		GreetingSourceImpl s =  new GreetingSourceImpl();
		s.setGreeting("Hello World");
		return s;
	}
	
// Switch out these two implementations of destination() along with the two i
//	implementations of GreetingDestinationImpl to see
// how it affects the output.

	@Bean
	public GreetingDestination destination(){
		return new GreetingDestinationImpl();
	}
	
//	@Bean
//	public GreetingDestination destination(){
//		return new GreetingDestinationImpl(){
//			@Override
//			protected GreetingDestination _this() {
//				return destination();
//			}
//		};
//	}

}
