package com.ociweb.corespring.helloworld;

public class GreetingService implements Service {
	
	private GreetingSource source;
	private GreetingDestination destination;
	
	
	public GreetingService(){}
	
	public void execute() {
		destination.shout(source.getGreeting());
		destination.write(source.getGreeting());
	}

	public GreetingService setSource(GreetingSource source) {
		this.source = source;
		return this;
	}

	public GreetingService setDestination(GreetingDestination destination) {
		this.destination = destination;
		return this;
	}
}
