package com.ociweb.corespring.helloworld.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.ociweb.corespring.helloworld.GreetingService;
import com.ociweb.corespring.helloworld.Service;

@Configuration
@Import(BeanConfig.class)
public class ServiceConfig {

	@Autowired
	private BeanConfig beanConfig;
	
	
	@Bean
	public Service greetingService(){
		// as of Spring 3.1, set methods that return objects will be supported in 
		// the XML as well, making this class usable in XML or chained code.
		return new GreetingService()
			.setDestination(beanConfig.destination())
			.setSource(beanConfig.source());
	}
}
