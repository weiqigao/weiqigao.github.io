package com.ociweb.corespring.helloworld.config;

import org.springframework.aop.aspectj.annotation.AnnotationAwareAspectJAutoProxyCreator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ociweb.corespring.helloworld.aspect.BobAspect;

@Configuration
//@EnableAspectJ    To Come in a future release?
public class AOPConfig {

	/**
	 * Turns on processing of the @AspectJ annotations
	 * @return
	 */
	@Bean   
	public AnnotationAwareAspectJAutoProxyCreator aspectj_autoproxy(){
		return new AnnotationAwareAspectJAutoProxyCreator();   
	}
	
	@Bean
	public BobAspect bob(){
		return new BobAspect();
	}
}
