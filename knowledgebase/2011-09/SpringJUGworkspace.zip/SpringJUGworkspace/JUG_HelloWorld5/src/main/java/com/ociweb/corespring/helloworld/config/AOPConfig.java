package com.ociweb.corespring.helloworld.config;

import org.springframework.aop.aspectj.annotation.AnnotationAwareAspectJAutoProxyCreator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ociweb.corespring.helloworld.aspect.BobAspect;
import com.ociweb.corespring.helloworld.config.profile.Dev;

@Configuration
@Dev
public class AOPConfig {

	@Bean   
	public AnnotationAwareAspectJAutoProxyCreator aspectj_autoproxy(){
		return new AnnotationAwareAspectJAutoProxyCreator();   
	}
	
	@Bean
	public BobAspect bob(){
		return new BobAspect();
	}
}
