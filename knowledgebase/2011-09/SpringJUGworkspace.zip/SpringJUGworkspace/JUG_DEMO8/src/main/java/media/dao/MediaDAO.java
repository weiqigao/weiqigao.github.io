package media.dao;

import java.util.List;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;

import media.Media;

public interface MediaDAO {

	List<Media> retrieveMedia(MediaType type);

	void addMedia(Media m);             

	@Cacheable("media")
	Media retrieveMedia(long id);
	
	@CacheEvict(value ="media", key="#m.id")
	void updateMedia(Media m);
	
	@CacheEvict(value ="media", key="#m.id")
	void removeMedia(Media m);
}
