package com.ociweb.corespring.helloworld;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ociweb.corespring.helloworld.config.ServiceConfig;

public class HelloWorld {

	public static void main(String[] args) {
		
		ConfigurableApplicationContext ac = new AnnotationConfigApplicationContext(ServiceConfig.class);
		ac.registerShutdownHook();
		
		//Run this example with "greetingServiceBroken" and then with "greetingService"
		Service service = (Service) ac.getBean("greetingServiceBroken");
		service.execute();
		service.execute();
		service.execute();
		service.execute();
	}
}
