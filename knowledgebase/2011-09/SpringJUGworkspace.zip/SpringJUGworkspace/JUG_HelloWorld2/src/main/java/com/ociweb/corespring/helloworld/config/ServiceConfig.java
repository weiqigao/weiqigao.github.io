package com.ociweb.corespring.helloworld.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.ociweb.corespring.helloworld.GreetingDestination;
import com.ociweb.corespring.helloworld.GreetingService;
import com.ociweb.corespring.helloworld.Service;

@Configuration
@Import(BeanConfig.class)
public class ServiceConfig {

	@Autowired
	private BeanConfig beanConfig;
	
	
	@Bean
	public Service greetingService(){
		return new GreetingService(beanConfig.source()){

			@Override
			protected GreetingDestination lookupDestination() {
				return beanConfig.destination();
			}
			
		};
	}
	
	@Bean
	public Service greetingServiceBroken(){
		final GreetingDestination d = beanConfig.destination();
		
		return new GreetingService(beanConfig.source()){

			@Override
			protected GreetingDestination lookupDestination() {
				return d;
			}
			
		};
	}
}
