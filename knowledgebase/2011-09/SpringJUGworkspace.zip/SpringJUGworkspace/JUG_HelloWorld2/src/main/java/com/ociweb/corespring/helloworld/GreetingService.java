package com.ociweb.corespring.helloworld;

public abstract class GreetingService implements Service {
	
	private GreetingSource source;
	
	
	public GreetingService(){}
	
	public GreetingService(GreetingSource source){
		this.source = source;
	}
	
	public void execute() {
		lookupDestination().write(source.getGreeting());
	}
	
	protected abstract GreetingDestination lookupDestination();
	
}
