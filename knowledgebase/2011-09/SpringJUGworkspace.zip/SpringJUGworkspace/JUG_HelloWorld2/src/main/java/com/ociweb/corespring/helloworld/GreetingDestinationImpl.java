package com.ociweb.corespring.helloworld;


public class GreetingDestinationImpl implements GreetingDestination {
	private boolean valid = true;
	
	public void write(String greeting) {
		if(valid){
			System.out.println(greeting);
		} else {
			System.out.println("Stale Destination!");
		}
		valid = false;
	}

}
