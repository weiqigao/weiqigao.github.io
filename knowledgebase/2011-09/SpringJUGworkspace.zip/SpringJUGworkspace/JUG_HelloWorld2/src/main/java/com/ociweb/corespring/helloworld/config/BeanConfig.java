package com.ociweb.corespring.helloworld.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.ociweb.corespring.helloworld.GreetingDestination;
import com.ociweb.corespring.helloworld.GreetingDestinationImpl;
import com.ociweb.corespring.helloworld.GreetingSource;
import com.ociweb.corespring.helloworld.GreetingSourceImpl;

@Configuration
public class BeanConfig {
	
	@Bean
	public GreetingSource source(){
		GreetingSourceImpl s =  new GreetingSourceImpl();
		s.setGreeting("Hello World");
		return s;
	}
	
	@Bean
	@Scope("prototype")
	public GreetingDestination destination(){
		System.out.println("Creating a new Destination instance...");
		return new GreetingDestinationImpl();
	}
}
