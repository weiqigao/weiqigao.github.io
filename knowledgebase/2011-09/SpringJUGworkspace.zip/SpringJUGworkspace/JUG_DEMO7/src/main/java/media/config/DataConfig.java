package media.config;

import java.util.Properties;

import javax.sql.DataSource;

import media.dao.MediaDAO;
import media.dao.SimpleMediaDAO;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.orm.hibernate3.SessionFactoryBuilder;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.util.ResourceUtils;

@Configuration
@EnableTransactionManagement
public class DataConfig {
	
	@Autowired
	private ApplicationContext ctx;
	
	@Autowired
	private DataSource datasource;
	
    @Bean
    public SessionFactory sessionFactory() throws Exception {
    	Resource location = 
    		ctx.getResource(ResourceUtils.CLASSPATH_URL_PREFIX + "hibernate");
    	
    	Properties hProps = new Properties();
    	hProps.put("hibernate.dialect", "org.hibernate.dialect.HSQLDialect");
    	
        return new SessionFactoryBuilder(datasource)
            .setMappingDirectoryLocations(location)
            .setHibernateProperties(hProps)
            .buildSessionFactory();
    }
    
    @Bean 
    public PlatformTransactionManager transactionManager() throws Exception{
    	return new HibernateTransactionManager(sessionFactory());
    }
	
    @Bean
    public MediaDAO mediaDAO() throws Exception{
    	return new SimpleMediaDAO(sessionFactory());
    }
    
    
    @Profile("dev")
    @Configuration
    public static class DataConfigDev {
    	
        @Bean(destroyMethod="shutdown")
        public DataSource dataSource(){
        	 return new EmbeddedDatabaseBuilder().
        	 	addScript(ResourceUtils.CLASSPATH_URL_PREFIX + "sql/schema.sql").
        	 	addScript(ResourceUtils.CLASSPATH_URL_PREFIX + "sql/test-data.sql").
        	 	build();
        }
    }
    
    @Profile("prod")
    @Configuration
    public static class DataConfigProd {
    	
        @Bean
        public DataSource dataSource(){
        	 return null;//TODO
        }
    }
}
