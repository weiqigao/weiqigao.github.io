package media.service;

import java.util.List;

import media.Media;
import media.dao.MediaDAO;
import media.dao.MediaType;

public class SimpleMediaService implements MediaService {

	private MediaDAO dao;
	
	public SimpleMediaService(MediaDAO mediaDao) {
		dao = mediaDao;
	}

	public void printCDs() {
		printContents(MediaType.CD);
	}

	public void printDVDs() {
		printContents(MediaType.DVD);
	}

	public void printGames() {
		printContents(MediaType.GAME);
	}
	
	private void printContents(MediaType mediaType) {
		List<Media> contents = dao.retrieveMedia(mediaType);
		
		System.out.println(mediaType.toString() + " Contents: ");
		
		for(Media media : contents) {
			System.out.println("\tId:        "+ String.valueOf(media.getId()));
			System.out.println("\tTitle:    "+ media.getTitle());
			System.out.println("\tGenre: "+ media.getGenre());
			System.out.println("");
		}
		System.out.println("");
	}

	public Media addCD(String title, String genre, String artist) {
		Media m = new Media(title, artist, genre, 0, MediaType.CD.toString());
		dao.addMedia(m);
		return m;
	}

	public Media addDvd(String title, String genre, String leadActor) {
		Media m = new Media(title, leadActor, genre, 0, MediaType.DVD.toString());
		dao.addMedia(m);
		return m;
	}

	public Media addGame(String title, String genre, int numPlayers, String publisher) {
		Media m = new Media(title, publisher, genre, numPlayers, MediaType.GAME.toString());
		dao.addMedia(m);
		return m;
	}

	public void removeMedia(Media media) {
		dao.removeMedia(media);
	}

	public Media retrieveMedia(long id) {
		return dao.retrieveMedia(id);
	}

	public void updateMedia(Media media) {
		dao.updateMedia(media);
	}
}
