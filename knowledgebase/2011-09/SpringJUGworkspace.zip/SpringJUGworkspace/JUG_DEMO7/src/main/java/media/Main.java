package media;

import media.service.MediaService;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext ac = new AnnotationConfigApplicationContext();
		ac.registerShutdownHook();
		
		ac.getEnvironment().setActiveProfiles("dev");
		ac.scan("media.config");
		ac.refresh();
		
		MediaService mediaService = ac.getBean("mediaService", MediaService.class);
		
		mediaService.printCDs();
		
		Media newCD = mediaService.addCD("Odelay", "Rock", "Beck");
		mediaService.printCDs();
		
		newCD.setTitle("Devils Haircut");
		mediaService.updateMedia(newCD);
		mediaService.printCDs();
		
		Media anotherCopy = mediaService.retrieveMedia(newCD.getId());
		mediaService.removeMedia(anotherCopy);
		mediaService.printCDs();
	}

}
