package media.dao;

public enum MediaType {

	DVD, CD, GAME;
}
