package media.config;

import media.service.MediaService;
import media.service.SimpleMediaService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(DataConfig.class)
public class ServiceConfig {
	
	@Autowired
	private DataConfig dataConfig;
	
	@Bean
	public MediaService mediaService() throws Exception{
		return new SimpleMediaService(dataConfig.mediaDAO());
	}
}
