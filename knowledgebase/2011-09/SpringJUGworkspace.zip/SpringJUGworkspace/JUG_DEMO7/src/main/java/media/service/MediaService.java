package media.service;

import org.springframework.transaction.annotation.Transactional;

import media.Media;

@Transactional
public interface MediaService {

	@Transactional(readOnly=true)
	void printDVDs();
	
	@Transactional(readOnly=true)
	void printCDs();
	
	@Transactional(readOnly=true)
	void printGames();
	
	Media addDvd(String title, String genre, String leadActor) ; //leadActor = artist
	Media addGame(String title, String genre, int numPlayers, String publisher); //publisher = artist
	Media addCD(String title, String genre, String artist);
	
	void removeMedia(Media media);
	
	@Transactional(readOnly=true)
	Media retrieveMedia(long id);
	
	void updateMedia(Media media);
	
}
