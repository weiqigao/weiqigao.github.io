package media.dao;

import java.util.List;

import media.Media;

public interface MediaDAO {

	List<Media> retrieveMedia(MediaType type);
	
	void addMedia(Media m);
	Media retrieveMedia(long id);
	void updateMedia(Media m);
	void removeMedia(Media m);
}
