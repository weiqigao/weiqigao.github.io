package media.dao;

import java.util.List;
import org.hibernate.SessionFactory;
import media.Media;

public class SimpleMediaDAO implements MediaDAO {
	
	private SessionFactory sessionFactory;
		
	public SimpleMediaDAO(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Media> retrieveMedia(MediaType type){
			return sessionFactory.getCurrentSession()
			.createQuery("from Media as media where media.type = ?")
		    .setString(0, type.name())
		    .list();
	}
	
	@Override
	public void addMedia(Media m) {
		sessionFactory.getCurrentSession().saveOrUpdate(m);
	}

	@Override
	public void removeMedia(Media m) {
		sessionFactory.getCurrentSession().delete(m);
	}

	@Override
	public Media retrieveMedia(long id) {
		return (Media)sessionFactory.getCurrentSession().load(Media.class, id);
	}

	@Override
	public void updateMedia(Media m) {
		sessionFactory.getCurrentSession().update(m);
	}
}
