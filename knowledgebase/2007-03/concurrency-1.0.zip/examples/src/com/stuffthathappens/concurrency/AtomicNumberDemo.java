package com.stuffthathappens.concurrency;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author Eric Burke
 */
public class AtomicNumberDemo {
    public static void main(String[] args) {
        final AtomicInteger tally = new AtomicInteger();
        System.out.println("tally = " + tally);

        tally.incrementAndGet();
        tally.getAndIncrement();

        System.out.println("tally = " + tally);

    }
}
