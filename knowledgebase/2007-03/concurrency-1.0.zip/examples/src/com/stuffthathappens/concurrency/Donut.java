package com.stuffthathappens.concurrency;

/**
 * @author Eric Burke
 */
public class Donut {
    public enum Type { JELLY, CAKE, GLAZED, LONG_JOHN }

    private final String producerName;
    private final Type type;

    public Donut(String producerName, Type type) {
        this.producerName = producerName;
        this.type = type;
    }

    public String getProducerName() {
        return producerName;
    }

    public Type getType() {
        return type;
    }
}
