package com.stuffthathappens.concurrency;

import java.io.Serializable;

/**
 * An immutable object.
 *
 * @author Eric Burke
 */
public class Name {
    private final String first;
    private final String last;

    public Name(String first, String last) {
        this.first = first;
        this.last = last;
    }

    public String toString() {
        return getFirst() + " " + getLast();
    }

    public String getFirst() {
        return first;
    }

    public String getLast() {
        return last;
    }
}
