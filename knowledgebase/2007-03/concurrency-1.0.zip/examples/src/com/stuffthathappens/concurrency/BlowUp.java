package com.stuffthathappens.concurrency;

import java.util.concurrent.*;

/**
 * @author Eric Burke
 */
public class BlowUp {
    public static void main(String[] args) {
        Thread.setDefaultUncaughtExceptionHandler(new LastResort());
        ExecutorService executorService = Executors.newCachedThreadPool();

        /*
        // option A - just call execute, letting the UncaughtExceptionHandler catch it
        executorService.execute(new Bomb());
        */

        /*
        // option B - call submit, but you WILL MISS THE EXCEPTION
        executorService.submit(new Bomb());
        */


        /*
        // option C - get the Future, and check its result
        Future future = executorService.submit(new Bomb());

        try {
            future.get();
        } catch (InterruptedException ie) {
            // ignored
        } catch (ExecutionException e) {
            Throwable cause = e.getCause();
            cause.printStackTrace();
        }
        */

        // option D - a custom FutureTask
        FutureTask<?> ft = new FutureTask<Object>(new Bomb(), null) {
            protected void done() {
                System.out.println("Done!");
                try {
                    get();
                } catch (InterruptedException e) {
                    // ignored
                } catch (ExecutionException e) {
                    e.getCause().printStackTrace();
                }
            }
        };
        executorService.execute(ft);

        executorService.shutdown();
    }

}

