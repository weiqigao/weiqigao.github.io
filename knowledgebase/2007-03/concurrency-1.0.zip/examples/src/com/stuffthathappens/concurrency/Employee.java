package com.stuffthathappens.concurrency;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.TimeUnit;

/**
 * @author Eric Burke
 */
public class Employee {
//    private static int employeeCount = 0;
    private static final AtomicInteger employeeCount = new AtomicInteger(0);

    private final Name name;
    private final int employeeNumber;

    public Employee(Name name) {
        this.name = name;
//        employeeNumber = employeeCount++;
        employeeNumber = employeeCount.getAndIncrement();
    }

    public Name getName() {
        return name;
    }

    public int getEmployeeNumber() {
        return employeeNumber;
    }
}
