package com.stuffthathappens.concurrency;

import java.util.Random;

/**
 * @author Eric Burke
 */
public class RandomName {
    private static final Random rand = new Random();

    private static final String[] FIRST_NAMES = new String[] {
            "Alice", "Avery", "Bob"
    };

    private static final String[] LAST_NAMES = new String[] {
            "Burke", "Jones", "Smith", "Clark"
    };

    public static Name generate() {
        return new Name(randomString(FIRST_NAMES), randomString(LAST_NAMES));
    }

    private static String randomString(String[] arr) {
        return arr[rand.nextInt(arr.length)];
    }
}
