package com.stuffthathappens.concurrency;

/**
 * @author Eric Burke
 */
public class Bomb implements Runnable {
    public void run() {
        System.out.println("About to blow...");
        throw new IllegalArgumentException("The Bomb Blew Up");
    }
}
