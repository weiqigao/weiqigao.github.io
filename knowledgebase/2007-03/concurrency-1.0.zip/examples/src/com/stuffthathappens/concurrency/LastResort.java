package com.stuffthathappens.concurrency;

/**
 * @author Eric Burke
 */
public class LastResort implements Thread.UncaughtExceptionHandler {
    public void uncaughtException(Thread t, Throwable e) {
        System.err.println("In thread " + t.getName() + ", caught this: ");
        e.printStackTrace();
    }
}
