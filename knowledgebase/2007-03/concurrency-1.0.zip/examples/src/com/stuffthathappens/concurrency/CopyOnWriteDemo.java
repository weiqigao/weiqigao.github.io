package com.stuffthathappens.concurrency;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * @author Eric Burke
 */
public class CopyOnWriteDemo {
    private final Set<ActionListener> listeners = 
            new CopyOnWriteArraySet<ActionListener>();

    public void addActionListener(ActionListener l) {
        listeners.add(l);
    }

    public void removeActionListener(ActionListener l) {
        listeners.remove(l);
    }

    private void notifyListeners(ActionEvent e) {
        for (ActionListener l : listeners) {
            l.actionPerformed(e);
        }
    }
}
