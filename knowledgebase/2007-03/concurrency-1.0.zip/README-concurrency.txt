"Training Stuff" is a collection of free PowerPoint slides and code
examples written by Eric M. Burke.

Open Source License: See LICENSE.txt

Java Concurrency
----------------
Originally developed for the March 8, 2007 St. Louis Java User's Group.
This takes about 1.5 hrs to deliver.


Building the Examples
---------------------
These examples require Java 6
