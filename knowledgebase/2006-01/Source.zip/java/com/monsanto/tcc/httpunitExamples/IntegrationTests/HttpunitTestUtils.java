package com.monsanto.tcc.httpunitExamples.IntegrationTests;

import com.meterware.httpunit.*;
import junit.framework.TestCase;

import java.io.IOException;

import org.xml.sax.SAXException;

/**
 * Created by IntelliJ IDEA.
 * User: LKPETER
 * Date: Dec 26, 2005
 * Time: 5:26:50 PM
 * To change this template use File | Settings | File Templates.
 */
public class HttpunitTestUtils extends TestCase
{
  protected static final String LOCATION_OF_APP = "http://localhost/httpUnit/";

  public static final String PAGE1 = "/html/formsPageExample.html";
  public static final String PAGE2 = "/html/tablesPageExample.html";
  public static final String PAGE3 = "/html/javascriptAndNewWindowsExample.html";

  public static final String PAGE2_TITLE = "Page 2 - tables";
  public static final String PAGE1_TITLE = "Intro Page 1";

  public static final String FORM_ID = "FormId";

  private final static String apacheTestUID = "guest";
  private final static String apacheTestPWD = "password";

  protected WebConversation conversation;
  protected WebResponse webResponse;

  protected WebResponse getNewlyOpenedBrowserWindow()
  {
    WebWindow[] windows = conversation.getOpenWindows();
    assertEquals(2, windows.length);
    WebResponse helpPage = windows[1].getCurrentPage();
    return helpPage;
  }

  protected void setUp() throws Exception
  {
    super.setUp();
    conversation = new WebConversation();
    conversation.setAuthorization(apacheTestUID, apacheTestPWD);
  }

  protected WebResponse getWebResponseFor(String webItem) throws IOException, SAXException
  {
    WebRequest request = new PostMethodWebRequest(LOCATION_OF_APP + webItem);
    webResponse = conversation.getResponse(request);
    assertNotNull(webResponse);
    return webResponse;
  }

  protected void assertCorrectPageTitle(String pageTitle) throws SAXException
  {
    assertEquals("HTTPUnit Example: " + pageTitle, webResponse.getTitle());
  }

  public void testDummy() throws Exception {
    // avoid no test found issue
  }
}
