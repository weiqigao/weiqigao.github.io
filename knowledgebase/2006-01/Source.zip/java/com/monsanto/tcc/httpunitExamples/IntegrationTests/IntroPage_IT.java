package com.monsanto.tcc.httpunitExamples.IntegrationTests;

import junit.framework.TestCase;
import com.meterware.httpunit.*;

import java.io.IOException;

import org.xml.sax.SAXException;

/*
 * com.monsanto.tcc.httpunitExamples.IntegrationTests.IntroPage_IT was created 
 * on Apr 19, 2005 2:51:56 PM using Monsanto resources and is the sole property of Monsanto.  
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's 
 * copyright.
 *
 * Author: lkpeter
 */

public class IntroPage_IT extends TestCase
{
  //logical values for checkbox
  protected static final String IS_CHECKED = "true";
  protected static final String NOT_CHECKED = null;

  protected static final String BACK_FORM = "back";
  protected static final String CLEAR_BUTTON = "clear";
  protected static final String RESET_BUTTON = "reset";

  protected static final String LOCATION_OF_APP = "http://localhost/httpUnit/";

  private final static String apacheTestUID = "guest";
  private final static String apacheTestPWD = "password";

  protected WebConversation conversation;
  protected WebResponse webResponse;

  public static final String PAGE1 = "/html/introPage.html";
  public static final String PAGE_TITLE = "Intro Page 1";
  public static final String FORM_ID = "FormId";
  public static final String TEXT_INPUT = "textInput";
  public static final String TEXT_INPUT_DISABLED = "textInputDisabled";
  public static final String TEXT_INPUT_READONLY = "textInputReadonly";
  public static final String PASSWORD_INPUT = "passwordInput";
  public static final String HIDDEN_INPUT = "hiddenInput";
  public static final String RADIO_INPUT = "radioInput";
  public static final String SELECT_SINGLE = "selectSingle";
  public static final String SELECT_MULTIPLE = "selectMultiple";
  public static final String TEXT_AREA = "textArea";

  protected void setUp() throws Exception
  {
    super.setUp();
    conversation = new WebConversation();
  }

  protected WebResponse getWebResponseFor(String webItem) throws IOException, SAXException{
    conversation.setAuthorization(apacheTestUID, apacheTestPWD);
    WebRequest request = new PostMethodWebRequest(LOCATION_OF_APP+ webItem );
    webResponse = conversation.getResponse(request);
    assertNotNull(webResponse);
    return webResponse;
  }

  protected void assertCorrectPageTitle(String pageTitle) throws SAXException{
    assertEquals("HTTPUnit Example: "+ pageTitle, webResponse.getTitle());
  }

  protected void assertPageDoesContain(String pageContents, String desiredText){
    assertTrue(pageContents.indexOf(desiredText) > -1);
  }

  protected void assertString1appearsBeforeString2OnPage(String pageContents, String string1, String string2){
    int locationOfString1 = pageContents.indexOf(string1);
    int locationOfString2 = pageContents.indexOf(string2);
    assertTrue(( locationOfString1 > -1) && (locationOfString1 < locationOfString2));
  }

  protected void assertPageDoesNotContain(String pageContents, String undesiredText){
    assertTrue(pageContents.indexOf(undesiredText) == -1);
  }

  protected WebResponse getNewlyOpenedBrowserWindow(){
    WebWindow[] windows = conversation.getOpenWindows();
    assertEquals(2, windows.length);
    WebResponse helpPage =  windows[1].getCurrentPage();
    return helpPage;
  }

  // test that page rendered correctly (pretend this was a dynamicaly create page)
  public void testGetInitialPage() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor("/html/introPage.html");

    //did we get the right page?
    assertCorrectPageTitle("Intro Page 1");

    //get raw HTML for the page so we can check for some basic things we are expecting
    String pageText = webResponse.getText();

    //simple test to see if something shows up on the page
    assertPageDoesContain(pageText, "Intro Page 1");

    // also want to make sure some special formatting was there
    assertPageDoesContain(pageText, "<H2 align=\"center\">HTTPUnit Example: Intro Page 1</H2>");

    // may want to test that some thing (like an error message?) does NOT appear on the screen
    assertPageDoesNotContain(pageText, "Fatal error occurred:");

    // if order of information on the screen was important
    assertString1appearsBeforeString2OnPage(pageText, "Intro Page 1", "Different Kinds of Form Inputs");

  }

  public void testGetInitialPageForm() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE_TITLE);

    // one way to get the form if you know there is only 1 on the page
    WebForm formFromArray = webResponse.getForms()[0];
    assertNotNull(formFromArray);

    // or modify your html to add id= to the form tag
    WebForm formFromId = webResponse.getFormWithID(FORM_ID);
    assertNotNull(formFromId);

    // or modify your html to add name= to the form tag
    WebForm formFromName = webResponse.getFormWithName("FormName");
    assertNotNull(formFromName);

    //all 3 methods got the same form
    assertEquals(formFromArray, formFromName);
    assertEquals(formFromName, formFromId);
  }

  public void testGettingFormValues() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE_TITLE);

    WebForm webForm = webResponse.getFormWithID(FORM_ID);
    assertNotNull(webForm);

    String[] paramNames = webForm.getParameterNames();
    for (int i = 0; i < paramNames.length; i++)
    {
      String paramName = paramNames[i];
      System.out.println("paramName : " + paramName);
      String[] paramValues = webForm.getParameterValues(paramName);
      for (int j = 0; j < paramValues.length; j++)
      {
        String paramValue = paramValues[j];
        System.out.println(" = " + paramValue);
      }
    }
  }

  public void testSettingFormValuesTextField() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    // text field (enabled & writable)
    assertEquals("", webForm.getParameterValue(TEXT_INPUT));
    assertTrue(webForm.isTextParameter(TEXT_INPUT));
    assertFalse(webForm.isDisabledParameter(TEXT_INPUT));
    assertFalse(webForm.isReadOnlyParameter(TEXT_INPUT));
    webForm.setParameter(TEXT_INPUT, "newValue");
    assertEquals("newValue", webForm.getParameterValue(TEXT_INPUT));

    // text field (disabled)
    assertEquals("this is disabled", webForm.getParameterValue(TEXT_INPUT_DISABLED));
    assertTrue(webForm.isTextParameter(TEXT_INPUT_DISABLED));
    assertTrue(webForm.isDisabledParameter(TEXT_INPUT_DISABLED));
    assertTrue(webForm.isReadOnlyParameter(TEXT_INPUT_DISABLED));  //this is surprising!
    //note -- trying to set a static value throws a MissingParameterValueException -- can't do this:
   // webForm.setParameter(TEXT_INPUT_DISABLED, "newValue");

    // text field (readonly)
    assertEquals("this is readonly", webForm.getParameterValue(TEXT_INPUT_READONLY));
    assertTrue(webForm.isTextParameter(TEXT_INPUT_READONLY));
    assertFalse(webForm.isDisabledParameter(TEXT_INPUT_READONLY));
    assertTrue(webForm.isReadOnlyParameter(TEXT_INPUT_READONLY));
    //note -- trying to set a static value throws a MissingParameterValueException -- can't do this:
   //webForm.setParameter(TEXT_INPUT_READONLY, "newValue");
  }

  public void testSettingFormValuesPasswordField() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    // password field
    assertEquals("", webForm.getParameterValue(PASSWORD_INPUT));
    assertTrue(webForm.isTextParameter(PASSWORD_INPUT));
    webForm.setParameter(PASSWORD_INPUT, "newValue");
    assertEquals("newValue", webForm.getParameterValue(PASSWORD_INPUT));
  }

  public void testSettingFormValuesHiddenField() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    // hidden field
    assertEquals("hiddenValue", webForm.getParameterValue(HIDDEN_INPUT));
    assertTrue(webForm.isHiddenParameter(HIDDEN_INPUT));
    assertFalse(webForm.isReadOnlyParameter(HIDDEN_INPUT)); // the disabled input is readonly but this is not?
    //note -- trying to set a static value throws a MissingParameterValueException -- can't do this:
    //webForm.setParameter(HIDDEN_INPUT, "newValue");
  }

  public void testSettingFormValuesRadioField() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    //radio buttons
    assertEquals("radio1", webForm.getParameterValue(RADIO_INPUT));
    webForm.setParameter(RADIO_INPUT, "radio2");
    assertEquals("radio2", webForm.getParameterValue(RADIO_INPUT));
    //note trying to set this to a non existant value throws IllegalParameterValueException -- can't do this:
    //webForm.setParameter(RADIO_INPUT, "junk");
    //try to set both at ones throws this :
    // FormParameter$UnusedParameterValueException: Attempted to assign to parameter 'radioInput' the extraneous value 'radio2'.
    //String[] tryToSetBoth = {"radio1", "radio2"};
    //webForm.setParameter(RADIO_INPUT, tryToSetBoth);
    // and checkbox convenience method does not work either:
    // com.meterware.httpunit.FormParameter$IllegalCheckboxParameterException:
    // Attempted to invoke method 'setCheckbox' for parameter 'radioInput/radio1', which is not a unique checkbox control.
    //webForm.setCheckbox(RADIO_INPUT, "radio1", true);
    //assertEquals("radio1", webForm.getParameterValue(RADIO_INPUT));
  }

  public void testSettingFormValuesCheckBoxes() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    //check boxes with unique names
    assertEquals("true", webForm.getParameterValue("checkBoxInput1"));
    assertEquals("true", webForm.getParameterValue("checkBoxInput2"));
    assertEquals("true", webForm.getParameterValue("checkBoxInput3"));
    // this will throw FormParameter$UnusedParameterValueException
    //webForm.setParameter("checkBoxInput1", "false");
    webForm.setCheckbox("checkBoxInput1", false);
    assertEquals(null, webForm.getParameterValue("checkBoxInput1"));

    //check boxes with same name -- unique values
    //note - this works even though there are multiple values for this parameter.  Just get the first one.
    assertEquals("checkBoxA", webForm.getParameterValue("aCheckbox"));
    //this gets all 3 checked items
    assertEquals(3, webForm.getParameterValues("aCheckbox").length);
    // now uncheck one
    //note extra param to match the value since the names are the same
    webForm.setCheckbox("aCheckbox", "checkBoxB", false);
    String[] nowChecked = webForm.getParameterValues("aCheckbox");
    assertEquals("checkBoxA", nowChecked[0]);
    assertEquals("checkBoxC", nowChecked[1]);
  }

  public void testSettingFormValuesSelectionOptions() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    //single select options
    //note flakyness here- html had to be chaged before this worked
    assertEquals("", webForm.getParameterValue(SELECT_SINGLE));
    assertFalse(webForm.isMultiValuedParameter(SELECT_SINGLE));
    webForm.setParameter(SELECT_SINGLE, "opt2");
    assertEquals("opt2", webForm.getParameterValue(SELECT_SINGLE));
    // must choose one of the allowed values, or you get this:
    // IllegalParameterValueException: May not set parameter 'selectSingle' to 'junk'. Value must be one of: { , opt1, opt2, opt3 }
    //webForm.setParameter(SELECT_SINGLE, "junk");
    webForm.setParameter(SELECT_SINGLE, "");

    //can't choose more than one for a single select -- throws FormParameter$UnusedParameterValueException
    String[] tryToSetTwo = {"opt1", "opt2"};
    //webForm.setParameter(SELECT_SINGLE, tryToSetTwo);


    //now the multi select
    // more flakes!  This returns null instead of "" like the last test?
    assertEquals(null, webForm.getParameterValue(SELECT_MULTIPLE));
    assertTrue(webForm.isMultiValuedParameter(SELECT_MULTIPLE));
    webForm.setParameter(SELECT_MULTIPLE, "opt2");
    String[] currentValues = webForm.getParameterValues(SELECT_MULTIPLE);
    assertEquals(1, currentValues.length);
    assertEquals("opt2", currentValues[0]);

    //now choose more than one
    webForm.setParameter(SELECT_MULTIPLE, tryToSetTwo);
    currentValues = webForm.getParameterValues(SELECT_MULTIPLE);

    assertEquals(2, currentValues.length);

  }

  public void testSettingFormValuesTextAreaField() throws Exception
  {
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    // text field (enabled & writable)
    assertEquals("", webForm.getParameterValue(TEXT_AREA));
    assertTrue(webForm.isTextParameter(TEXT_AREA));
    webForm.setParameter(TEXT_AREA, "newValue\nline 2");
    assertEquals("newValue\nline 2", webForm.getParameterValue(TEXT_AREA));
  }

  public void testRestButton() throws Exception
  {
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    //initially field is empty, put some text in it & check that it is there
    assertEquals("", webForm.getParameterValue(TEXT_AREA));
    String newText = "blah blah blah";
    webForm.setParameter(TEXT_AREA, newText);
    assertEquals(newText, webForm.getParameterValue(TEXT_AREA));

    // naming flake -- WebResponse, WebForm, but not WebButton?
    Button[] allButtons = webForm.getButtons();

    //first way to get a button -- find it in the array
    Button buttonFromArray = allButtons[1]; //seems to return these in the order they appear in the form (not specified in api)?
    assertEquals("Reset Form Values", buttonFromArray.getValue());

    //click it & make sure the text got cleared.
    buttonFromArray.click();
    assertEquals("", webForm.getParameterValue(TEXT_AREA));


    //set the text again
    webForm.setParameter(TEXT_AREA, newText);
    assertEquals(newText, webForm.getParameterValue(TEXT_AREA));

    //get the button by ID this time, click it & make sure it worked.
    Button buttonById = webForm.getButtonWithID("resetButtonId");
    buttonById.click();
    assertEquals("", webForm.getParameterValue(TEXT_AREA));

    assertEquals(buttonFromArray, buttonById);

  }


  //todo : note common mistakes:
  // -- forget to "Reget" values after update to form/response
  // -- forget to redeploy when testing war file (test don't need it, code does)
  // -- forget to have Tomcat running
}
