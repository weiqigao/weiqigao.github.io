package com.monsanto.tcc.httpunitExamples.IntegrationTests;

import com.meterware.httpunit.*;

public class FormsExamples_IT extends HttpunitTestUtils
{
  //logical values for checkbox
  protected static final String IS_CHECKED = "true";
  protected static final String NOT_CHECKED = null;

  protected static final String LOCATION_OF_APP = "http://localhost/httpUnit/";

  private void assertPageDoesContain(String pageContents, String desiredText)
  {
    assertTrue(pageContents.indexOf(desiredText) > -1);
  }

  private void assertString1appearsBeforeString2OnPage(String pageContents, String string1, String string2)
  {
    int locationOfString1 = pageContents.indexOf(string1);
    int locationOfString2 = pageContents.indexOf(string2);
    assertTrue((locationOfString1 > -1) && (locationOfString1 < locationOfString2));
  }

  private void assertPageDoesNotContain(String pageContents, String undesiredText)
  {
    assertTrue(pageContents.indexOf(undesiredText) == -1);
  }

  // test that page rendered correctly (pretend this was a dynamicaly created page)
  public void testGetInitialPage() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor("/html/formsPageExample.html");

    //did we get the right page?
    assertEquals("HTTPUnit Example: Intro Page 1", webResponse.getTitle());

    //get raw HTML for the page so we can check for some basic things we are expecting
    String pageText = webResponse.getText();

    //simple test to see if something shows up on the page.
    assertTrue(pageText.indexOf("Intro Page 1") > -1);

    // for some of these text rendering tests I like to use convenience methods like these...

    // also want to make sure some special formatting was there
    assertPageDoesContain(pageText, "<H2 align=\"center\">HTTPUnit Example: Intro Page 1</H2>");

    // may want to test that some thing (like an error message?) does NOT appear on the screen
    assertPageDoesNotContain(pageText, "Fatal error occurred:");

    // if order of information on the screen was important
    assertString1appearsBeforeString2OnPage(pageText, "Intro Page 1", "Different Kinds of Form Inputs");

  }

  public void testGetInitialPageForm() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE1_TITLE);

    // one way to get the form if you know there is only 1 on the page
    WebForm formFromArray = webResponse.getForms()[0];
    assertNotNull(formFromArray);

    // or modify your html to add id= to the form tag
    //<FORM METHOD="POST" ACTION="/html/page2.html" name="FormName" id="FormId">
    WebForm formFromId = webResponse.getFormWithID(FORM_ID);
    assertNotNull(formFromId);

    // or modify your html to add name= to the form tag
    WebForm formFromName = webResponse.getFormWithName("FormName");
    assertNotNull(formFromName);

    //all 3 methods got the same form
    assertEquals(formFromArray, formFromName);
    assertEquals(formFromName, formFromId);
  }

  public void testGettingFormValues() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE1_TITLE);

    WebForm webForm = webResponse.getFormWithID(FORM_ID);
    assertNotNull(webForm);

    String[] paramNames = webForm.getParameterNames();
    for (int i = 0; i < paramNames.length; i++)
    {
      String paramName = paramNames[i];
      System.out.println("paramName : " + paramName);
      String[] paramValues = webForm.getParameterValues(paramName);
      for (int j = 0; j < paramValues.length; j++)
      {
        String paramValue = paramValues[j];
        System.out.println(" = " + paramValue);
      }
    }
  }

  public static final String TEXT_INPUT = "textInput";
  public static final String TEXT_INPUT_DISABLED = "textInputDisabled";
  public static final String TEXT_INPUT_READONLY = "textInputReadonly";

  public void testSettingFormValuesTextField() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE1_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    // text field (enabled & writable)
    // <INPUT TYPE="TEXT" NAME="textInput" VALUE="" SIZE="45" MAXLENGTH="45">
    assertEquals("", webForm.getParameterValue(TEXT_INPUT));
    assertTrue(webForm.isTextParameter(TEXT_INPUT));
    assertFalse(webForm.isDisabledParameter(TEXT_INPUT));
    assertFalse(webForm.isReadOnlyParameter(TEXT_INPUT));
    webForm.setParameter(TEXT_INPUT, "newValue");
    assertEquals("newValue", webForm.getParameterValue(TEXT_INPUT));

    // text field (disabled)
    //<INPUT TYPE="TEXT" NAME="textInputDisabled" VALUE="this is disabled" SIZE="45" MAXLENGTH="45" disabled="true">
    assertEquals("this is disabled", webForm.getParameterValue(TEXT_INPUT_DISABLED));
    assertTrue(webForm.isTextParameter(TEXT_INPUT_DISABLED));
    assertTrue(webForm.isDisabledParameter(TEXT_INPUT_DISABLED));
    assertTrue(webForm.isReadOnlyParameter(TEXT_INPUT_DISABLED));  //this is surprising (see line 219)!
    //note -- trying to set a static value throws a MissingParameterValueException -- can't do this:
    // webForm.setParameter(TEXT_INPUT_DISABLED, "newValue");

    // text field (readonly)
    //<INPUT TYPE="TEXT" NAME="textInputReadonly" VALUE="this is readonly" SIZE="45" MAXLENGTH="45" readonly="true">
    assertEquals("this is readonly", webForm.getParameterValue(TEXT_INPUT_READONLY));
    assertTrue(webForm.isTextParameter(TEXT_INPUT_READONLY));
    assertFalse(webForm.isDisabledParameter(TEXT_INPUT_READONLY));
    assertTrue(webForm.isReadOnlyParameter(TEXT_INPUT_READONLY));
    //note -- trying to set a static value throws a MissingParameterValueException -- can't do this:
    //webForm.setParameter(TEXT_INPUT_READONLY, "newValue");
  }

  public static final String PASSWORD_INPUT = "passwordInput";

  public void testSettingFormValuesPasswordField() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE1_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    // password field
    //<INPUT TYPE="PASSWORD" NAME="passwordInput" VALUE="" SIZE="45" MAXLENGTH="45">
    assertEquals("", webForm.getParameterValue(PASSWORD_INPUT));
    assertTrue(webForm.isTextParameter(PASSWORD_INPUT));
    webForm.setParameter(PASSWORD_INPUT, "newValue");
    assertEquals("newValue", webForm.getParameterValue(PASSWORD_INPUT));
  }

  public static final String HIDDEN_INPUT = "hiddenInput";

  public void testSettingFormValuesHiddenField() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE1_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    // hidden field
    //<INPUT TYPE="HIDDEN" NAME="hiddenInput" VALUE="hiddenValue">
    assertEquals("hiddenValue", webForm.getParameterValue(HIDDEN_INPUT));
    assertTrue(webForm.isHiddenParameter(HIDDEN_INPUT));
    assertFalse(webForm.isReadOnlyParameter(HIDDEN_INPUT)); // the disabled input is readonly but this is not?
    //note -- trying to set a static value throws a MissingParameterValueException -- can't do this:
    //webForm.setParameter(HIDDEN_INPUT, "newValue");
  }

  public static final String RADIO_INPUT = "radioInput";

  public void testSettingFormValuesRadioField() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE1_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    //radio buttons
    //<input type="radio" name="radioInput" value="radio1" checked="true">radio button 1</input>
    //<input type="radio" name="radioInput" value="radio2">radio button 2</input>
    assertEquals("radio1", webForm.getParameterValue(RADIO_INPUT));
    webForm.setParameter(RADIO_INPUT, "radio2");
    assertEquals("radio2", webForm.getParameterValue(RADIO_INPUT));
    //note trying to set this to a non existant value throws IllegalParameterValueException -- can't do this:
    //webForm.setParameter(RADIO_INPUT, "junk");
    //try to set both at once throws this :
    // FormParameter$UnusedParameterValueException: Attempted to assign to parameter 'radioInput' the extraneous value 'radio2'.
    //String[] tryToSetBoth = {"radio1", "radio2"};
    //webForm.setParameter(RADIO_INPUT, tryToSetBoth);
    // But radio buttons do not have a convenience setter method like checkbox does....
    // and checkbox convenience method does not work either:
    // com.meterware.httpunit.FormParameter$IllegalCheckboxParameterException:
    // Attempted to invoke method 'setCheckbox' for parameter 'radioInput/radio1', which is not a unique checkbox control.
    //webForm.setCheckbox(RADIO_INPUT, "radio1", true);
    //assertEquals("radio1", webForm.getParameterValue(RADIO_INPUT));
  }

  public void testSettingFormValuesCheckBoxes() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE1_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    //check boxes with unique names
    //<input type="checkbox" name="checkBoxInput1" value="true" checked="true">check box 1</input>
    //<input type="checkbox" name="checkBoxInput2" value="true" checked="true">check box 2</input>
    //<input type="checkbox" name="checkBoxInput3" value="true" checked="true">check box 3</input>
    assertEquals("true", webForm.getParameterValue("checkBoxInput1"));
    assertEquals("true", webForm.getParameterValue("checkBoxInput2"));
    assertEquals("true", webForm.getParameterValue("checkBoxInput3"));
    // this will throw FormParameter$UnusedParameterValueException  -- MUST use setCheckbox
    //webForm.setParameter("checkBoxInput1", "false");
    webForm.setCheckbox("checkBoxInput1", false);
    assertEquals(null, webForm.getParameterValue("checkBoxInput1"));

    //check boxes with same name -- unique values
    //<input type="checkbox" name="aCheckbox" value="checkBoxA" checked="true">check box 1</input>
    //<input type="checkbox" name="aCheckbox" value="checkBoxB" checked="true">check box 2</input>
    //<input type="checkbox" name="aCheckbox" value="checkBoxC" checked="true">check box 3</input>
    //note - this works even though there are multiple values for this parameter.  Just get the first one -- seems dangerous?
    assertEquals("checkBoxA", webForm.getParameterValue("aCheckbox"));
    //this gets all 3 checked items
    assertEquals(3, webForm.getParameterValues("aCheckbox").length);
    // now uncheck one
    //note extra param to match the value since the names are the same
    webForm.setCheckbox("aCheckbox", "checkBoxB", false);
    String[] nowChecked = webForm.getParameterValues("aCheckbox");
    assertEquals("checkBoxA", nowChecked[0]);
    assertEquals("checkBoxC", nowChecked[1]);
    // note trying to use this version of the method gives FormParameter$IllegalCheckboxParameterException:
    // Attempted to invoke method 'setCheckbox' for parameter 'aCheckbox', which is not a unique checkbox control.
    //  webForm.setCheckbox("aCheckbox", false);
  }

  public static final String SELECT_SINGLE = "selectSingle";
  public static final String SELECT_MULTIPLE = "selectMultiple";

  public void testSettingFormValuesSelectionOptions() throws Exception
  {
    // get the page from the server
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE1_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    //single select options
    //<SELECT NAME="selectSingle" SIZE="1" >
    //    <OPTION  VALUE="" SELECTED/>
    //    <OPTION VALUE="opt1">Option Number 1</option>
    //    <OPTION VALUE="opt2">Option Number 2</option>
    //    <OPTION VALUE="opt3">Option Number 3</option>
    //  </SELECT>
    //note flakyness here- html had to be chaged before this worked
    assertEquals("", webForm.getParameterValue(SELECT_SINGLE));
    assertFalse(webForm.isMultiValuedParameter(SELECT_SINGLE));
    webForm.setParameter(SELECT_SINGLE, "opt2");
    assertEquals("opt2", webForm.getParameterValue(SELECT_SINGLE));
    // must choose one of the allowed values, or you get this:
    // IllegalParameterValueException: May not set parameter 'selectSingle' to 'junk'.
    // Value must be one of: { , opt1, opt2, opt3 }
    //webForm.setParameter(SELECT_SINGLE, "junk");
    webForm.setParameter(SELECT_SINGLE, "");
    assertEquals("", webForm.getParameterValue(SELECT_SINGLE));

    //can't choose more than one for a single select -- throws FormParameter$UnusedParameterValueException
    String[] tryToSetTwo = {"opt1", "opt2"};
    //webForm.setParameter(SELECT_SINGLE, tryToSetTwo);


    //now the multi select
    //<SELECT NAME="selectMultiple" SIZE="3"  multiple="TRUE">
    //    <OPTION  VALUE="" SELECTED></option>
    //    <OPTION VALUE="opt1">Option Number 1</option>
    //    <OPTION VALUE="opt2">Option Number 2</option>
    //    <OPTION VALUE="opt3">Option Number 3</option>
    //  </SELECT>

    // more flakes!  could not handle a self closing option tag
    assertEquals("", webForm.getParameterValue(SELECT_MULTIPLE));
    assertEquals(1, webForm.getParameterValues(SELECT_MULTIPLE).length);
    assertTrue(webForm.isMultiValuedParameter(SELECT_MULTIPLE));
    webForm.setParameter(SELECT_MULTIPLE, "opt2");
    String[] currentValues = webForm.getParameterValues(SELECT_MULTIPLE);
    assertEquals(1, currentValues.length);
    assertEquals("opt2", currentValues[0]);

    //now choose more than one
    webForm.setParameter(SELECT_MULTIPLE, tryToSetTwo);
    currentValues = webForm.getParameterValues(SELECT_MULTIPLE);

    assertEquals(2, currentValues.length);

  }

  public static final String TEXT_AREA = "textArea";

  public void testSettingFormValuesTextAreaField() throws Exception
  {
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE1_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    // text field (enabled & writable)
    //<TEXTAREA NAME="textArea" VALUE="" rows="3" cols="45"></TEXTAREA>
    assertEquals("", webForm.getParameterValue(TEXT_AREA));
    assertTrue(webForm.isTextParameter(TEXT_AREA));
    webForm.setParameter(TEXT_AREA, "newValue\nline 2");
    assertEquals("newValue\nline 2", webForm.getParameterValue(TEXT_AREA));
  }

  public void testResetButton() throws Exception
  {
    webResponse = getWebResponseFor(PAGE1);
    assertCorrectPageTitle(PAGE1_TITLE);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    //initially field is empty, put some text in it & check that it is there
    assertEquals("", webForm.getParameterValue(TEXT_AREA));
    String newText = "blah blah blah";
    webForm.setParameter(TEXT_AREA, newText);
    assertEquals(newText, webForm.getParameterValue(TEXT_AREA));

    // naming flake -- WebResponse, WebForm, but not WebButton?
    Button[] allButtons = webForm.getButtons();

    //first way to get a button -- find it in the array
    Button buttonFromArray = allButtons[1]; //returns these in the order they appear in the form (not specified in api)?
    assertEquals("Reset Form Values", buttonFromArray.getValue());

    //click it & make sure the text got cleared.
    buttonFromArray.click();
    assertEquals("", webForm.getParameterValue(TEXT_AREA));

    //set the text again
    webForm.setParameter(TEXT_AREA, newText);
    assertEquals(newText, webForm.getParameterValue(TEXT_AREA));

    //get the button by ID this time, click it & make sure it worked.
    Button buttonById = webForm.getButtonWithID("resetButtonId");
    buttonById.click();
    assertEquals("", webForm.getParameterValue(TEXT_AREA));

    assertEquals(buttonFromArray, buttonById);

    //but why no getButtonWithName method?????
  }

  public void testSubmitButton() throws Exception
  {
   //<INPUT TYPE="submit" VALUE="Submit Form" id="submitButtonId" name="submitButtonName">

    webResponse = getWebResponseFor(PAGE1);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    //four ways to find the button
    Button[] allButtons = webForm.getButtons();
    Button buttonFromAllArray = allButtons[0];

    Button[] submitButtons = webForm.getSubmitButtons();
    Button buttonFromSubmitArray = submitButtons[0];

    Button buttonByName = webForm.getSubmitButton("submitButtonName");  // method is not getSubmitButtonWithName??

    Button buttonById = webForm.getSubmitButtonWithID("submitButtonId");

    assertEquals("Submit Form", buttonFromAllArray.getValue());
    assertEquals("Submit Form", buttonFromSubmitArray.getValue());
    assertEquals("Submit Form", buttonByName.getValue());
    assertEquals("Submit Form", buttonById.getValue());
  }

  public void testScreenNavigation_ByButtonClick() throws Exception
  {
    webResponse = getWebResponseFor(PAGE1);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);
    Button buttonByName = webForm.getSubmitButton("submitButtonName");
    buttonByName.click();

    //note we need to get a handle to the new webresponse object, the one we have is stale:
    assertCorrectPageTitle("Intro Page 1");

    //need to do this:
    webResponse = conversation.getCurrentPage();
    assertCorrectPageTitle(PAGE2_TITLE);
  }

  public void testScreenNavigation_ByFormSubmit() throws Exception
  {
    webResponse = getWebResponseFor(PAGE1);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    // this one returns the new webresponse, no need for the extra getCurrentPage call
    webResponse = webForm.submit();

    //webResponse = conversation.getCurrentPage();
    assertCorrectPageTitle("Page 2 - tables");
  }

  public void testScreenNavigation_ByFormSubmitWithButton() throws Exception
  {
    webResponse = getWebResponseFor(PAGE1);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);
    SubmitButton buttonByName = webForm.getSubmitButton("submitButtonName");

    // if there were more than one submit button on the form then do this way
    webResponse = webForm.submit(buttonByName);

    //webResponse = conversation.getCurrentPage();
    assertCorrectPageTitle("Page 2 - tables");
  }

}
