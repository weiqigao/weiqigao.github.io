package com.monsanto.tcc.httpunitExamples.IntegrationTests;

import com.meterware.httpunit.*;

/*
 * com.monsanto.tcc.httpunitExamples.IntegrationTests.FormsExamples_IT was created
 * on Apr 19, 2005 2:51:56 PM using Monsanto resources and is the sole property of Monsanto.  
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's 
 * copyright.
 *
 * Author: lkpeter
 */

public class TableExamples_IT extends HttpunitTestUtils
{


  public void testScreenNavigation_ByDirectUrl() throws Exception
  {
    //bypass the first page & go directly to page2.  This can be very useful for testing
    //screens that depend on something being on the session will behave gracefully when
    // expected items are not on the session.
    webResponse = getWebResponseFor(PAGE2);

    //webResponse = conversation.getCurrentPage();
    assertCorrectPageTitle("Page 2 - tables");
  }

  public void test_WaysToFindTables() throws Exception
  {
    webResponse = getWebResponseFor(PAGE2);

    // multiple ways to find the table...
    WebTable[] allTables = webResponse.getTables();
    assertEquals(2, allTables.length);
    WebTable tableData1 = allTables[0];

    //uses the value of the first cell
    WebTable tableData2 = webResponse.getTableStartingWith("first table, first row, column 1");
    //uses the first part of the value of the first cell
    WebTable tableData3 = webResponse.getTableStartingWithPrefix("first table");
    WebTable tableData4 = webResponse.getTableWithID("tableId");
    //WebTable tableData5 = webResponse.getTableWithSummary("");

    //notice there is not getTableByName ??????

    assertEquals(10, tableData1.getColumnCount());
    assertEquals(5, tableData1.getRowCount());

    assertEquals(10, tableData2.getColumnCount());
    assertEquals(5, tableData2.getRowCount());

    assertEquals(10, tableData3.getColumnCount());
    assertEquals(5, tableData3.getRowCount());

    assertEquals(10, tableData4.getColumnCount());
    assertEquals(5, tableData4.getRowCount());

    //assertEquals(10, tableData5.getColumnCount());
    //assertEquals(5, tableData5.getRowCount());
  }


  public void test_TableCellValues() throws Exception
  {
    webResponse = getWebResponseFor(PAGE2);

    WebTable tableData = webResponse.getTableWithID("tableId");

    // when things like order matter it helps to dislay results in a table.
    // now we can look at specific cells & make sure things are in the right place
    // a little cleaner than the "asser x is before y" used in an earlier example

    //note the index is zero based
    assertEquals("first table, third row, column 3", tableData.getCellAsText(2,2));
  }

  public void test_TableCellObjects() throws Exception
  {
    webResponse = getWebResponseFor(PAGE2);

    // if you are testing for special formatting of the data...
    WebTable tableData = webResponse.getTableWithID("tableId");
    TableCell cell = tableData.getTableCell(2,2);
    assertEquals(1, cell.getRowSpan());
    assertEquals(1, cell.getColSpan());
  }

}
