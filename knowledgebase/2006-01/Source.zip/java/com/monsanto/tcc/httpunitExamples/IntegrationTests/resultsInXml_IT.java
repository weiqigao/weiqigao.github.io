package com.monsanto.tcc.httpunitExamples.IntegrationTests;

import junit.framework.TestCase;
import com.meterware.httpunit.*;

import java.io.IOException;

import org.xml.sax.SAXException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

/*
 * com.monsanto.tcc.httpunitExamples.IntegrationTests.FormsExamples_IT was created
 * on Apr 19, 2005 2:51:56 PM using Monsanto resources and is the sole property of Monsanto.  
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's 
 * copyright.
 *
 * Author: lkpeter
 */

public class resultsInXml_IT extends HttpunitTestUtils
{
  public static final String XML_PAGE = "/html/resultAsXml.xml";

  public void testDomWithXml() throws Exception
  {
    webResponse = getWebResponseFor(XML_PAGE);

    Document dom = webResponse.getDOM();
    NodeList nodeList = dom.getElementsByTagName("item1");

    assertEquals(2, nodeList.getLength());

    assertEquals("value1", nodeList.item(0).getFirstChild().getNodeValue());
  }

}
