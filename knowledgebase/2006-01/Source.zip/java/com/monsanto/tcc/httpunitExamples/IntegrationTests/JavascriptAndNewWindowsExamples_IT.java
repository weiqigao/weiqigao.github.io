package com.monsanto.tcc.httpunitExamples.IntegrationTests;

import com.meterware.httpunit.*;

/*
 * com.monsanto.tcc.httpunitExamples.IntegrationTests.FormsExamples_IT was created
 * on Apr 19, 2005 2:51:56 PM using Monsanto resources and is the sole property of Monsanto.  
 * Any duplication of the code and/or logic is a direct infringement of Monsanto's 
 * copyright.
 *
 * Author: lkpeter
 */

public class JavascriptAndNewWindowsExamples_IT extends HttpunitTestUtils
{
  private static final String PAGE3_TITLE = "page in new window";
  private static final String SUBMIT_BUTTON = "submitButtonName";

  public void testLastPage_buttonClick() throws Exception
  {
    webResponse = getWebResponseFor(PAGE2);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);
    Button buttonByName = webForm.getSubmitButton(SUBMIT_BUTTON);

    buttonByName.click();

    // the new response opened in a new window, but doing this just gives the original window :(
    webResponse = conversation.getCurrentPage();
    assertCorrectPageTitle(PAGE2_TITLE);

    // need to do this:
    WebWindow[] windows = conversation.getOpenWindows();
    assertEquals(2, windows.length);
    webResponse = windows[1].getCurrentPage();
    assertCorrectPageTitle(PAGE3_TITLE);

    // or this (where window name is the target= value from the page that invoked it:
    //<FORM METHOD="POST" ACTION="lastPage.html" target="window2">

    webResponse = conversation.getOpenWindow("window2").getCurrentPage();
    assertCorrectPageTitle(PAGE3_TITLE);
  }

  public void testLastPage_formSubmit() throws Exception
  {
    webResponse = getWebResponseFor(PAGE2);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    // the new response opened in a new window, the form.submit returns the new window,
    // don't need the extra steps to get the right window in this case.
    webResponse = webForm.submit();
    assertCorrectPageTitle(PAGE3_TITLE);
  }

  public void testLastPage_disabledSubmitButton() throws Exception
  {
    webResponse = getWebResponseFor(PAGE3);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);

    // the only submit button on this page is disabled....
    //webResponse = webForm.submit();
    // will do this: WebForm$DisabledSubmitButtonException: The specified button (name='submitButtonName'
    // value='Submit Form' is disabled and may not be used to submit this form.


    Button buttonByName = webForm.getSubmitButton(SUBMIT_BUTTON);
    //buttonByName.click();
    //try try this & get a slightly different error:
    //java.lang.IllegalStateException: Button 'submitButtonName' is disabled and may not be clicked.
  }

  //in this example the submit button is initally disabled & is not avaialble until the
  // enableButton is clicked and runs some javascript to enable it.  This is similar to
  //cases where you might want to require input on a form before allowing the submit
  // button to be used.
  public void testLastPage_jsEnableSubmit() throws Exception{
    webResponse = getWebResponseFor(PAGE3);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);
    Button formValidate = webForm.getButtonWithID("enableSubmit");
    formValidate.click();

    //now this will work without throwing the excpetion
    Button buttonByName = webForm.getSubmitButton(SUBMIT_BUTTON);
    buttonByName.click();
    webResponse = conversation.getCurrentPage();
    assertCorrectPageTitle(PAGE1_TITLE);
  }

  public void testLastPage_jsAlert() throws Exception{
    webResponse = getWebResponseFor(PAGE3);
    WebForm webForm = webResponse.getFormWithID(FORM_ID);
    Button jsAlertButton = webForm.getButtonWithID("jsAlert");
    jsAlertButton.click();
    assertEquals("this is a javascript alert!", conversation.getNextAlert());
  }

  // javascript in this test is not supported, get an error that does not make this clear...
  public void testDialogsInJavascript_notSupported() throws Exception{
    webResponse = getWebResponseFor(PAGE3);
    WebLink link = webResponse.getLinkWith("calendar dialog javascript example");
    link.click();
  }

  // Simple dialog window can be tested:
  public void testSimpleDialogsInJavascript() throws Exception{
    //DialogResponder responder = new DialogAdapter();
    //conversation.setDialogResponder(responder);
    webResponse = getWebResponseFor(PAGE3);
    WebLink link = webResponse.getLinkWith("simple dialog javascript example");
    webResponse = link.click(); //note this is NOT the new window ;(
    //System.out.println("responder.getConfirmation() = " + responder.getConfirmation(""));

   //new window opened in javascript function
    webResponse = getNewlyOpenedBrowserWindow();
    assertCorrectPageTitle("dialog");
    WebForm webForm = webResponse.getFormWithID(FORM_ID);
    Button closeIt = webForm.getButtonWithID("close me");
    closeIt.click();

    //should be back to original window now
    WebWindow[] windows = conversation.getOpenWindows();
    assertEquals(1, windows.length);

  }
}
