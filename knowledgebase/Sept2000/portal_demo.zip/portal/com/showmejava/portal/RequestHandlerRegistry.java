package com.showmejava.portal;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;


/**
 * Keeps track of all registered RequestHandler objects.  Each ServletContext
 * has an instance of RequestHandlerRegistry.  Since several Servlets may
 * share the same ServletContext, this registry maps Servlets to structures
 * that hold handlers.
 *
 * @author Eric M. Burke
 * @version $Id: RequestHandlerRegistry.java,v 1.2 2000/08/10 01:45:03 ericb Exp $
 */
public class RequestHandlerRegistry implements Serializable {

    // Servlets are used as the key, and structures of request handlers are
    // used as the values in this map
    private Map servletToStructMap = new HashMap();


    /**
     * Load this registry with request handlers for a given Servlet.  This
     * method should be called from the Servlet's init method.
     *
     * @param servlet the Servlet instance to register request handlers for.
     * @param defaultRequestHandler the handler to use by default.
     * @param requestHandlers an array of handler objects.
     * @exception DuplicateIDException if any of the request handlers
     *           have duplicate pathInfos.
     */
    public void load(PortalServlet servlet,
            RequestHandler defaultRequestHandler,
            RequestHandler[] requestHandlers) throws DuplicateIDException {

        // don't register a Servlet more than once
        if (servletToStructMap.containsKey(servlet)) {
            return;
        }

        servletToStructMap.put(servlet, new ServletStruct(
                defaultRequestHandler, requestHandlers));
    }

    /**
     * Remove a Servlet and its associated handlers from this registry.  This
     * method is normally called from the Servlet's destroy method.
     *
     * @param servlet the Servlet to unregister.
     */
    public void unload(PortalServlet servlet) {
        if (servletToStructMap.containsKey(servlet)) {
            servletToStructMap.remove(servlet);
        }
    }

    /**
     * Locate a request handler by looking at the extra path info which
     * is part of the request.  If the request handler is not found, then
     * return the default handler.
     *
     * @param servlet the Servlet to locate a handler for.
     * @param req the request from the client to the Servlet.
     * @exception IllegalArgumentException if the Servlet was not registered.
     */
    public RequestHandler getRequestHandler(PortalServlet servlet,
            HttpServletRequest req) {
        ServletStruct struct = (ServletStruct) servletToStructMap.get(servlet);
        if (struct != null) {
            return struct.getRequestHandler(req);
        }
        throw new IllegalArgumentException("Servlet was not registered.");
    }


    // a helper class that keeps track of all registered request handlers
    // for a given Servlet.
    private static class ServletStruct {
        private Map pathToHandlerMap;
        private RequestHandler defaultHandler;

        // construct a new structure.
        ServletStruct(RequestHandler defaultHandler,
                      RequestHandler[] handlers) throws DuplicateIDException {
            this.defaultHandler = defaultHandler;
            pathToHandlerMap = new HashMap();
            for (int i=0; i<handlers.length; i++) {
                String curPathInfo = handlers[i].getPathInfo();
                if (!pathToHandlerMap.containsKey(curPathInfo)) {
                    pathToHandlerMap.put(curPathInfo, handlers[i]);
                } else {
                    throw new DuplicateIDException(curPathInfo);
                }
            }
        }

        // locate a request handler, using extra path info from the request
        public RequestHandler getRequestHandler(HttpServletRequest req) {
            String pathInfo = req.getPathInfo();
            if (pathInfo != null && pathInfo.length() > 1) {
                int firstSlashPos = pathInfo.indexOf("/");
                int secondSlashPos = pathInfo.indexOf("/", 1);

                if (firstSlashPos > -1) {
                    if (secondSlashPos > -1) {
                        pathInfo = pathInfo.substring(firstSlashPos+1,
                                secondSlashPos);
                    } else {
                        pathInfo = pathInfo.substring(firstSlashPos+1);
                    }
                }
                if (pathToHandlerMap.containsKey(pathInfo)) {
                    return (RequestHandler) pathToHandlerMap.get(pathInfo);
                }
            }

            return defaultHandler;
        }
    }
}

