package com.showmejava.portal;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Base class for Servlets in this framework.  The primary function of this
 * Servlet is to locate and invoke request handlers.  In order to use this
 * framework, you must create a subclass of this Servlet and override
 * the abstract methods.
 * <p>
 * This Servlet supports GET and POST requests by default.  In order to
 * disable either of those, simply override the doGet or doPost method
 * and return an error to the client.
 *
 * @author Eric M. Burke
 * @version $Id: PortalServlet.java,v 1.1 2000/07/31 00:29:37 ericb Exp $
 */
public abstract class PortalServlet extends HttpServlet {

    /**
     * Register this Servlet with the RequestHandlerRegistry.
     *
     * @param config the Servlet configuration, passed to the superclass.
     * @exception ServletException if any Exceptions occur, a log file entry
     * is written and an UnavailableException is thrown.
     */
    public void init(ServletConfig config) throws ServletException {
        super.init(config);

        try {
            RequestHandlerRegistry rhReg = getRegistry();
            rhReg.load(this, getDefaultRequestHandler(),
                    getRequestHandlers());
        } catch (Exception ex) {
            log(ex.getMessage(), ex);
            throw new UnavailableException(ex.getMessage());
        }
    }

    /**
     * Unregister this Servlet from the RequestHandlerRegistry.
     */
    public void destroy() {
        super.destroy();
        RequestHandlerRegistry rhr = getRegistry();
        rhr.unload(this);
    }

    /**
     * This method will only be called once, and the returned request
     * handlers will be reused for the lifetime of this Servlet.
     *
     * @return an array of new RequestHandler objects.  This array does
     * not need to include the default RequestHandler.
     */
    protected abstract RequestHandler[] getRequestHandlers();

    /**
     * The returned RequestHandler will be used whenever a request cannot
     * be mapped to any of the other request handlers.  The default
     * request handler is typically your application home page.
     *
     * @return the default RequestHandler.
     */
    protected abstract RequestHandler getDefaultRequestHandler();


    /**
     * This method simply calls the doService method.  Normally the only
     * reason you would override this method is to disable GET requests.
     *
     * @param req the request from the client.
     * @param res the response to the client.
     * @exception IOException if an I/O error occurs.
     * @exception ServletException if any other error occurs.
     */
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws IOException, ServletException {
        doService(req, res);
    }

    /**
     * This method simply calls the doService method.  Normally the only
     * reason you would override this method is to disable POST requests.
     *
     * @param req the request from the client.
     * @param res the response to the client.
     * @exception IOException if an I/O error occurs.
     * @exception ServletException if any other error occurs.
     */
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException, ServletException {
        doService(req, res);
    }


    /**
     * This method handles requests from the client.  Normally you will not
     * override this method.  It does the following:
     * <ul>
     *   <li>Locates the RequestHandlerRegistry instance
     *   <li>Gets the appropriate RequestHandler object from the registry
     *   <li>Asks the RequestHandler to handle the request
     * </ul>
     *
     * @param req the request from the client.
     * @param res the response to the client.
     * @exception IOException if an I/O error occurs.
     * @exception ServletException if any other error occurs.
     */
    protected void doService(HttpServletRequest req, HttpServletResponse res)
            throws IOException, ServletException {
        RequestHandlerRegistry rhReg = getRegistry();

        // if the requestHandlerID is null, the registry will return its
        // default handler
        RequestHandler rh = rhReg.getRequestHandler(this, req);
        rh.handleRequest(req, res);
    }


    /**
     * Locates the request handler registry from the Servlet context.
     */
    protected RequestHandlerRegistry getRegistry() {
        ServletContext context = getServletContext();

        RequestHandlerRegistry rhReg = (RequestHandlerRegistry)
                context.getAttribute("RequestHandlerRegistry");
        if (rhReg == null) {
            synchronized (this) {
                if (rhReg == null) {
                    rhReg = new RequestHandlerRegistry();
                    context.setAttribute("RequestHandlerRegistry", rhReg);
                }
            }
        }
        return rhReg;
    }
}

