package com.showmejava.portal;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * A renderer that forwards to a static page (such as an HTML file or
 * a JSP) using RequestDispatcher.  The RequestDispatcher is obtained from
 * the Servlet request object, rather than the Servlet context.
 *
 * @author Eric M. Burke
 * @version $Id: DispatchRenderer.java,v 1.1 2000/07/31 00:29:36 ericb Exp $
 */
public class DispatchRenderer extends PageRenderer {
 
    private String path;

    /**
     * @param path the resource to forward (dispatch) to.
     */
    public DispatchRenderer(String path) {
        this.path = path;
    }

    /**
     * Render a page to a Servlet response.  A RequestDispatcher is used
     * to forward the user to the specified path.
     *
     * @param req the request from the client to this Servlet.
     * @param res the response from this Servlet to the client.
     * @exception IOException standard Servlet exception.
     * @exception ServletException standard Servlet exception.
     */
    public void render(HttpServletRequest req, HttpServletResponse res)
            throws IOException, ServletException {
        RequestDispatcher rd = req.getRequestDispatcher(path);
        rd.forward(req, res);
    }
}

