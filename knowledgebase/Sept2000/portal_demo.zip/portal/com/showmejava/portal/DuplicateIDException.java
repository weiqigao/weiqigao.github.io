
package com.showmejava.portal;

/**
 * Indicates that a "unique ID" was not unique.
 *
 * @author Eric M. Burke
 * @version $Id: DuplicateIDException.java,v 1.1 2000/07/31 00:29:37 ericb Exp $
 */
public class DuplicateIDException extends Exception {

    /**
     * @param idName the ID which was not unique.
     */
    public DuplicateIDException(String idName) {
        super("Duplicate ID: " + idName);
    }
}
