package com.showmejava.portal;

import javax.servlet.http.*;

/**
 * Simple utility methods.
 *
 * @author Eric M. Burke
 * @version $Id: HTMLUtil.java,v 1.1 2000/07/31 00:29:37 ericb Exp $
 */
public class HTMLUtil {

    /**
     * Get a parameter from a request.  If the parameter is null, return
     * the default value.  Otherwise, trim all leading and trailing 
     * whitespace.
     */
    public static String getParameter(HttpServletRequest request,
            String parameterName, String defaultValue) {
        String value = request.getParameter(parameterName);
        return (value == null) ? defaultValue : value.trim();
    }

    /**
     * Search for and replace characters which may not display
     * correctly in HTML.
     *
     * @param a string which may contain HTML control characters.
     * @return the string with HTML control characters replaced.
     */
    public static String escape(String str) {
        if (str == null) {
            return "";
        }
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            switch (ch) {
            case '<':
                buf.append("&lt;");
                break;
            case '>':
                buf.append("&gt;");
                break;
            case '&':
                buf.append("&amp;");
                break;
            case '\'':
                buf.append("&#039;");
                break;
            case '"':
                buf.append("&quot;");
                break;
            default:
                buf.append(ch);
            }
        }
        return buf.toString();
    }

    /**
     * Replace newline characters with the br tag.
     */
    public static String insertBreaks(String str) {
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (ch == '\n') {
                buf.append("<br>\n");
            } else {
               buf.append(ch);
            }
        }
        return buf.toString();
    }
}
