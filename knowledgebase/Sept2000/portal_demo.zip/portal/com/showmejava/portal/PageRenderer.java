package com.showmejava.portal;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Abstract base class for all page renderers.  Derived classes must
 * override the render method.
 *
 * @author Eric M. Burke
 * @version $Id: PageRenderer.java,v 1.1 2000/07/31 00:29:37 ericb Exp $
 */
public abstract class PageRenderer {

    /**
     * Render a page to a Servlet response.  Any kind of content can be
     * rendered - this is entirely up to the subclass.  The subclass is
     * responsible for setting the content type, obtaining the OutputStream
     * or PrintWriter, and generating the entire response.
     *
     * @param req the request from the client to this Servlet.
     * @param res the response from this Servlet to the client.
     * @exception IOException standard Servlet exception.
     * @exception ServletException standard Servlet exception.
     */
    public abstract void render(HttpServletRequest req, HttpServletResponse res)
            throws IOException, ServletException;
}

