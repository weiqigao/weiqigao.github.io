package com.showmejava.portal;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Abstract base class which makes it easier to create HTML pages.
 *
 * @author Eric M. Burke
 * @version $Id: HTMLPageRenderer.java,v 1.1 2000/07/31 00:29:37 ericb Exp $
 */
public abstract class HTMLPageRenderer extends PageRenderer {

    /**
     * This method has been overridden from the abstract render method
     * in the superclass.  It does the following:
     * <ul>
     *   <li>calls getHTML
     *   <li>sets the content type to text/html
     *   <li>sets the content length
     *   <li>writes the HTML to the response's PrintWriter
     * </ul>
     *
     * @param req the request from the client to this Servlet.
     * @param res the response from this Servlet to the client.
     * @exception IOException standard Servlet exception.
     * @exception ServletException standard Servlet exception.
     */
    public void render(HttpServletRequest req, HttpServletResponse res)
            throws IOException, ServletException {
        String html = getHTML(req, res);
        res.setContentType("text/html");
        res.setContentLength(html.length());
        res.getWriter().print(html);
    }

    /**
     * Derived classes should return an HTML web page.
     *
     * @param req the request from the client to this Servlet.
     * @param res the response from this Servlet to the client.
     * @return an HTML web page.
     * @exception IOException standard Servlet exception.
     * @exception ServletException standard Servlet exception.
     */
    public abstract String getHTML(HttpServletRequest req,
            HttpServletResponse res) throws IOException, ServletException;
}

