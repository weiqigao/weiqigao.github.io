package com.showmejava.portal;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Abstract base class for all request handlers.  Subclasses are responsible
 * for processing requests and returning the next page renderer to display.
 * <p>
 * Subclasses must be <b>stateless</b>.  The request handler objects will be
 * reused and shared by all clients, so they cannot maintain state between
 * requests.  In general, the best way to avoid state-related threading
 * problems is to avoid private data of any kind.
 * <p>
 *
 * @author Eric M. Burke
 * @version $Id: RequestHandler.java,v 1.2 2000/08/10 01:45:03 ericb Exp $
 */
public abstract class RequestHandler {

    // this private field is thread-safe, because it is only set once in
    // the constructor, and String objects are immutable.
    private String pathInfo;

    /**
     * Construct a new request handler.  Derived classes should provide
     * a no-arg constructor which invokes this constructor via the "super"
     * keyword.
     * <p>
     * The pathInfo should be unique within a particular web application.
     * This is a directory, such as "logon", which will eventually be
     * appended to the URL as extra path information.  Only the first
     * part of extra path information is examined.
     * <p>
     * For example, a web app name "catalog" would have the following
     * URL to the logon request handler:
     * <pre>
     * http://hostname/catalog/logon
     * </pre>
     * The following URL would have the same effect:
     * <pre>
     * http://hostname/catalog/logon/somethingElseHere
     * </pre>
     *
     * @param pathInfo a unique identifier for this request handler,
     * such as "logon".
     */
    public RequestHandler(String pathInfo) {
        this.pathInfo = pathInfo;
    }

    /**
     * Handle a single request from a client.  This is a template method
     * which calls the doHandleRequest abstract method.
     *
     * @param req the request.
     * @param res the response.
     * @exception IOException a standard Servlet exception.
     * @exception ServletException a standard Servlet exception.
     */
    public final void handleRequest(HttpServletRequest req,
            HttpServletResponse res) throws IOException, ServletException {
        PageRenderer pr = doHandleRequest(req);
        pr.render(req, res);
    }

    /**
     * Derived classes must override this method.  Typical usage is to
     * parse form request parameters and return the next page to display.
     * If the page renderer is thread-safe, you can simply return the same
     * object over and over.  On the other hand, you can also create a
     * new instance each time this method is called if you need to store
     * state information in the renderer.
     *
     * @param req the request from the client.
     * @return the page renderer for the next page to display.
     */
    protected abstract PageRenderer doHandleRequest(HttpServletRequest req);


    /**
     * The request handler pathInfo must be unique - it cannot collide with any
     * other request handler pathInfos in the same web application context.
     *
     * @return the path information pattern to use for this request handler.
     */
    public String getPathInfo() {
        return pathInfo;
    }
}

