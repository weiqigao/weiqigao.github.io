README.txt

This directory contains the ShowMeJava Web Application Framework.

--------------------------------------------------------------------------
REQUIREMENTS
- Tomcat 3.1 (jakarta.apache.org)
- Java 2, v1.2.2 or better (it may work with 1.1.x, but not tested)
- TOMCAT_HOME and JAVA_HOME environment variables must be set

--------------------------------------------------------------------------
RUNNING THE DEMO:
1.  Copy portaltest.war into Tomcat's webapps directory
2.  Start Tomcat
3.  Visit http://localhost:8080/portaltest

--------------------------------------------------------------------------
BUILDING THE FRAMEWORK AND DEMO:

The actual framework source code can be found in the "com" 
directory.

The "war" directory contains a demo of the framework.
This is a normal web application with JSP files, a deployment
descriptor, and helper classes.

"makewar.bat" is a Windows NT batch file to compile everything.  Once
this has been executed, you should see the following files:

  smj_portal.jar - The framework classes only.  This can be copied
                   to the WEB-INF/lib directory of any of your own
                   web applications.

  portaltest.war - a WAR file which contains an example web app.
                   smj_portal.jar is also copied to the WEB-INF/lib
                   directory of portaltest.war.

install.bat - a Windows NT batch file to install into Tomcat's directory
startup.bat - a convenience to start Tomcat
shutdown.bat - a convenience to shut down Tomcat

