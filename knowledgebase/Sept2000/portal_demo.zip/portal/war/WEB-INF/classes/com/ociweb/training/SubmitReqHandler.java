package com.ociweb.training;

import com.showmejava.portal.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class SubmitReqHandler extends RequestHandler {
    public static String PATH_INFO() {
        return "submit";
    }

    public SubmitReqHandler() {
        super(PATH_INFO());
    }

    public static String getURL(HttpServletRequest request,
            HttpServletResponse response) {
        // the context path is the name of the war file minus ".war"
        return response.encodeURL(request.getContextPath()
                + "/register/" + PATH_INFO());
    }

    protected PageRenderer doHandleRequest(HttpServletRequest req) {
            HttpSession session = req.getSession(true);
        Registration reg = (Registration) session.getAttribute("registration");

        if (reg == null || !reg.isValid()) {
            // return to the customer information page
            return new DispatchRenderer("/custInfo.jsp");
        }

        // if this were a real system, we would submit the registration
        // to the database at this point

        session.removeAttribute("registration");

        // the "/" is relative to the context path
        return new DispatchRenderer("/thanks.jsp");
    }
}

