package com.ociweb.training;

public class Registration {
    private String firstName;
    private String lastName;
    private String phone;
    private String email;

    public Registration(String firstName, String lastName, String phone,
            String email) {
        this.firstName = (firstName != null) ? firstName.trim() : "";
        this.lastName = (lastName != null) ? lastName.trim() : "";
        this.phone = (phone != null) ? phone.trim() : "";
        this.email = (email != null) ? email.trim() : "";
    }

    public boolean isValid() {
        return firstName.length() > 0
                && lastName.length() > 0
                && email.length() > 0
                && phone.length() > 0;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }
}

