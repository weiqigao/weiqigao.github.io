package com.ociweb.training;

import com.showmejava.portal.*;


/**
 * The only subclass of PortalServlet for this web app.
 */
public class RegistrationServlet extends PortalServlet {
    protected RequestHandler[] getRequestHandlers() {
        return new RequestHandler[] {
            new CustInfoReqHandler(),
            new SubmitReqHandler()
        };
    }

    protected RequestHandler getDefaultRequestHandler() {
        return new DefaultReqHandler();
    }
}

