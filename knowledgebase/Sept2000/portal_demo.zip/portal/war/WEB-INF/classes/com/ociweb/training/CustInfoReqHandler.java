package com.ociweb.training;

import com.showmejava.portal.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class CustInfoReqHandler extends RequestHandler {
    public static String PATH_INFO() {
        return "custInfo";
    }

    public CustInfoReqHandler() {
        super(PATH_INFO());
    }

    public static String getURL(HttpServletRequest request,
            HttpServletResponse response) {
        // the context path is the name of the war file minus ".war"
        return response.encodeURL(request.getContextPath()
                + "/register/" + PATH_INFO());
    }

    protected PageRenderer doHandleRequest(HttpServletRequest req) {
        // see if the user hit the Next button
        if (req.getParameter("nextBtn") != null) {
            String firstName = req.getParameter("firstName");
            String lastName = req.getParameter("lastName");
            String phone = req.getParameter("phone");
            String email = req.getParameter("email");

            Registration reg = new Registration(firstName, lastName,
                    phone, email);

            // store the registration info
            HttpSession session = req.getSession(true);
            session.setAttribute("registration", reg);
            if (reg.isValid()) {
                // only move to the next page if the data is valid
                return new DispatchRenderer("/confirm.jsp");
            }
        }

        // the "/" is relative to the context path
        return new DispatchRenderer("/custInfo.jsp");
    }
}

