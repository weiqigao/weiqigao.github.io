package com.ociweb.training;

import com.showmejava.portal.*;
import javax.servlet.http.*;

/**
 * This is a request handler which is used if no other matching
 * handler is located.  It just dispatches to the index page.
 */
public class DefaultReqHandler extends RequestHandler {
    public DefaultReqHandler() {
        super("");
    }

    protected PageRenderer doHandleRequest(HttpServletRequest req) {
        return new DispatchRenderer("/index.html");
    }
}

