package com.ociweb;

import static com.ociweb.Contact.Properties.*;

public class SortContactsJemmy extends AbstractJemmyTestCase {
    private static final String ABC = "_abc";
    private static final String DEF = "_def";
    private static final String GHI = "_ghi";
    private static final String ADD_NEW = "Add New";

    protected void executeTest() {

        populateInputs(GHI);

        pushButton(ADD_NEW);

        populateInputs(DEF);

        pushButton(ADD_NEW);

        populateInputs(ABC);

        clickColumnHeader(0, 1);  //Should sort in ascending alphabetic order

        compareSortedRow(0, ABC);
        compareSortedRow(1, DEF);
        compareSortedRow(2, GHI);

        clickColumnHeader(0, 1);  //Should sort in descending alphabetic order

        compareSortedRow(0, GHI);
        compareSortedRow(1, DEF);
        compareSortedRow(2, ABC);

    }

    private void populateInputs(String suffix) {
        setTextField(fullName.getTooltip(), fullName + suffix);
        setTextField(phone1.getTooltip(), phone1 + suffix);
        setTextField(phone2.getTooltip(), phone2 + suffix);
        setTextField(phone3.getTooltip(), phone3 + suffix);
        setTextField(email.getTooltip(), email + suffix);
        setTextField(homepage.getTooltip(), homepage + suffix);
        setTextField(IMAddress.getTooltip(), IMAddress + suffix);
    }

    private void compareSortedRow(int row, String suffix) {
        assertEquals(fullName + suffix, getTableCellValue(row, 0));
        assertEquals(phone1 + suffix, getTableCellValue(row, 1));
        assertEquals(phone2 + suffix, getTableCellValue(row, 2));
        assertEquals(phone3 + suffix, getTableCellValue(row, 3));
    }
}
