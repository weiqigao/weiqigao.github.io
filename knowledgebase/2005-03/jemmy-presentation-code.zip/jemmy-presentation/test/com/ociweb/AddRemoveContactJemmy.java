package com.ociweb;

import static com.ociweb.Contact.PhoneType.*;
import static com.ociweb.Contact.Properties.*;

public class AddRemoveContactJemmy extends AbstractJemmyTestCase {
    private static final String NAME = "Mario Aquino";
    private static final String PHONE_1 = "314-555-1212";
    private static final String PHONE_2 = "314-777-0000";
    private static final String PHONE_3 = "314-888-1111";
    private static final String EMAIL = "mario@ociweb.com";
    private static final String HOMEPAGE = "http://www.ociweb.com";
    private static final String IM_ADDRESS = "mario_aquino";
    private static final String EMPTY_STRING = "";
    private static final String FOO = "foo";
    private static final String ADD_NEW = "Add New";
    private static final String BAR = "bar";
    private static final String REMOVE = "Remove";

    protected void executeTest() {
        checkInputFieldsInInitializedState();

        setTextField(fullName.getTooltip(), NAME);
        setTextField(phone1.getTooltip(), PHONE_1);
        setComboBox(phone1Type.getTooltip(), Work.name());
        setTextField(phone2.getTooltip(), PHONE_2);
        setComboBox(phone2Type.getTooltip(), Mobile.name());
        setTextField(phone3.getTooltip(), PHONE_3);
        setComboBox(phone3Type.getTooltip(), Mobile.name());

        setTextField(email.getTooltip(), EMAIL);
        setTextField(homepage.getTooltip(), HOMEPAGE);
        setTextField(IMAddress.getTooltip(), IM_ADDRESS);

        pushButton(ADD_NEW);

        checkInputFieldsInInitializedState();

        setTextField(fullName.getTooltip(), FOO);
        setTextField(phone1.getTooltip(), FOO);
        setTextField(phone2.getTooltip(), FOO);
        setTextField(phone3.getTooltip(), FOO);
        setTextField(email.getTooltip(), FOO);
        setTextField(homepage.getTooltip(), FOO);
        setTextField(IMAddress.getTooltip(), FOO);

        pushButton(ADD_NEW);

        checkInputFieldsInInitializedState();

        setTextField(fullName.getTooltip(), BAR);
        setTextField(phone1.getTooltip(), BAR);
        setTextField(phone2.getTooltip(), BAR);
        setTextField(phone3.getTooltip(), BAR);
        setTextField(email.getTooltip(), BAR);
        setTextField(homepage.getTooltip(), BAR);
        setTextField(IMAddress.getTooltip(), BAR);

        clickTableRow(1); //This should be the middle table row

        pushButton(REMOVE); //remove middle table row

        pushButton(REMOVE); //remove last table row

        checkFirstEntryIsDisplayed();

        pushButton(REMOVE); //should do nothing - remove leaves at least one entry in address book

        checkFirstEntryIsDisplayed();
    }

    private void checkFirstEntryIsDisplayed() {
        assertEquals(NAME, getTextFieldValue(fullName.getTooltip()));
        assertEquals(PHONE_1, getTextFieldValue(phone1.getTooltip()));
        assertEquals(Work.name(), getComboBoxValue(phone1Type.getTooltip()));
        assertEquals(PHONE_2, getTextFieldValue(phone2.getTooltip()));
        assertEquals(Mobile.name(), getComboBoxValue(phone2Type.getTooltip()));
        assertEquals(PHONE_3, getTextFieldValue(phone3.getTooltip()));
        assertEquals(Mobile.name(), getComboBoxValue(phone3Type.getTooltip()));
        assertEquals(EMAIL, getTextFieldValue(email.getTooltip()));
        assertEquals(HOMEPAGE, getTextFieldValue(homepage.getTooltip()));
        assertEquals(IM_ADDRESS, getTextFieldValue(IMAddress.getTooltip()));
    }

    private void checkInputFieldsInInitializedState() {

        assertEquals(EMPTY_STRING, getTextFieldValue(fullName.getTooltip()));
        assertEquals(EMPTY_STRING, getTextFieldValue(phone1.getTooltip()));
        assertEquals(Home.name(), getComboBoxValue(phone1Type.getTooltip()));
        assertEquals(EMPTY_STRING, getTextFieldValue(phone2.getTooltip()));
        assertEquals(Work.name(), getComboBoxValue(phone2Type.getTooltip()));
        assertEquals(EMPTY_STRING, getTextFieldValue(phone3.getTooltip()));
        assertEquals(Mobile.name(), getComboBoxValue(phone3Type.getTooltip()));
        assertEquals(EMPTY_STRING, getTextFieldValue(email.getTooltip()));
        assertEquals(EMPTY_STRING, getTextFieldValue(homepage.getTooltip()));
        assertEquals(EMPTY_STRING, getTextFieldValue(IMAddress.getTooltip()));
    }
}
