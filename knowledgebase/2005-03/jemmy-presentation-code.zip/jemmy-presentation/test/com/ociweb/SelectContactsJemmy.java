package com.ociweb;

import static com.ociweb.Contact.Properties.*;

public class SelectContactsJemmy extends AbstractJemmyTestCase {
    private static final String FOO = "_foo";
    private static final String ADD_NEW = "Add New";
    private static final String BAR = "_bar";

    protected void executeTest() {

        populateInputs(FOO);

        pushButton(ADD_NEW);

        populateInputs(BAR);

        clickTableRow(0);

        compareInputValues(FOO);

        clickTableRow(1);

        compareInputValues(BAR);
    }

    private void populateInputs(String suffix) {
        setTextField(fullName.getTooltip(), fullName + suffix);
        setTextField(phone1.getTooltip(), phone1 + suffix);
        setTextField(phone2.getTooltip(), phone2 + suffix);
        setTextField(phone3.getTooltip(), phone3 + suffix);
        setTextField(email.getTooltip(), email + suffix);
        setTextField(homepage.getTooltip(), homepage + suffix);
        setTextField(IMAddress.getTooltip(), IMAddress + suffix);
    }

    private void compareInputValues(String suffix) {
        assertEquals(fullName + suffix, getTextFieldValue(fullName.getTooltip()));
        assertEquals(phone1 + suffix, getTextFieldValue(phone1.getTooltip()));
        assertEquals(phone2 + suffix, getTextFieldValue(phone2.getTooltip()));
        assertEquals(phone3 + suffix, getTextFieldValue(phone3.getTooltip()));
        assertEquals(email + suffix, getTextFieldValue(email.getTooltip()));
        assertEquals(homepage + suffix, getTextFieldValue(homepage.getTooltip()));
        assertEquals(IMAddress + suffix, getTextFieldValue(IMAddress.getTooltip()));
    }
}
