package com.ociweb;

import static com.ociweb.Contact.Properties.*;
import org.netbeans.jemmy.operators.JTableOperator;

public class SearchContactsJemmy extends AbstractJemmyTestCase {
    private static final String QOQ = "_qoq";
    private static final String XOX = "_xox";
    private static final String ZOZ = "_zoz";
    private static final String ADD_NEW = "Add New";

    protected void executeTest() {

        populateInputs(QOQ);

        pushButton(ADD_NEW);

        populateInputs(XOX);

        pushButton(ADD_NEW);

        populateInputs(ZOZ);

        setTextField(ContactUpdater.FILTER_INPUT_TOOLTIP, "o");

        compareSortedRow(0, QOQ);
        compareSortedRow(1, XOX);
        compareSortedRow(2, ZOZ);

        setTextField(ContactUpdater.FILTER_INPUT_TOOLTIP, "ox");

        compareSortedRow(0, XOX);

        setTextField(ContactUpdater.FILTER_INPUT_TOOLTIP, "mapunge");

        assertEquals(0, new JTableOperator(getMainFrameOperator()).getRowCount());

        setTextField(ContactUpdater.FILTER_INPUT_TOOLTIP, "");

        compareSortedRow(1, QOQ);
        compareSortedRow(1, XOX);
        compareSortedRow(2, ZOZ);
    }

    private void populateInputs(String suffix) {
        setTextField(fullName.getTooltip(), fullName + suffix);
        setTextField(phone1.getTooltip(), phone1 + suffix);
        setTextField(phone2.getTooltip(), phone2 + suffix);
        setTextField(phone3.getTooltip(), phone3 + suffix);
        setTextField(email.getTooltip(), email + suffix);
        setTextField(homepage.getTooltip(), homepage + suffix);
        setTextField(IMAddress.getTooltip(), IMAddress + suffix);
    }

    private void compareSortedRow(int row, String suffix) {
        assertEquals(fullName + suffix, getTableCellValue(row, 0));
        assertEquals(phone1 + suffix, getTableCellValue(row, 1));
        assertEquals(phone2 + suffix, getTableCellValue(row, 2));
        assertEquals(phone3 + suffix, getTableCellValue(row, 3));
    }}
