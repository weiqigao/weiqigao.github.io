package com.ociweb;

import junit.framework.TestCase;
import org.netbeans.jemmy.*;
import org.netbeans.jemmy.operators.*;

import java.io.PrintWriter;
import java.io.Writer;
import java.awt.*;

public abstract class AbstractJemmyTestCase extends TestCase {
    private JFrameOperator mainFrame;

    protected AbstractJemmyTestCase() {
        super("testJemmyScenario");
    }

    protected void setUp() throws Exception {
//        JemmyProperties.setCurrentOutput(new TestOut(System.in,
//                                                     new PrintWriter(newNullWriter()),
//                                                     new PrintWriter(System.err)));
        new ClassReference(getMainClassName()).startApplication(getStartupParams());
        queueWait();
        mainFrame = new JFrameOperator();
    }

    private Writer newNullWriter() {
        return new Writer() {
            public void close() {}
            public void flush() {}
            public void write(char cbuf[], int off, int len) {}
            public void write(int c) {}
            public void write(char cbuf[]) {}
            public void write(String str) {}
            public void write(String str, int off, int len) {}
        };
    }

    protected String[] getStartupParams() {
        return new String[0];
    }

    protected JFrameOperator getMainFrameOperator() {
        return mainFrame;
    }

    public void testJemmyScenario() {
        Scenario scenario = new Scenario() {
            public int runIt(Object o) {
                executeTest();
                return 0;
            }
        };

        assertEquals(0, new Test(scenario).startTest(null));
    }

    protected abstract void executeTest();

    protected String getMainClassName() {
        return MainForm.class.getName();
    }

    protected static void queueWait() {
        queueWait(50); //wait until the AWT Event Queue has been empty for 50 milliseconds
    }

    protected static void queueWait(long millis) {
        new QueueTool().waitEmpty(millis);
    }

    protected void setTextField(String tooltip, String value) {
        new JTextFieldOperator(getMainFrameOperator(),
                               new JComponentOperator.JComponentByTipFinder(tooltip)).enterText(value);
        queueWait();
    }

    protected String getTextFieldValue(String tooltip) {
        return new JTextFieldOperator(getMainFrameOperator(),
                                      new JComponentOperator.JComponentByTipFinder(tooltip)).getText();
    }

    protected void setComboBox(String tooltip, String value) {
        new JComboBoxOperator(getMainFrameOperator(),
                              new JComponentOperator.JComponentByTipFinder(tooltip)).selectItem(value);
        queueWait();
    }

    protected String getComboBoxValue(String tooltip) {
        return new JComboBoxOperator(getMainFrameOperator(),
                              new JComponentOperator.JComponentByTipFinder(tooltip)).getSelectedItem().toString();
    }

    protected void clickTableRow(int row) {
        new JTableOperator(getMainFrameOperator()).setRowSelectionInterval(row, row);
        queueWait();
    }

    protected void clickColumnHeader(int column, int clickCount) {
        JTableHeaderOperator operator = new JTableHeaderOperator(getMainFrameOperator());
        Point columnPoint = operator.getPointToClick(column);
        operator.clickMouse((int)columnPoint.getX(), (int)columnPoint.getY(), clickCount);
        queueWait();
    }

    protected Object getTableCellValue(int row, int column) {
        return new JTableOperator(getMainFrameOperator()).getValueAt(row, column);    
    }

    protected void pushButton(String buttonText) {
        new JButtonOperator(getMainFrameOperator(), buttonText).pushNoBlock();
        queueWait();
    }
}
