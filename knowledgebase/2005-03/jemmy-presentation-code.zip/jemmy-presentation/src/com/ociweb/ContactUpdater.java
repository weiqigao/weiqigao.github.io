package com.ociweb;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.GlazedLists;
import ca.odell.glazedlists.SortedList;
import ca.odell.glazedlists.TextFilterator;
import ca.odell.glazedlists.gui.TableFormat;
import ca.odell.glazedlists.swing.TableComparatorChooser;
import ca.odell.glazedlists.swing.TextFilterList;

import javax.swing.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;
import java.lang.reflect.InvocationTargetException;

public class ContactUpdater implements PropertyChangeListener {
    private static final Contact.Properties[] fields = new Contact.Properties[] {
        Contact.Properties.fullName,
        Contact.Properties.phone1,
        Contact.Properties.phone2,
        Contact.Properties.phone3
    };

    public static final String FILTER_INPUT_TOOLTIP = "Filter the displayed contact records";

    private ContactTableModel tableModel;
    private SortedList sortedList = new SortedList(new BasicEventList());
    private final TextFilterList textFilteredIssues = new TextFilterList(sortedList, new TextFilterator() {
        public void getFilterStrings(List baseList, Object element) {
            final Object[] emptyArgs = new Object[0];

            for (int i = 0; i < fields.length; i++) {
                Contact.Properties field = fields[i];
                try {
                    baseList.add(field.getAccessor().invoke(element, emptyArgs));
                } catch (IllegalAccessException e) {
                    throw new UnsupportedOperationException();
                } catch (InvocationTargetException e) {
                    throw new UnsupportedOperationException();
                }
            }
        }
    });

    public void addContact(Contact contact) {
        contact.getPropertyChangeSupport().addPropertyChangeListener(this);
        textFilteredIssues.add(contact);
    }

    public void removeContact(int contactIndex) {
        textFilteredIssues.remove(contactIndex);
    }

    public void propertyChange(PropertyChangeEvent evt) {
        tableModel.fireTableDataChanged();
    }

    public Contact getContact(int contactIndex) {
        if (textFilteredIssues.size() == 0) {
            return new Contact(); //empty contact - not attached to anything
        }

        contactIndex = contactIndex == textFilteredIssues.size() ? contactIndex - 1 : contactIndex;
        contactIndex = contactIndex == -1 ? 0 : contactIndex;
        return (Contact)textFilteredIssues.get(contactIndex);
    }

    public int getCount() {
        return textFilteredIssues.size();
    }

    public JTable newContactTable() {
        TableFormat format = newTableFormat(fields);

        tableModel = new ContactTableModel(textFilteredIssues, format);
        JTable table = new JTable(tableModel);
        new TableComparatorChooser(table, sortedList, false);
        return table;
    }

    public JTextField getFilterInput() {
        final JTextField filterEdit = textFilteredIssues.getFilterEdit();
        filterEdit.setToolTipText(FILTER_INPUT_TOOLTIP);
        return filterEdit;
    }

    private TableFormat newTableFormat(Contact.Properties[] props) {
        String[] propNames = new String[props.length];
        String[] columnNames = new String[props.length];
        for (int i = 0; i < props.length; i++) {
            propNames[i] = props[i].name();
            columnNames[i] = props[i].getLabel();
        }

        boolean[] notEditable = new boolean[props.length];

        return GlazedLists.tableFormat(Contact.class, propNames, columnNames, notEditable);
    }
}
