package com.ociweb;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class MainForm extends JFrame {
    private Contact currentContact = new Contact();

    private JTextField fullName = newJTextField(Contact.Properties.fullName);
    private JTextField email = newJTextField(Contact.Properties.email);
    private JComboBox phone1Type = newPhoneCombo(Contact.Properties.phone1Type, currentContact.getPhone1Type());
    private JComboBox phone2Type = newPhoneCombo(Contact.Properties.phone2Type, currentContact.getPhone2Type());
    private JComboBox phone3Type = newPhoneCombo(Contact.Properties.phone3Type, currentContact.getPhone3Type());
    private JTextField phone1 = newJTextField(Contact.Properties.phone1);
    private JTextField phone2 = newJTextField(Contact.Properties.phone2);
    private JTextField phone3 = newJTextField(Contact.Properties.phone3);
    private JTextField homepage = newJTextField(Contact.Properties.homepage);
    private JTextField imAddress = newJTextField(Contact.Properties.IMAddress);

    private JTable table;
    private ContactUpdater updater;

    private void init() {
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setTopComponent(createDetailComponent());
        splitPane.setBottomComponent(createTableComponent());
        add(splitPane);
    }

    private JComponent createDetailComponent() {

        FormLayout layout = new FormLayout("right:pref, 2dlu, pref, 8dlu, right:pref, 2dlu, default:grow",
                                           "pref, 3dlu, pref, 3dlu, pref, 10dlu, pref, 10dlu, pref, 3dlu, pref");
        PanelBuilder builder = new PanelBuilder(layout);
        builder.setDefaultDialogBorder();

        CellConstraints cc1 = new CellConstraints();
        CellConstraints cc2 = new CellConstraints();

        builder.addLabel(Contact.Properties.fullName.getLabel(), cc1.xy(1, 1), fullName, cc2.xy(3, 1)).setDisplayedMnemonic('N');
        builder.add(phone1Type, cc1.xy(5, 1));
        builder.add(phone1, cc1.xy(7, 1));

        phone2Type.setSelectedItem(Contact.PhoneType.Work);
        builder.add(phone2Type, cc1.xy(5, 3));
        builder.add(phone2, cc1.xy(7, 3));

        phone3Type.setSelectedItem(Contact.PhoneType.Mobile);
        builder.add(phone3Type, cc1.xy(5, 5));
        builder.add(phone3, cc1.xy(7, 5));

        builder.addLabel(Contact.Properties.email.getLabel(), cc1.xy(5, 7), email, cc2.xy(7, 7)).setDisplayedMnemonic('m');

        builder.addLabel(Contact.Properties.homepage.getLabel(), cc1.xy(5, 9), homepage, cc2.xy(7, 9)).setDisplayedMnemonic('H');

        builder.addLabel(Contact.Properties.IMAddress.getLabel(), cc1.xy(5, 11), imAddress, cc2.xy(7, 11)).setDisplayedMnemonic('I');

        JButton addContact = new JButton("Add New");
        addContact.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updater.addContact(new Contact());
                final int index0 = table.getRowCount() - 1;
                table.setRowSelectionInterval(index0, index0);
            }
        });
        addContact.setMnemonic('A');
        JButton removeContact = new JButton("Remove");
        removeContact.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (updater.getCount() > 1) {
                    int selectedRow = table.getSelectedRow();
                    selectedRow = selectedRow == -1 ? table.getRowCount() - 1 : selectedRow;
                    updater.removeContact(selectedRow);
                    int newSelectionRow = selectedRow == table.getRowCount() ? selectedRow - 1 : selectedRow;
                    table.setRowSelectionInterval(newSelectionRow, newSelectionRow);
                }
            }
        });
        removeContact.setMnemonic('R');
        builder.add(ButtonBarFactory.buildAddRemoveBar(addContact, removeContact), cc1.xyw(1, 11, 3));
        return builder.getPanel();
    }

    private JComponent createTableComponent() {
        updater = new ContactUpdater();
        updater.addContact(currentContact);
        table = updater.newContactTable();

        table.setRowSelectionAllowed(true);
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedIndex = ((DefaultListSelectionModel)e.getSource()).getLeadSelectionIndex();
                    currentContact = updater.getContact(selectedIndex);
                    refreshFromContact();
                }

            }
        });

        JScrollPane scrollPane = new JScrollPane(table);

        FormLayout layout = new FormLayout("right:pref, 2dlu, pref:grow",
                                           "top:default:grow, 3dlu, bottom:pref");
        PanelBuilder builder = new PanelBuilder(layout);
        builder.setDefaultDialogBorder();

        CellConstraints cc1 = new CellConstraints();
        CellConstraints cc2 = new CellConstraints();

        builder.add(scrollPane, cc1.xyw(1, 1, 3));
        builder.addLabel("Search", cc1.xy(1, 3), updater.getFilterInput(), cc2.xy(3, 3)).setDisplayedMnemonic('S');

        return builder.getPanel();
    }

    private JComboBox newPhoneCombo(final Contact.Properties property, Contact.PhoneType selectedType) {
        final JComboBox combo = new JComboBox(Contact.PhoneType.values());
        combo.setSelectedItem(selectedType);
        combo.setToolTipText(property.getTooltip());
        combo.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                invokePropertyMutator(property.getMutator(), combo.getSelectedItem());
            }
        });
        return combo;
    }

    private JTextField newJTextField(final Contact.Properties property) {
        final JTextField textfield = new JTextField(property.getColumnSize());
        textfield.setToolTipText(property.getTooltip());
        textfield.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent evt) {
                invokePropertyMutator(property.getMutator(), textfield.getText());
            }
        });
        textfield.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                invokePropertyMutator(property.getMutator(), textfield.getText());
            }
        });
        return textfield;
    }

    private void invokePropertyMutator(Method mutator, Object value) {
        try {
            mutator.invoke(currentContact, value);
        } catch (IllegalAccessException e) {
            throw new UnsupportedOperationException(e);
        } catch (InvocationTargetException e) {
            throw new UnsupportedOperationException(e);
        }
    }

    private void refreshFromContact() {
        fullName.setText(currentContact.getFullName());
        email.setText(currentContact.getEmail());
        phone1.setText(currentContact.getPhone1());
        phone1Type.setSelectedItem(currentContact.getPhone1Type());
        phone2.setText(currentContact.getPhone2());
        phone2Type.setSelectedItem(currentContact.getPhone2Type());
        phone3.setText(currentContact.getPhone3());
        phone3Type.setSelectedItem(currentContact.getPhone3Type());
        homepage.setText(currentContact.getHomepage());
        imAddress.setText(currentContact.getIMAddress());
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                MainForm gui = new MainForm();
                gui.init();
                gui.setTitle("Address Book");
                Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
                gui.pack();
                gui.setLocation((int) ((dim.getWidth() - gui.getWidth()) / 2),
                                (int) ((dim.getHeight() - gui.getHeight()) / 6));
                gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                gui.setVisible(true);
            }
        });
    }
}
