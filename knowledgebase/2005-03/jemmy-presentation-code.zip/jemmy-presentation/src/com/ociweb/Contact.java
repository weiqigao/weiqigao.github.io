package com.ociweb;

import oreilly.hcj.references.PropertyChangeSupport;

import java.util.Map;
import java.util.HashMap;
import java.lang.reflect.Method;
import java.beans.*;

public class Contact implements Comparable {
    private String fullName;
    private String email;
    private String phone1;
    private PhoneType phone1Type = PhoneType.Home;
    private String phone2;
    private PhoneType phone2Type = PhoneType.Work;
    private String phone3;
    private PhoneType phone3Type = PhoneType.Mobile;
    private String homepage;
    private String IMAddress;

    private final PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        final String oldValue = this.fullName;
        this.fullName = fullName;
        propertyChangeSupport.firePropertyChange(Properties.fullName.name(), oldValue, fullName);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        final String oldValue = this.email;
        this.email = email;
        propertyChangeSupport.firePropertyChange(Properties.email.name(), oldValue, email);
    }

    public String getPhone1() {
        return phone1;
    }

    public void setPhone1(String phone1) {
        final String oldValue = this.phone1;
        this.phone1 = phone1;
        propertyChangeSupport.firePropertyChange(Properties.phone1.name(), oldValue, phone1);
    }

    public PhoneType getPhone1Type() {
        return phone1Type;
    }

    public void setPhone1Type(PhoneType phone1Type) {
        final PhoneType oldValue = this.phone1Type;
        this.phone1Type = phone1Type;
        propertyChangeSupport.firePropertyChange(Properties.phone1Type.name(), oldValue, phone1Type);
    }

    public String getPhone2() {
        return phone2;
    }

    public void setPhone2(String phone2) {
        final String oldValue = this.phone2;
        this.phone2 = phone2;
        propertyChangeSupport.firePropertyChange(Properties.phone2.name(), oldValue, phone2);
    }

    public PhoneType getPhone2Type() {
        return phone2Type;
    }

    public void setPhone2Type(PhoneType phone2Type) {
        final PhoneType oldValue = this.phone2Type;
        this.phone2Type = phone2Type;
        propertyChangeSupport.firePropertyChange(Properties.phone2Type.name(), oldValue, phone2Type);
    }

    public String getPhone3() {
        return phone3;
    }

    public void setPhone3(String phone3) {
        final String oldValue = this.phone3;
        this.phone3 = phone3;
        propertyChangeSupport.firePropertyChange(Properties.phone3.name(), oldValue, phone3);
    }

    public PhoneType getPhone3Type() {
        return phone3Type;
    }

    public void setPhone3Type(PhoneType phone3Type) {
        final PhoneType oldValue = this.phone3Type;
        this.phone3Type = phone3Type;
        propertyChangeSupport.firePropertyChange(Properties.phone3Type.name(), oldValue, phone3Type);
    }

    public String getHomepage() {
        return homepage;
    }

    public void setHomepage(String homepage) {
        final String oldValue = this.homepage;
        this.homepage = homepage;
        propertyChangeSupport.firePropertyChange(Properties.homepage.name(), oldValue, homepage);
    }

    public String getIMAddress() {
        return IMAddress;
    }

    public void setIMAddress(String IMAddress) {
        final String oldValue = this.IMAddress;
        this.IMAddress = IMAddress;
        propertyChangeSupport.firePropertyChange(Properties.IMAddress.name(), oldValue, IMAddress);
    }

    public PropertyChangeSupport getPropertyChangeSupport() {
        return propertyChangeSupport;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Contact)) return false;

        final Contact contact = (Contact) o;

        if (IMAddress != null ? !IMAddress.equals(contact.IMAddress) : contact.IMAddress != null) return false;
        if (email != null ? !email.equals(contact.email) : contact.email != null) return false;
        if (fullName != null ? !fullName.equals(contact.fullName) : contact.fullName != null) return false;
        if (homepage != null ? !homepage.equals(contact.homepage) : contact.homepage != null) return false;
        if (phone1 != null ? !phone1.equals(contact.phone1) : contact.phone1 != null) return false;
        if (phone1Type != null ? !phone1Type.equals(contact.phone1Type) : contact.phone1Type != null) return false;
        if (phone2 != null ? !phone2.equals(contact.phone2) : contact.phone2 != null) return false;
        if (phone2Type != null ? !phone2Type.equals(contact.phone2Type) : contact.phone2Type != null) return false;
        if (phone3 != null ? !phone3.equals(contact.phone3) : contact.phone3 != null) return false;
        if (phone3Type != null ? !phone3Type.equals(contact.phone3Type) : contact.phone3Type != null) return false;
        if (propertyChangeSupport != null ? !propertyChangeSupport.equals(contact.propertyChangeSupport) : contact.propertyChangeSupport != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (fullName != null ? fullName.hashCode() : 0);
        result = 29 * result + (email != null ? email.hashCode() : 0);
        result = 29 * result + (phone1 != null ? phone1.hashCode() : 0);
        result = 29 * result + (phone1Type != null ? phone1Type.hashCode() : 0);
        result = 29 * result + (phone2 != null ? phone2.hashCode() : 0);
        result = 29 * result + (phone2Type != null ? phone2Type.hashCode() : 0);
        result = 29 * result + (phone3 != null ? phone3.hashCode() : 0);
        result = 29 * result + (phone3Type != null ? phone3Type.hashCode() : 0);
        result = 29 * result + (homepage != null ? homepage.hashCode() : 0);
        result = 29 * result + (IMAddress != null ? IMAddress.hashCode() : 0);
        result = 29 * result + (propertyChangeSupport != null ? propertyChangeSupport.hashCode() : 0);
        return result;
    }

    public int compareTo(Object o) {
        Contact contact = (Contact)o;
        int comparison = 0;

        // Define null less than everything, except null.
        final String myFullName = getFullName();
        final String yourFullName = contact.getFullName();
        if (myFullName == null && yourFullName == null) {
            comparison = 0;
        } else if (myFullName == null) {
            comparison = 1;
        } else if (yourFullName == null) {
            comparison = -1;
        } else {
            comparison = myFullName.compareToIgnoreCase(yourFullName);
        }
        return comparison;
    }

    public static enum PhoneType {
        Home, Work, Mobile
    }

    public static enum Properties {
        fullName(20, "Contact name", "Name"),
        email(20, "Contact email address", "Email"),
        phone1(14, "Main phone number", "Phone #"),
        phone1Type(10, "Main phone type"),
        phone2(14, "First alternate phone number", "Phone #(2)"),
        phone2Type(10, "Second phone type"),
        phone3(14, "Second alternate phone number", "Phone #(3)"),
        phone3Type(10, "Third phone type"),
        homepage(20, "Personal website homepage", "Homepage"),
        IMAddress(20, "Instant Messenger address name", "IM Address");

        private final int columnSize;
        private final String tooltip;
        private final String label;

        private static final Map<String, PropertyDescriptor> properties = new HashMap<String, PropertyDescriptor>();
        static {
            try {
                BeanInfo beanInfo = Introspector.getBeanInfo(Contact.class);
                PropertyDescriptor[] descriptors = beanInfo.getPropertyDescriptors();
                for (int i = 0; i < descriptors.length; i++) {
                    final PropertyDescriptor descriptor = descriptors[i];
                    properties.put(descriptor.getName(), descriptor);
                }

            } catch (IntrospectionException e) {
                throw new UnsupportedOperationException();
            }
        }

        Properties(int columnSize, String tooltip, String label) {
            this.columnSize = columnSize;
            this.tooltip = tooltip;
            this.label = label;
        }

        Properties(int columnSize, String tooltip) {
            this(columnSize, tooltip, "");
        }

        public int getColumnSize() {
            return columnSize;
        }

        public String getTooltip() {
            return tooltip;
        }

        public String getLabel() {
            return label;
        }

        public Method getAccessor() {
            return properties.get(name()).getReadMethod();
        }
        
        public Method getMutator() {
            return properties.get(name()).getWriteMethod();
        }
    }
}
