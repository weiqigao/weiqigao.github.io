package com.ociweb;

import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.gui.TableFormat;
import ca.odell.glazedlists.swing.EventTableModel;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class ContactTableModel extends EventTableModel implements PropertyChangeListener {

    public ContactTableModel(EventList source, TableFormat format) {
        super(source, format);
    }

    public void propertyChange(PropertyChangeEvent evt) {
        fireTableDataChanged();
    }
}
