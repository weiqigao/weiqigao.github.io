package listing6client;

import listing0service.Service;
import listing4guice.Client;
import listing5serviceDependency.Emailer;
import listing6chooseImpl.EmailingServiceImpl;
import listing6chooseImpl.Mass;
import listing6chooseImpl.MassMailer;

import com.google.inject.AbstractModule;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;

public class Application {

  private static final Module MY_MODULE = new AbstractModule() { 
    protected void configure() { 
      bind(Service.class) 
        .to(EmailingServiceImpl.class);
      bind(Emailer.class) 
      .annotatedWith(Mass.class)
      .to(MassMailer.class);
    } 
  };
  
  /**
   * @param args
   */
  public static void main(String[] args) {
    Injector injector = Guice.createInjector(MY_MODULE); 
    Client client = injector.getInstance(Client.class); 
    System.out.println("<!><!><!><!> client sez: " + client.someBusinessMethod(null));
  }

}
