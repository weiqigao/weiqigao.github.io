package listing5client;

import listing0service.Service;
import listing4guice.Client;
import listing5serviceDependency.EmailingServiceImpl;

import com.google.inject.AbstractModule;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;
import com.google.inject.Scopes;

public class Application {

  // Note use of AbstractModule
  private static final Module MY_MODULE = new AbstractModule() { 
    protected void configure() { 
      bind(Service.class) 
        .to(EmailingServiceImpl.class)
        .in(Scopes.SINGLETON); 
    } 
  };
  
  /**
   * @param args
   */
  public static void main(String[] args) {
    Injector injector = Guice.createInjector(MY_MODULE); 
    Client client = injector.getInstance(Client.class); 
    System.out.println("<!><!><!><!> client sez: " + client.someBusinessMethod(null));
  }

}
