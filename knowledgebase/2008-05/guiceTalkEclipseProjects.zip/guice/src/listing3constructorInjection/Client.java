package listing3constructorInjection;

import listing0service.Service;
import listing0service.ServiceImpl;

class Client {
  private Service service;

  public Client(Service someDAO) {
    this.service = someDAO;
  }

  public Client() {
    this(new ServiceImpl());
  }

  public String someBusinessMethod(String arg) {

    //Data access here...
    String data = getService().getData(arg);

    //Business Logic here...
    if (data.equals("bar")){
      return "foo";
    }
    return null;
  }

  private Service getService() {
    return service;
  }
}