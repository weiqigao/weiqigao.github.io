package listing6chooseImpl;

import listing0service.Service;
import listing5serviceDependency.Emailer;

import com.google.inject.Inject;

public class EmailingServiceImpl implements Service {

  @Inject @Mass
  private Emailer emailer;

  /** alternately remove no-arg constructor, annotate remaining constructor w/ Inject */
  public EmailingServiceImpl(){
    
  }
  
  public EmailingServiceImpl(Emailer emailer) {
    this.emailer = emailer;
  }

  public String getData(String id) {
    // SIMULATE EXPENSIVE OPERATION
    try {
      Thread.sleep(50); //TODO 5000
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    
    emailer.email("bar");

    return "bar";  
  }

}
