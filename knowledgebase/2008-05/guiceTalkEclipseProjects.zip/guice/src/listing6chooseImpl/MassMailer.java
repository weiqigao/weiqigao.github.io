package listing6chooseImpl;

import listing5serviceDependency.Emailer;

public class MassMailer extends Emailer {

  @Override
  public void email(String message) {
    System.out.println("<!><!><!><!>mass mailing... " + message);
  }

}
