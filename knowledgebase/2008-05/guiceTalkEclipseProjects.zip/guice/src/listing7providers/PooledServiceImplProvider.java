package listing7providers;

import java.util.ArrayList;
import java.util.List;

import listing0service.Service;
import listing5serviceDependency.Emailer;
import listing6chooseImpl.EmailingServiceImpl;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.google.inject.name.Named;

public class PooledServiceImplProvider implements Provider<Service> {

  private final Emailer emailer;
  private final int poolSize;
  private final List<Service> pool;
  private int index;

  @Inject
  public PooledServiceImplProvider(Emailer emailer, @Named("poolSize") int poolSize) {
    this.emailer = emailer;
    this.poolSize = poolSize;
    pool = new ArrayList<Service>(poolSize);
    for (int i=0; i<poolSize; i++){
      pool.add(new EmailingServiceImpl(emailer));
    }
    index=0;
  }

  public Service get() {
    // TODO Auto-generated method stub
    Service service = pool.get(index);
    System.out.println("<!><!><!><!> Pooled Service Provider returning " + index + "th pooled service impl.");
    index = (index+1)%poolSize;
    return service;
  }

}
