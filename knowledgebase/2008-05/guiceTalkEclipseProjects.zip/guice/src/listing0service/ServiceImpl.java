package listing0service;

public class ServiceImpl implements Service {

  public String getData(String id) {

    // SIMULATE EXPENSIVE DB OPERATION
    try {
      Thread.sleep(50); //TODO 5000
    } catch (InterruptedException e) {
      e.printStackTrace();
    }

    return "bar";
  }

}