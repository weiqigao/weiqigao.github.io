package listing0service;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author scbale
 * @version $Revision$
 */
public interface Service {
  public String getData(String id);
}