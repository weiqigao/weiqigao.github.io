package listing7client;

import listing0service.Service;
import listing7providers.PooledServiceImplProvider;

import com.google.inject.AbstractModule;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;
import com.google.inject.Scopes;
import com.google.inject.name.Names;

public class Application {

  private static final Module MY_MODULE = new AbstractModule() { 
    protected void configure() { 
      bind(Service.class) 
        .toProvider(PooledServiceImplProvider.class);
      
      bindConstant().annotatedWith(Names.named("poolSize")).to(42);

      bind(PooledServiceImplProvider.class).in(Scopes.SINGLETON);
    } 
  };
  
  /**
   * @param args
   */
  public static void main(String[] args) {
    Injector injector = Guice.createInjector(MY_MODULE); 
    Client client = injector.getInstance(Client.class); 
    System.out.println("<!><!><!><!> client sez: " + client.someBusinessMethod(null));
    Client client1 = injector.getInstance(Client.class); 
    System.out.println("<!><!><!><!> client1 sez: " + client1.someBusinessMethod(null));
  }

}
