package listing7client;

import listing0service.Service;

import com.google.inject.Inject;

public class Client {
  private Service service;

  @Inject
  public Client(Service service) {
    this.service = service;
  }

  public String someBusinessMethod(String arg) {

    //Data access here...
    String data = getService().getData(arg);

    //Business Logic here...
    if (data.equals("bar")){
      return "foo";
    }
    return null;
  }

  private Service getService() {
    return service;
  }
}
