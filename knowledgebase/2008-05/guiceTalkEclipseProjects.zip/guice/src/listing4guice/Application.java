package listing4guice;

import listing0service.Service;
import listing0service.ServiceImpl;

import com.google.inject.Binder;
import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;

public class Application {

  // Note use of AbstractModule
  private static final Module MY_MODULE = new Module() { 
    public void configure(Binder binder) { 
      binder.bind(Service.class) 
        .to(ServiceImpl.class); 
    } 
  };
  
  /**
   * @param args
   */
  public static void main(String[] args) {
    Injector injector = Guice.createInjector(MY_MODULE); 
    Client client = injector.getInstance(Client.class); 
    System.out.println("<!><!><!><!> client sez: " + client.someBusinessMethod(null));
  }

}
