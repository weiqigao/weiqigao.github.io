package listing5serviceDependency;

public class Emailer {
  
  public void email(String message){
    System.out.println("<!><!><!><!>emailing... " + message);
  }

}
