package listing5serviceDependency;

import listing0service.Service;

import com.google.inject.Inject;

public class EmailingServiceImpl implements Service {

  @Inject
  private Emailer emailer; // "implicit" binding, because Emailer is concrete

  /** alternately remove no-arg constructor, annotate remaining constructor w/ Inject */
  public EmailingServiceImpl(){
    
  }
  
  public EmailingServiceImpl(Emailer emailer) {
    this.emailer = emailer;
  }

  public String getData(String id) {
    // SIMULATE EXPENSIVE OPERATION
    try {
      Thread.sleep(50); //TODO 5000
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    
    emailer.email("bar");

    return "bar";  
  }

}
