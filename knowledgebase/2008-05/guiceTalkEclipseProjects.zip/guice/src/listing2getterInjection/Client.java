package listing2getterInjection;

import listing0service.Service;
import listing0service.ServiceImpl;

class Client {

  public String someBusinessMethod(String arg) {

    //Data access here...
    String data = getService().getData(arg);

    //Business Logic here...
    if (data.equals("bar")){
      return "foo";
    }
    return null;
  }

  protected Service getService() {
    // added more logic...
    return new ServiceImpl();
  }
}