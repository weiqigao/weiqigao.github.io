package listing2getterInjection;

import static org.junit.Assert.assertEquals;
import listing0service.Service;
import listing2getterInjection.Client;

import org.junit.Test;



public class TestClient {

  @Test
  public void testServiceCall() throws Exception {
    assertEquals("foo", new MockClient().someBusinessMethod("bar"));
  }

  private static final class MockClient extends Client {
    protected Service getService() {
      return new MockService();
    }
  }

  private static final class MockService implements Service {
    public String getData(String id) {
      return "bar";
    }
  }
}