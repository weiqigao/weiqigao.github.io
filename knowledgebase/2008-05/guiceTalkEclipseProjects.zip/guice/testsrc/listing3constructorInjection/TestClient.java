package listing3constructorInjection;

import static org.junit.Assert.assertEquals;
import listing0service.Service;
import listing3constructorInjection.Client;

import org.junit.Test;



public class TestClient {

  @Test
  public void testServiceCall() throws Exception {
    assertEquals("foo", new Client(new MockService()).someBusinessMethod("bar"));
  }

  @Test
  public void testServiceCall_Production() throws Exception {
    assertEquals("foo", new Client().someBusinessMethod("bar"));
  }

  private static final class MockService implements Service {
    public String getData(String id) {
      return "bar";
    }
  }
}