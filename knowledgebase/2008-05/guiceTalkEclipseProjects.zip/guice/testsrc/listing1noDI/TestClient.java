package listing1noDI;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestClient {

  @Test
  public void testServiceCall() throws Exception {
    assertEquals("foo", new Client().someBusinessMethod("abc"));
  }

}