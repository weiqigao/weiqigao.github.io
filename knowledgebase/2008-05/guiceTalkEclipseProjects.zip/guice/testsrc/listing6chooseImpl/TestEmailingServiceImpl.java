package listing6chooseImpl;

import static org.junit.Assert.assertEquals;
import listing0service.Service;
import listing5serviceDependency.Emailer;

import org.junit.Before;
import org.junit.Test;


public class TestEmailingServiceImpl {

  private Service service;
  private MockEmailer emailer;
  
  @Before
  public void setUp() throws Exception {
    emailer = new MockEmailer();
    service = new EmailingServiceImpl(emailer);
  }
  
  @Test
  public void testEmailingService(){
    service.getData(null);
    assertEquals("bar", emailer.msg);
  }
  
  private static class MockEmailer extends Emailer{
    private String msg;
    
    public void email(String message){
      this.msg = message;
    }
  }

}
