package listing4guice;

import static org.junit.Assert.assertEquals;
import listing0service.Service;

import org.junit.Test;


public class TestClient {

    @Test
    public void testService() throws Exception {
        Client client = new Client(new MockService());
        assertEquals("foo", client.someBusinessMethod("bar"));
    }

    private static final class MockService implements Service {
        public String getData(String id) {
            return "bar";
        }
    }
}
