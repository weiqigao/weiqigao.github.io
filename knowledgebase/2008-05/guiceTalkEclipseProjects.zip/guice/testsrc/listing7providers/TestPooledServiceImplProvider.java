package listing7providers;


import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;
import listing0service.Service;
import listing5serviceDependency.Emailer;

import org.junit.Before;
import org.junit.Test;

import com.google.inject.Provider;

public class TestPooledServiceImplProvider {

  private static final int POOL_SIZE = 3;
  private Provider<Service> serviceProvider;
  
  @Before
  public void setUp() throws Exception {
    serviceProvider = new PooledServiceImplProvider(new Emailer(), POOL_SIZE);
  }
  
  @Test
  public void testDistinctInstancesFromPool() throws Exception {
    Service s1 = serviceProvider.get();
    Service s2 = serviceProvider.get();
    Service s3 = serviceProvider.get();
    assertNotSame(s1, s2);
    assertNotSame(s2, s3);
    assertNotSame(s1, s3);
  }
  
  @Test
  public void testReuseServices() throws Exception {
    Service s1 = serviceProvider.get();
    for (int i=1; i<POOL_SIZE; i++){
      serviceProvider.get();
    }
    assertSame(s1, serviceProvider.get());
  }

}
