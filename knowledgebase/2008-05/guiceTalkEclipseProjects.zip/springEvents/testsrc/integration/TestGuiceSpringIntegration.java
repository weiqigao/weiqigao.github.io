package integration;


import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;

import demo.events.EventProcessor;
import demo.formatted.EventFormatter;
import demo.formatted.MyModuleFactory;

public class TestGuiceSpringIntegration {

  private static ListableBeanFactory beanFactory;
  private EventProcessor theEventProcessor;
  
  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    ClassPathResource resource = new ClassPathResource("demo/events/applicationContext.xml");
    beanFactory = new XmlBeanFactory(resource);
  }

  @Before
  public void setUp() throws Exception {
    theEventProcessor = (EventProcessor) beanFactory.getBean("eventProcessor");
  }
  
  @Test // For this test to pass, uncomment the annotation on the EventFormatter constructor param
  public void testSpringBindAll() throws Exception {
    Module module = MyModuleFactory.moduleUsingbindAll(beanFactory);
    Injector inject = Guice.createInjector(module);
    EventFormatter formatter = inject.getInstance(EventFormatter.class);
    assertNotNull(formatter.getEventProcessor());
    assertSame(theEventProcessor, formatter.getEventProcessor());
  }
  
  @Test // For this test to pass, comment the annotation on the EventFormatter constructor param
  public void testFromSpring() throws Exception {
    Module module = MyModuleFactory.moduleUsingfromSpring(beanFactory);
    Injector inject = Guice.createInjector(module);
    EventFormatter formatter = inject.getInstance(EventFormatter.class);
    assertNotNull(formatter.getEventProcessor());
    assertSame(theEventProcessor, formatter.getEventProcessor());
  }

}
