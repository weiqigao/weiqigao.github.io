package demo.formatted;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;

import demo.events.EventProcessor;
import demo.events.MessageEvent;

public class TestEventFormatter {

  private EventFormatter formatter;
  private EventProcessor eventProcessor;
  
  @Before
  public void setUp() throws Exception {
    eventProcessor = new EventProcessor();
    formatter = new EventFormatter(eventProcessor);
  }
  
  @Test
  public void testSimpleFormat() throws Exception {
    eventProcessor.onApplicationEvent(new MessageEvent(this, "Foo"));
    assertEquals(Arrays.asList("**Foo**"), formatter.getFormatted());
  }

  @Test
  public void testMultiple() throws Exception {
    eventProcessor.onApplicationEvent(new MessageEvent(this, "Bar"));
    eventProcessor.onApplicationEvent(new MessageEvent(this, "Foo"));
    assertEquals(Arrays.asList("**Foo**", "**Bar**"), formatter.getFormatted());
  }

}
