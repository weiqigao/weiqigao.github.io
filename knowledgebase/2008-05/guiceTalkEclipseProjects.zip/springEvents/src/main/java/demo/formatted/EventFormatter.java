package demo.formatted;

import java.util.ArrayList;
import java.util.List;

import com.google.inject.Inject;

import demo.events.EventProcessor;
import demo.events.MessageEvent;

public class EventFormatter {

  private final EventProcessor eventProcessor;

  @Inject
  public EventFormatter(/*@Named("eventProcessor")*/ EventProcessor eventProcessor) {
    this.eventProcessor = eventProcessor;
  }

  public List<String> getFormatted() {
    List events = eventProcessor.getEvents();
    List<String> results = new ArrayList<String>(events.size());
    for (Object object : events) {
      MessageEvent event = (MessageEvent)object;
      results.add("**" + event.getMessage() + "**");
    }
    return results;
  }

  public EventProcessor getEventProcessor() {
    return eventProcessor;
  }

}
