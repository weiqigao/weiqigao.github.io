package demo.formatted;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.ListableBeanFactory;

import com.google.inject.AbstractModule;
import com.google.inject.Module;
import com.google.inject.spring.SpringIntegration;

import demo.events.EventProcessor;

public class MyModuleFactory {

  public static Module moduleUsingbindAll(final ListableBeanFactory beanFactory) {
    return new AbstractModule(){

      @Override
      protected void configure() {
        SpringIntegration.bindAll(binder(), beanFactory);
      }
    };
  }

  public static Module moduleUsingfromSpring(final ListableBeanFactory beanFactory) {
    return new AbstractModule(){
      
      @Override
      protected void configure() {
        bind(BeanFactory.class).toInstance(beanFactory);
        bind(EventProcessor.class).toProvider(SpringIntegration.fromSpring(EventProcessor.class, "eventProcessor"));
      }
    };
  }
  
}
