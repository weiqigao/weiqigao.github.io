package mandel.generator.v2;

import junit.framework.TestCase;

public class MultiThreadGeneratorTest extends TestCase {

	public void testCalculateRange() {
		MultiThreadGenerator gen = new MultiThreadGenerator(3);
		gen.setBounds(0, 0, 1, 1, 100, 100, 10);
		
		checkRange(gen.calculateRange(0), 0, 3333);
		checkRange(gen.calculateRange(1), 3334, 6667);
		checkRange(gen.calculateRange(2), 6668, 9999);
	}
	
	private void checkRange(int[] actual, int expectedMin, int expectedMax) {
		assertNotNull(actual);
		assertEquals(2, actual.length);
		assertEquals(expectedMin, actual[0]);
		assertEquals(expectedMax, actual[1]);
	}
}
