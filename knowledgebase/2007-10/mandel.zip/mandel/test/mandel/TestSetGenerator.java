package mandel;

import mandel.generator.v1.SerialGenerator;
import junit.framework.TestCase;

public class TestSetGenerator extends TestCase {

    public void test1() {
    	int xp = 100;
    	int yp = 100;
        SerialGenerator sg = new SerialGenerator();
        sg.setBounds(-2, -1, 1, 1, xp, yp, 256);
        byte[] points = sg.generate();
        
        int i=0;
        for(int x=0; x<xp; x++) {            
            for(int y=0; y<yp; y++) {
                if(points[i] == 0) {
                    System.out.print(" ");
                } else if(points[i] < 10) {
                    System.out.print("O");
                } else if(points[i] < 20){
                    System.out.print("o");
                } else {
                    System.out.print(".");
                }
                i++;
            }
            System.out.println();
        }
    }
}
