package mandel.bench;

import java.util.ArrayList;
import java.util.List;

import mandel.SetGenerator;
import mandel.generator.v4.LockResults;
import mandel.generator.v4.MultiThreadSafeGenerator;
import mandel.generator.v4.RWLockResults;
import mandel.generator.v5.LatchGenerator;

public class CompareImplementations {

	private static List<Result> results = new ArrayList<Result>();
	
	public static void main(String args[]) {
//		benchmark(new SerialGenerator());
//		
//		for(int i=1; i<=5; i++) {
//			benchmark(new MultiThreadAtomicGenerator(i));
//		}
//		
//		for(int i=1; i<=5; i++) {
//			benchmark(new MultiThreadSafeGenerator(i, new SynchronizedResults()));
//		}

		for(int i=1; i<=5; i++) {
			benchmark(new MultiThreadSafeGenerator(i, new LockResults()));
		}

		for(int i=1; i<=5; i++) {
			benchmark(new MultiThreadSafeGenerator(i, new RWLockResults()));
		}

		for(int i=1; i<=5; i++) {
			benchmark(new LatchGenerator(i, new LockResults()));
		}

		for(int i=1; i<=5; i++) {
			benchmark(new LatchGenerator(i, new RWLockResults()));
		}

		summarize();
	}
	
	private static void benchmark(SetGenerator generator) {
		System.out.println("\nStarting " + generator);
		// Initialize and do one to warm up (just 100x100 pixels though)
		generator.setBounds(-1.5f, 0.5f, -1f, 1f, 100, 100, 100);
		generator.generate();
		
		// Time a real one - 1000x1000
		int size = 2000;
		generator.setBounds(-1.5f, 0.5f, -1f, 1f, size, size, 100);
		long start = System.currentTimeMillis();
		generator.generate();
		long end = System.currentTimeMillis();
		
		Result result = new Result(generator.toString(), end-start, size*size);
		System.out.println(result);
		results.add(result);
	}
	
	private static void summarize() {
		System.out.println();
		for(Result result : results) {
			System.out.println(result);
		}
	}
	
	private static class Result {
		String description;
		long elapsed;
		int pixels;
		long ppms;
		
		Result(String description, long elapsed, int pixels) {
			this.description = description;
			this.elapsed = elapsed;
			this.pixels = pixels;
			this.ppms = pixels/elapsed;
		}
		
		public String toString() {
			return description + ": " + elapsed + " millis, " + ppms + " ppms";
		}
	}

}
