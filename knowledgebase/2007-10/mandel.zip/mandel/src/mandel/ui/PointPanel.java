package mandel.ui;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.IndexColorModel;
import java.awt.image.Raster;
import java.awt.image.SampleModel;
import java.awt.image.WritableRaster;

import javax.swing.JPanel;

import mandel.SetGenerator;


public class PointPanel extends JPanel {

    private SetGenerator generator;
    private IndexColorModel colorModel;
    
    private float minx;
    private float maxx;
    private float miny;
    private float maxy;
    private int escape;
    
    private boolean needsRepaint = true;
    
    public PointPanel() {
    	colorModel = GradientColorModelUtil.createGradientColorModel(256, 8);
    }
    
    public void setMinx(float minx) {
		this.minx = minx;
	}

	public void setMaxx(float maxx) {
		this.maxx = maxx;
	}

	public void setMiny(float miny) {
		this.miny = miny;
	}

	public void setMaxy(float maxy) {
		this.maxy = maxy;
	}

	public void setEscape(int escape) {
		this.escape = escape;
	}
	
	public void setGenerator(SetGenerator generator) {
		this.generator = generator;
	}

	public void paintComponent(Graphics g) {
		if(needsRepaint()) {			
	        int width = getWidth();
	        int height = getHeight();

	        // LOOK Do computation
            generator.setBounds(minx, maxx, miny, maxy, width, height, escape);
	        byte[] data = generator.generate();
	        
	        // Paint pretty picture
	        drawImage(g, data);	        
        }
    } 
	
	private void drawImage(Graphics g, byte[] data) {
        DataBuffer buffer = new DataBufferByte(data, data.length);
        SampleModel sm = colorModel.createCompatibleSampleModel(getWidth(), getHeight());
        WritableRaster raster = Raster.createWritableRaster(sm, buffer, null);
        BufferedImage img = new BufferedImage(colorModel, raster, false, null);
        g.drawImage(img, 0, 0, null);		
	}

	private boolean needsRepaint() {
		return maxx != 0 &&
			(generator == null ||
			 needsRepaint || 
			 getWidth() != generator.getWidth() ||
			 getHeight() != generator.getHeight());
	}
		
} 
