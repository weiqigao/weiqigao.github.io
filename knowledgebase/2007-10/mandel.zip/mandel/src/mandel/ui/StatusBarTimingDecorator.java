package mandel.ui;

import javax.swing.JLabel;
import javax.swing.SwingUtilities;

import mandel.SetGenerator;
import mandel.TimingDecorator;


public class StatusBarTimingDecorator extends TimingDecorator {

	private JLabel label;
	
	public StatusBarTimingDecorator(SetGenerator generator, JLabel statusLabel) {
		super(generator);
		this.label = statusLabel;
	}
	
	@Override
	protected void preMessage() {
	}

	@Override
	protected void writeMessage(String message) {
		// Remove new lines
		final String cleanMessage = message.replaceAll("\n", "");
		
		// Update label
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				label.setText(cleanMessage);
			}
		});
	}
}
