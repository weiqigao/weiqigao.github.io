package mandel.ui;

import java.awt.image.IndexColorModel;

public class GradientColorModelUtil {

    public static IndexColorModel createGradientColorModel(int colors, int bits) {
        byte[] reds = new byte[colors];
        byte[] greens = new byte[colors];
        byte[] blues = new byte[colors];

        int [][] grad = {{ 255 , 0 , 0 },{ 0 , 255 , 0 },{ 0 , 0 , 255 },{ 1 , 1 , 1 }};
	    int tot = grad.length, sec = colors / tot, cur = 0;
	    byte a = 0, b = 0, c = 0;
	    if (colors < tot) {
	    	tot = colors; sec = 1; 
	    }
	    for (int i = 0; i < tot; i++)
	    {
	        for (int j = 0; j < sec; j++)
	        {
	            a = (byte)(grad[i==tot-1?0:i+1][0]*j/sec+grad[i][0]*(sec-j)/sec);
	            b = (byte)(grad[i==tot-1?0:i+1][1]*j/sec+grad[i][1]*(sec-j)/sec);
	            c = (byte)(grad[i==tot-1?0:i+1][2]*j/sec+grad[i][2]*(sec-j)/sec);
	            if (a < 0) a = 0; else if (a > 255) a = (byte)255;
	            if (b < 0) b = 0; else if (b > 255) b = (byte)255;
	            if (c < 0) c = 0; else if (c > 255) c = (byte)255;
	            
	            int index = cur;
	            reds[index] = a;
	            greens[index] = b;
	            blues[index] = c;
	            
	            // System.out.println(cur + ": " + reds[cur] + ", " + greens[cur] + ", " + blues[cur]);
	            cur++;
	        }
	    }
        return new IndexColorModel(bits, colors, reds, greens, blues);
    }
}
