package mandel.generator.v1;

import mandel.AbstractGenerator;

public class SerialGenerator extends AbstractGenerator {

    public byte[] generate() {
        // Loop through every pixel
        int pixelIndex = 0;
        byte[] data = initializeData();    
        for(int yPixel=0; yPixel<yPixels; yPixel++) {
        	for(int xPixel = 0; xPixel<xPixels; xPixel++) {        		
        		data[pixelIndex++] = calculatePixel(xPixel, yPixel);
            }
        }
        return data;
    }
    
    public String toString() {
    	return "Serial";
    }
    
}
