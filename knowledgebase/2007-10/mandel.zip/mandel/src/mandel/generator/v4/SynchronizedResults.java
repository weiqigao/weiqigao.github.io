package mandel.generator.v4;

public class SynchronizedResults implements Results {
	private byte[] data;
	private int pixelsComplete;
	
	public synchronized void initialize(int pixels) {
		data = new byte[pixels];
		pixelsComplete = 0;
	}
	
	public synchronized byte[] getResults() {
		return this.data;
	}
	
	public synchronized void addResult(int index, byte result) {
		data[index] = result;
		pixelsComplete++;
	}
	
	public synchronized boolean isCompleted() {
		return pixelsComplete == data.length;
	}
	
	
}
