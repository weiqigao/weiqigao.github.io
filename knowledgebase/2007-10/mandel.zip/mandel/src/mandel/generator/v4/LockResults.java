package mandel.generator.v4;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class LockResults implements Results {

	private Lock lock;
	private byte[] data;
	private int pixelsComplete;
	
	public void initialize(int pixels) {
		data = new byte[pixels];
		lock = new ReentrantLock();
		pixelsComplete = 0;
	}
	
	public void addResult(int index, byte result) {
		lock.lock();
		try {
			data[index] = result;
			pixelsComplete++;
		} finally {
			lock.unlock();
		}
	}

	public boolean isCompleted() {
		lock.lock();
		try {
			return pixelsComplete == data.length;
		} finally {
			lock.unlock();
		}
	}

	public byte[] getResults() {
		lock.lock();
		try {
			return this.data;
		} finally {
			lock.unlock();
		}
	}
	
}
