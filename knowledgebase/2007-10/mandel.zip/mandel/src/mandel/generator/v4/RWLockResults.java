package mandel.generator.v4;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class RWLockResults implements Results {

	private ReadWriteLock lock;
	private byte[] data;
	private int pixelsComplete;
	
	public void initialize(int pixels) {
		data = new byte[pixels];
		lock = new ReentrantReadWriteLock(false);		// LOOK
		pixelsComplete = 0;
	}
	
	public void addResult(int index, byte result) {
		lock.writeLock().lock();
		try {
			data[index] = result;
			pixelsComplete++;
		} finally {
			lock.writeLock().unlock();
		}
	}

	public boolean isCompleted() {
		lock.readLock().lock();
		try {
			return pixelsComplete == data.length;
		} finally {
			lock.readLock().unlock();
		}
	}
	
	public byte[] getResults() {
		lock.readLock().lock();
		try {
			return this.data;
		} finally {
			lock.readLock().unlock();
		}
	}
}
