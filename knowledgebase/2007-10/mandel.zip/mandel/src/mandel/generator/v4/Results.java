package mandel.generator.v4;

public interface Results {

	void initialize(int totalPixels);
	
	void addResult(int index, byte result);
	
	boolean isCompleted();
	
	byte[] getResults();
}
