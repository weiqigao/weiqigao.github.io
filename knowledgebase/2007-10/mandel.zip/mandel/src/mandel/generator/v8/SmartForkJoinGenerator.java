package mandel.generator.v8;

import jsr166y.forkjoin.ForkJoinExecutor;
import jsr166y.forkjoin.ForkJoinPool;
import jsr166y.forkjoin.RecursiveTask;
import mandel.AbstractGenerator;

public class SmartForkJoinGenerator extends AbstractGenerator {

	// Configuration
	private final int concurrency;
	private final int minPixelsPerTask;
	private final ForkJoinExecutor fjexec;

	public SmartForkJoinGenerator(int concurrency, int minPixelsPerTask) {
		this.concurrency = concurrency;
		this.minPixelsPerTask = minPixelsPerTask;
		this.fjexec = new ForkJoinPool(concurrency);
	}
	
	public String toString() {
		return "Fork/join (" + concurrency + ")";
	}
	
	public byte[] generate() {
		Result result = fjexec.invoke(new PixelTask(0, totalPixels, getWidth()));
		return result.data;
	}
	
	private class PixelTask extends RecursiveTask<Result> {
		private int startIndex;
		private int length;
		private int width;
		
		PixelTask(int startIndex, int length, int width) {
			this.startIndex = startIndex;
			this.length = length;
			this.width = width;
		}
		
		public Result compute() {
			if(length <= minPixelsPerTask) {
				byte[] data = new byte[length];
				int lastIndex = startIndex+length;
				for(int index=startIndex; index<lastIndex; index++) {
					int x = index % width;
					int y = index / width;
					data[index-startIndex] = calculatePixel(x, y);
				}
				return new Result(startIndex, data);
				
			} else {
				// Divide and conquer
				int begLength = length / 2;
				int mid = startIndex + begLength;
				PixelTask sub1 = new PixelTask(startIndex, begLength, width);
				sub1.fork();
				
				PixelTask sub2 = new PixelTask(mid, length-begLength, width);
				return new Result(sub1.join(), sub2.invoke());
			}
		}
	}
	
	private static class Result {
		int startIndex;
		byte[] data;
		
		public Result(Result sub1, Result sub2) {
			data = new byte[sub1.data.length + sub2.data.length];
			startIndex = sub1.startIndex;
			System.arraycopy(sub1.data, 0, data, 0, sub1.data.length);
			System.arraycopy(sub2.data, 0, data, sub1.data.length, sub2.data.length);
		}
		
		private Result(int start, byte[] data) {
			this.startIndex = start;
			this.data = data;
		}
	}
		

}
