package mandel.generator.v8;

import jsr166y.forkjoin.ForkJoinExecutor;
import jsr166y.forkjoin.ForkJoinPool;
import jsr166y.forkjoin.RecursiveTask;
import mandel.AbstractGenerator;

public class ForkJoinGenerator extends AbstractGenerator {

	// Configuration
	private final int concurrency;

	public ForkJoinGenerator(int concurrency) {
		this.concurrency = concurrency;
	}
	
	public String toString() {
		return "Fork/join (" + concurrency + ")";
	}
	
	public byte[] generate() {
		ForkJoinExecutor fjexec = new ForkJoinPool(concurrency);
		Result result = fjexec.invoke(new PixelTask(0, totalPixels, getWidth()));
		return result.data;
	}
	
	private class PixelTask extends RecursiveTask<Result> {
		private int startIndex;
		private int length;
		private int width;
		
		PixelTask(int startIndex, int length, int width) {
			this.startIndex = startIndex;
			this.length = length;
			this.width = width;
		}
		
		public Result compute() {
			if(length <= 0) {
				return Result.EMPTY;
			} else if(length == 1) {
				int x = startIndex % width;
				int y = startIndex / width;
				byte result = calculatePixel(x, y);	
				return new Result(startIndex, result);
			} else {
				// Divide and conquer
				int begLength = length / 2;
				int mid = startIndex + begLength;
				PixelTask sub1 = new PixelTask(startIndex, begLength, width);
				sub1.fork();
				
				PixelTask sub2 = new PixelTask(mid, length-begLength, width);
				return new Result(sub1.join(), sub2.invoke());
			}
		}
	}
	
	private static class Result {
		int startIndex;
		byte[] data;
		
		public static final Result EMPTY = new Result(0, new byte[0]); 
		
		public Result(int start, byte value) {
			this.startIndex = start;
			data = new byte[1];
			data[0] = value;
		}

		public Result(Result sub1, Result sub2) {
			data = new byte[sub1.data.length + sub2.data.length];
			startIndex = sub1.startIndex;
			System.arraycopy(sub1.data, 0, data, 0, sub1.data.length);
			System.arraycopy(sub2.data, 0, data, sub1.data.length, sub2.data.length);
		}
		
		private Result(int start, byte[] data) {
			this.startIndex = start;
			this.data = data;
		}
	}
		

}
