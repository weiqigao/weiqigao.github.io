package mandel.generator.v3;

import java.util.concurrent.atomic.AtomicInteger;

import mandel.AbstractGenerator;

public class MultiThreadAtomicGenerator extends AbstractGenerator {

	// Configuration
	private final int concurrency;

	// State
	private byte[] data;	
	private AtomicInteger pixelsCompleted;		// LOOK
	
	public MultiThreadAtomicGenerator(int concurrency) {
		this.concurrency = concurrency;
	}
	
	public String toString() {
		return "MultiThreadAtomic (" + concurrency + ")";
	}
	
	public byte[] generate() {
		final CalculatePixel[] work = generateWork();
        pixelsCompleted = new AtomicInteger(0);		// LOOK
    	data = initializeData();
    	
        Thread[] threads = new Thread[concurrency];
        for(int t = 0; t<concurrency; t++) {
        	final int[] workRange = calculateRange(t);
        	
        	final String name = "Thread " + t;
        	threads[t] = new Thread(new Runnable() { 
        		public void run() {
        			System.out.println(name + " starting");
        			for(int w=workRange[0]; w<=workRange[1]; w++) {
        				data[w] = calculatePixel(work[w].getXPixel(), work[w].getYPixel());
        				pixelsCompleted.incrementAndGet();			// LOOK
        			}
        			System.out.println(name + " done");
        		}
        	});
        }

        for(int t=0; t<concurrency; t++) {
        	threads[t].start();
        }
        while(pixelsCompleted.get() < totalPixels) {				// LOOK
        	try { 
        		Thread.sleep(500);
        		System.out.println("Pixels complete: " + pixelsCompleted);
        	} catch(InterruptedException e) {
        	}
        }
		return data;
	}

	private CalculatePixel[] generateWork() {
		final CalculatePixel[] work = new CalculatePixel[totalPixels];
        int pixelIndex = 0;
        for(int yPixel=0; yPixel<yPixels; yPixel++) {
        	for(int xPixel = 0; xPixel<xPixels; xPixel++) {     
        		work[pixelIndex++] = new CalculatePixel(xPixel, yPixel);
            }
        }
		return work;
	}

	private int[] calculateRange(int thread) {
		int workPerThread = (int)Math.ceil(((double)totalPixels) / (double)concurrency);
    	int firstWork = thread * workPerThread;
    	int lastWork = Math.min(totalPixels-1, ((thread+1) * workPerThread)-1);
    	return new int[] { firstWork, lastWork };
	}

	private class CalculatePixel {
		private final int xPixel;
		private final int yPixel;
		
		public CalculatePixel(int xPixel, int yPixel) {
			this.xPixel = xPixel;
			this.yPixel = yPixel;
		}
		
		public int getXPixel() {
			return xPixel;
		}

		public int getYPixel() {
			return yPixel;
		}		
	}
	
}
