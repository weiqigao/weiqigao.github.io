package mandel.generator.v7;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;

import mandel.AbstractGenerator;

public class ExecutorGenerator extends AbstractGenerator {

	// Configuration
	private final int concurrency;
	private final ExecutorService workExecutor;
	private final ExecutorService resultExecutor;

	public ExecutorGenerator(int concurrency) {
		this.concurrency = concurrency;
		this.workExecutor = Executors.newFixedThreadPool(concurrency);
		this.resultExecutor = Executors.newSingleThreadExecutor();
	}
	
	public String toString() {
		return "Executor (" + concurrency + ")";
	}
	
	public byte[] generate() {
		final BlockingQueue<CalculatePixel> resultQueue = new LinkedBlockingQueue<CalculatePixel>();

        // Read and assemble results
        Callable<byte[]> resultCallable = new Callable<byte[]>() {
        	public byte[] call() throws Exception {
        		byte[] data = new byte[totalPixels];
        		try {
	        		for(int i=0; i<totalPixels; i++) {
        				CalculatePixel result = resultQueue.take();
        				data[result.getPixelIndex(getWidth())] = result.getValue();
	        		}
    			} catch(InterruptedException e) {
    			}
        		return data;
        	}
        };
        Future<byte[]> finalResult = resultExecutor.submit(resultCallable);
		
		// Pump work into work executor
        for(int yPixel=0; yPixel<yPixels; yPixel++) {
        	for(int xPixel = 0; xPixel<xPixels; xPixel++) { 
        		final CalculatePixel work = new CalculatePixel(xPixel, yPixel);
    			workExecutor.execute(new Runnable() {
    				public void run() {
        				try {
	        				byte result = calculatePixel(work.getXPixel(), work.getYPixel());
	        				work.setValue(result);
	        				resultQueue.put(work);
        				} catch(InterruptedException e) {
        					// interrupted - exit
    					}
    				}
    			});
            }
        }        		
        
		// Wait for completion
    	byte[] results;
		try {
			results = finalResult.get();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		
        // Cleanup
        workExecutor.shutdown();
        resultExecutor.shutdown();
        
    	System.out.println("Results complete.");
        return results;
	}

	private class CalculatePixel {
		private final int xPixel;
		private final int yPixel;
		private byte value;
		
		public CalculatePixel(int xPixel, int yPixel) {
			this.xPixel = xPixel;
			this.yPixel = yPixel;
		}
		
		public int getXPixel() {
			return xPixel;
		}

		public int getYPixel() {
			return yPixel;
		}		
		
		public int getPixelIndex(int width) {
			return yPixel*width + xPixel;
		}
		
		public void setValue(byte value) {
			this.value = value;
		}
		
		public byte getValue() {
			return this.value;
		}
	}
}
