package mandel.generator.v7;

import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import mandel.AbstractGenerator;

public class CompletionServiceGenerator extends AbstractGenerator {

	// Configuration
	private final int concurrency;
	private final ExecutorService workExecutor;
	private final ExecutorService resultExecutor;

	public CompletionServiceGenerator(int concurrency) {
		this.concurrency = concurrency;
		this.workExecutor = Executors.newFixedThreadPool(concurrency);
		this.resultExecutor = Executors.newSingleThreadExecutor();
	}
	
	public String toString() {
		return "Fork/join (" + concurrency + ")";
	}
	
	public byte[] generate() {
		final CompletionService<CalculatePixel> completionService = new ExecutorCompletionService<CalculatePixel>(workExecutor);

        // Read and assemble results
        Callable<byte[]> resultCallable = new Callable<byte[]>() {
        	public byte[] call() throws Exception {
        		byte[] data = new byte[totalPixels];
        		try {
	        		for(int i=0; i<totalPixels; i++) {
        				Future<CalculatePixel> completedResult = completionService.take();		// LOOK
        				CalculatePixel result = completedResult.get();
        				data[result.getPixelIndex(getWidth())] = result.getValue();
	        		}
    			} catch(InterruptedException e) {
    			}
        		return data;
        	}
        };
        Future<byte[]> finalResult = resultExecutor.submit(resultCallable);
		
		// Pump work into work executor
        for(int yPixel=0; yPixel<yPixels; yPixel++) {
        	for(int xPixel = 0; xPixel<xPixels; xPixel++) { 
        		final CalculatePixel work = new CalculatePixel(xPixel, yPixel);
    			completionService.submit(new Callable<CalculatePixel>() {		// LOOK
    				public CalculatePixel call() {
        				byte result = calculatePixel(work.getXPixel(), work.getYPixel());
        				work.setValue(result);
        				return work;
    				}
    			});
            }
        }        		
        
		// Wait for completion
    	byte[] results;
		try {
			results = finalResult.get();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		
        // Cleanup
        workExecutor.shutdown();
        resultExecutor.shutdown();
        
    	System.out.println("Results complete.");
        return results;
	}

	private class CalculatePixel {
		private final int xPixel;
		private final int yPixel;
		private byte value;
		
		public CalculatePixel(int xPixel, int yPixel) {
			this.xPixel = xPixel;
			this.yPixel = yPixel;
		}
		
		public int getXPixel() {
			return xPixel;
		}

		public int getYPixel() {
			return yPixel;
		}		
		
		public int getPixelIndex(int width) {
			return yPixel*width + xPixel;
		}
		
		public void setValue(byte value) {
			this.value = value;
		}
		
		public byte getValue() {
			return this.value;
		}
	}
}
