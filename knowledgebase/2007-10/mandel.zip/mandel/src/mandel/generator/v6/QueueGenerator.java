package mandel.generator.v6;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.SynchronousQueue;

import mandel.AbstractGenerator;

public class QueueGenerator extends AbstractGenerator {

	// Configuration
	private final int concurrency;

	public QueueGenerator(int concurrency) {
		this.concurrency = concurrency;
	}
	
	public String toString() {
		return "Queue (" + concurrency + ")";
	}
	
	public byte[] generate() {
		final BlockingQueue<CalculatePixel> workQueue = new LinkedBlockingQueue<CalculatePixel>();
		final BlockingQueue<CalculatePixel> resultQueue = new LinkedBlockingQueue<CalculatePixel>();
		final BlockingQueue<byte[]> dataQueue = new SynchronousQueue<byte[]>();

		// Start worker threads
        Thread[] threads = new Thread[concurrency];
        for(int t = 0; t<concurrency; t++) {
        	final String name = "Thread " + t;
        	threads[t] = new Thread(new Runnable() { 
        		public void run() {
        			System.out.println(name + " starting");
        			
        			while(true) {
        				try {
	        				CalculatePixel work = workQueue.take();
	        				byte result = calculatePixel(work.getXPixel(), work.getYPixel());
	        				work.setValue(result);
	        				resultQueue.put(work);
        				} catch(InterruptedException e) {
        					break;
        				}
        			}

        			System.out.println(name + " done");
        		}
        	});
        	threads[t].start();
        }
        
        // Start result thread
        Thread resultThread = new Thread(new Runnable() {
        	public void run() {
        		byte[] data = new byte[totalPixels];
        		for(int i=0; i<totalPixels; i++) {
        			try {
        				CalculatePixel result = resultQueue.take();
        				data[result.getPixelIndex(getWidth())] = result.getValue();
        			} catch(InterruptedException e) {
        				break;
        			}
        		}
        		try {
        			dataQueue.put(data);
        		} catch(InterruptedException e) {}
        	}
        });
        resultThread.start();
        
		// Pump work into queue
        for(int yPixel=0; yPixel<yPixels; yPixel++) {
        	for(int xPixel = 0; xPixel<xPixels; xPixel++) { 
        		try {
        			workQueue.put(new CalculatePixel(xPixel, yPixel));
        		} catch(InterruptedException e) {}
            }
        }        		
		
		// Wait for completion
        byte[] results = null;
        try {
        	results = dataQueue.take();
        } catch(InterruptedException e) {
        	throw new RuntimeException();
        }
        
        // Interrupt all worker threads and let them finish
        for(int t=0; t<threads.length; t++) {
        	threads[t].interrupt();
        }
        
    	System.out.println("Results complete.");
        return results;
	}

	private class CalculatePixel {
		private final int xPixel;
		private final int yPixel;
		private byte value;
		
		public CalculatePixel(int xPixel, int yPixel) {
			this.xPixel = xPixel;
			this.yPixel = yPixel;
		}
		
		public int getXPixel() {
			return xPixel;
		}

		public int getYPixel() {
			return yPixel;
		}		
		
		public int getPixelIndex(int width) {
			return yPixel*width + xPixel;
		}
		
		public void setValue(byte value) {
			this.value = value;
		}
		
		public byte getValue() {
			return this.value;
		}
	}
}
