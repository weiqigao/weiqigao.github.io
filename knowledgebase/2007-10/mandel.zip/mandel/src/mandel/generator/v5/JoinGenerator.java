package mandel.generator.v5;

import mandel.AbstractGenerator;
import mandel.generator.v4.Results;

public class JoinGenerator extends AbstractGenerator {

	// Configuration
	private final int concurrency;

	// State
	private final Results results;	
	
	public JoinGenerator(int concurrency, Results results) {
		this.concurrency = concurrency;
		this.results = results;
	}
	
	public String toString() {
		String resultType = (results == null) ? "NONE" : results.getClass().getSimpleName();
		return "Join (" + concurrency + ") - " + resultType;
	}
	
	public byte[] generate() {
		final CalculatePixel[] work = generateWork();
		results.initialize(totalPixels);
    	
        Thread[] threads = new Thread[concurrency];
        for(int t = 0; t<concurrency; t++) {
        	final int[] workRange = calculateRange(t);
        	
        	final String name = "Thread " + t;
        	threads[t] = new Thread(new Runnable() { 
        		public void run() {
        			System.out.println(name + " starting");
        			
        			for(int w=workRange[0]; w<=workRange[1]; w++) {
        				results.addResult(w, calculatePixel(work[w].getXPixel(), work[w].getYPixel()));
        			}

        			System.out.println(name + " done");
        		}
        	});
        }

        for(int t=0; t<concurrency; t++) {
        	threads[t].start();
        }

        // Wait for everyone to be done
        for(int t=0; t<concurrency; t++) {		// LOOK
        	while(true) {
            	try {
            		threads[t].join();
            		break;
            	} catch(InterruptedException e) {
            	}
        	}
        }
		
    	System.out.println("Results complete.");
		return results.getResults();
	}

	private CalculatePixel[] generateWork() {
		final CalculatePixel[] work = new CalculatePixel[totalPixels];
        int pixelIndex = 0;
        for(int yPixel=0; yPixel<yPixels; yPixel++) {
        	for(int xPixel = 0; xPixel<xPixels; xPixel++) {     
        		work[pixelIndex++] = new CalculatePixel(xPixel, yPixel);
            }
        }
		return work;
	}

	private int[] calculateRange(int thread) {
		int workPerThread = (int)Math.ceil(((double)totalPixels) / (double)concurrency);
    	int firstWork = thread * workPerThread;
    	int lastWork = Math.min(totalPixels-1, ((thread+1) * workPerThread)-1);
    	return new int[] { firstWork, lastWork };
	}

	private class CalculatePixel {
		private final int xPixel;
		private final int yPixel;
		
		public CalculatePixel(int xPixel, int yPixel) {
			this.xPixel = xPixel;
			this.yPixel = yPixel;
		}
		
		public int getXPixel() {
			return xPixel;
		}

		public int getYPixel() {
			return yPixel;
		}		
	}
	
}
