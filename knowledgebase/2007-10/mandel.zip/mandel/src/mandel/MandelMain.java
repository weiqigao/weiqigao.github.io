package mandel;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import mandel.ui.PointPanel;
import mandel.ui.StatusBarTimingDecorator;

public class MandelMain {
    private JFrame frame = new JFrame("Mandelbrot Set");
    private JPanel panel = new JPanel(new BorderLayout());
    private PointPanel mandelPanel = new PointPanel();
        
    private JTextField minxField;
    private JTextField minyField;
    private JTextField maxxField;
    private JTextField maxyField;
    private JTextField escapeField;
    private JComboBox strategyCombo;
    private JTextField concurrencyField;
    
    private JLabel statusLabel;
    
    public MandelMain() {
    	createComponents();
    }
    
    private void createComponents() {
        JPanel configPanel = new JPanel();
        configPanel.setLayout(new BoxLayout(configPanel, BoxLayout.X_AXIS));
        configPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
        
        minxField = addConfig("Min x", "-1.5", configPanel);
        maxxField = addConfig("Max x", "-0.5", configPanel);
        minyField = addConfig("Min y", "-0.4", configPanel);
        maxyField = addConfig("Max y", "0.4", configPanel);
        escapeField = addConfig("Escape", "50", configPanel);
        
        JButton button = new JButton("Render");
        button.addActionListener(new ActionListener() { 
        	public void actionPerformed(ActionEvent e) {
        		configAndPaint();
        	}
        });
        configPanel.add(button);                
        
        JPanel strategyPanel = new JPanel();
        strategyPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
        
        strategyPanel.add(new JLabel("Strategy"));
        strategyCombo = new JComboBox(RenderStrategy.values());
        strategyCombo.setSelectedIndex(0);
        strategyPanel.add(strategyCombo);
        strategyPanel.add(new JLabel("Concurrency"));
        concurrencyField = new JTextField("1", 6);
        strategyPanel.add(concurrencyField);
        
        JPanel controlPanel = new JPanel();        
        controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
        controlPanel.add(configPanel);
        controlPanel.add(strategyPanel);

        panel.add(controlPanel, BorderLayout.NORTH);

        mandelPanel.setPreferredSize(new Dimension(800, 600));
        panel.add(mandelPanel, BorderLayout.CENTER);
        
        statusLabel = new JLabel("Welcome to Mandelbrot!");
        statusLabel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
        panel.add(statusLabel, BorderLayout.SOUTH);
        
        panel.setBorder(BorderFactory.createEmptyBorder(5, 10, 0, 10));
    }
    
    private JTextField addConfig(String label, String initial, JPanel configPanel) {
        configPanel.add(new JLabel(label));
        JTextField field = new JTextField(initial, 6);
        configPanel.add(field);
        return field;
    }

    private void configAndPaint() {			// LOOK
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				frame.setCursor(new Cursor(Cursor.WAIT_CURSOR));
			}
		});
    	
    	mandelPanel.setMinx(Float.parseFloat(minxField.getText()));
    	mandelPanel.setMaxx(Float.parseFloat(maxxField.getText()));
    	mandelPanel.setMiny(Float.parseFloat(minyField.getText()));
    	mandelPanel.setMaxy(Float.parseFloat(maxyField.getText()));
    	mandelPanel.setEscape(Integer.parseInt(escapeField.getText()));

    	RenderStrategy strategy = (RenderStrategy) strategyCombo.getSelectedItem();
    	
    	int concurrency = Integer.parseInt(concurrencyField.getText());
    	SetGenerator generator = strategy.newGenerator(concurrency);
    	generator = new TimingDecorator(generator);
    	generator = new StatusBarTimingDecorator(generator, this.statusLabel);
    	mandelPanel.setGenerator(generator);
    	
    	mandelPanel.repaint();
    	
    	SwingUtilities.invokeLater(new Runnable() {
    		public void run() {
    			frame.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    		}
    	});

    }
    
    private void createAndShowGUI() {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel.setOpaque(true);
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) throws Exception {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MandelMain().createAndShowGUI();
            }
        });
    }
}