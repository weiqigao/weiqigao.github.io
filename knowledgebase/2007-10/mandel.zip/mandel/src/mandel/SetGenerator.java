package mandel;

public interface SetGenerator {

	/**
	 * Initialize the generator
	 * @param minx Minimum x value (the reals)
	 * @param maxx Maximum x value (the reals)
	 * @param miny Minimum y value (the imaginaries)
	 * @param maxy Maximum y value (the imaginaries)
	 * @param xPixels Width in pixels
	 * @param yPixels Height in pixels
	 * @param escape Max iterations to try
	 */
	void setBounds(float minx, float maxx, float miny, float maxy, int xPixels, int yPixels, int escape);
	
	/**
	 * Generates the data
	 * @return Array of escape values, indexed per row/column
	 */
	byte[] generate();
	
	/**
	 * Get width in pixels
	 * @return Width
	 */
	int getWidth();
	
	/**
	 * Get height in pixels 
	 * @return Height
	 */
	int getHeight();
}
