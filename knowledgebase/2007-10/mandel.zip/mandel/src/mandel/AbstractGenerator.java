package mandel;

public abstract class AbstractGenerator implements SetGenerator {

    // Window boundaries
    protected float minX;
    protected float minY;
    protected float maxX;
    protected float maxY;
    
    // Pixels
    protected int xPixels;
    protected int yPixels;

    // Max escape iteration
    protected int escapeIteration;
    
    // Derived values
    protected float xRange;
    protected float yRange;
    protected float xUnit;
    protected float yUnit;
    protected int totalPixels;

	public abstract byte[] generate();

    public int getWidth() {
        return xPixels;
    }
    
    public int getHeight() {
        return yPixels;
    }

	public void setBounds(float minx, float maxx, float miny, float maxy,
			int xPixels, int yPixels, int escape) {

        this.minX = minx;
        this.minY = miny;
        this.maxX = maxx;
        this.maxY = maxy;
        
        this.xPixels = xPixels;
        this.yPixels = yPixels;
        
        this.escapeIteration = escape;
        
        // Calculate derived values
        xRange = maxX - minX;
        yRange = maxY - minY;
        xUnit = xRange / xPixels;
        yUnit = yRange / yPixels;
        totalPixels = xPixels * yPixels;
	}
	
	protected byte[] initializeData() {
        return new byte[totalPixels];    
	}
	
	protected byte calculatePixel(int xPixel, int yPixel) {
        float x = minX + (xPixel * xUnit);
        final float x0 = x;

        float y = minY + (yPixel * yUnit);
        final float y0 = y;                
        
        int iteration = 0;               
        while(x*x + y*y < 4 && iteration < escapeIteration) {
            float xtemp = x*x - y*y + x0;
            y = 2*x*y + y0;
            x = xtemp;
            iteration++;
        }
        
		if(iteration >= escapeIteration) {
            return 0;
        } else {
            return (byte) ((iteration % 255) + 1);
        }
	}

}
