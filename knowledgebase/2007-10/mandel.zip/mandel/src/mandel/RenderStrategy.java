package mandel;

import mandel.generator.v1.SerialGenerator;
import mandel.generator.v2.MultiThreadGenerator;
import mandel.generator.v3.MultiThreadAtomicGenerator;
import mandel.generator.v4.LockResults;
import mandel.generator.v4.MultiThreadSafeGenerator;
import mandel.generator.v4.RWLockResults;
import mandel.generator.v4.SynchronizedResults;
import mandel.generator.v5.CyclicBarrierGenerator;
import mandel.generator.v5.JoinGenerator;
import mandel.generator.v5.LatchGenerator;
import mandel.generator.v6.QueueGenerator;
import mandel.generator.v7.ExecutorGenerator;
import mandel.generator.v8.ForkJoinGenerator;
import mandel.generator.v8.SmartForkJoinGenerator;

public enum RenderStrategy {
	V1_SERIAL("v1. Serial"), 
	V2_MULTI("v2. Multi"), 
	V3_ATOMIC("v3. Multi atomic"), 
	V4_SAFE_SYNCH("v4. Multi safe - synchronized"),
	V4_SAFE_LOCK("v4. Multi safe - lock"),
	V4_SAFE_RWLOCK("v4. Multi safe - rw lock"),
	V5_JOIN("v5. Join"),
	V5_LATCH("v5. Latch"),
	V5_CYCLIC_BARRIER("v5. Cyclic barrier"),
	V6_QUEUE("v6. Queue"),
	V7_EXECUTOR("v7. Executor"),
	V8_FORKJOIN("v8. ForkJoin"),
	V8_SMARTFORKJOIN("v8. Smart ForkJoin");
	
	
	private String description;
	private RenderStrategy(String description) {
		this.description = description;
	}
	
	public SetGenerator newGenerator(int concurrency) {
		if(this.equals(V1_SERIAL)) {
			return new SerialGenerator();
		} else if(this.equals(V2_MULTI)) {
			return new MultiThreadGenerator(concurrency);
		} else if(this.equals(V3_ATOMIC)) {
			return new MultiThreadAtomicGenerator(concurrency);
		} else if(this.equals(V4_SAFE_SYNCH)) {
			return new MultiThreadSafeGenerator(concurrency, new SynchronizedResults());
		} else if(this.equals(V4_SAFE_LOCK)) {
			return new MultiThreadSafeGenerator(concurrency, new LockResults());
		} else if(this.equals(V4_SAFE_RWLOCK)) {
			return new MultiThreadSafeGenerator(concurrency, new RWLockResults());
		} else if(this.equals(V5_JOIN)) {
			return new CyclicBarrierGenerator(concurrency, new RWLockResults());
		} else if(this.equals(V5_LATCH)) {
			return new LatchGenerator(concurrency, new RWLockResults());
		} else if(this.equals(V5_CYCLIC_BARRIER)) {
			return new JoinGenerator(concurrency, new RWLockResults());
		} else if(this.equals(V6_QUEUE)) {
			return new QueueGenerator(concurrency);
		} else if(this.equals(V7_EXECUTOR)) {
			return new ExecutorGenerator(concurrency);
		} else if(this.equals(V8_FORKJOIN)) {
			return new ForkJoinGenerator(concurrency);
		} else if(this.equals(V8_SMARTFORKJOIN)) {
			return new SmartForkJoinGenerator(concurrency, 20000);
		}
		
		throw new IllegalStateException("Unknown generator specified for " + this);
	}
	
	public String toString() {
		return this.description;
	}
	
}
