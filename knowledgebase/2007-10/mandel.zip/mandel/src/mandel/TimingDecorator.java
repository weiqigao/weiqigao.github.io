package mandel;


public class TimingDecorator implements SetGenerator {

	private SetGenerator generator;
	
	public TimingDecorator(SetGenerator generator) {
		this.generator = generator;
	}
	
	public byte[] generate() {
		preMessage();
		
		long start = System.currentTimeMillis();
		byte[] result = this.generator.generate();
		long end = System.currentTimeMillis();
		
		int pixels = getHeight()*getWidth();
		long elapsed = end-start;
		long ppms = pixels / elapsed;
		postMessage(pixels, elapsed, ppms);

		return result;
	}

	public int getHeight() {
		return generator.getHeight();
	}

	public int getWidth() {
		return generator.getWidth();
	}

	public void setBounds(float minx, float maxx, float miny, float maxy,
			int xPixels, int yPixels, int escape) {
		generator.setBounds(minx, maxx, miny, maxy, xPixels, yPixels, escape);
	}
	
	protected void preMessage() {
		writeMessage("\nCalculating with " + generator);
	}
	
	protected void postMessage(int pixels, long elapsed, long ppms) {
		writeMessage("Calculated " + pixels + " pixels in " + elapsed + " millis, ppms = " + ppms);
	}
	
	protected void writeMessage(String message) {
		System.out.println(message);
	}

}
