
package org.cas.judemo;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 *
 * @author cas
 */
public class ParrotTestSuite extends TestCase {
    
    public ParrotTestSuite(String testName) {
        super(testName);
    }            

    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public static Test suite() {
        TestSuite suite = new TestSuite();
        suite.addTest(new TestSuite(ParrotTest.class));
        // suite.addTest(new TestSuite(PetShoppeTest.class));
        suite.addTest(new PetShoppeTest("testCheckParrotWithOwner"));
        suite.addTest(new PetShoppeTest("testCheckParrotWithCustomer"));
        return suite;
    }
}
