
package ju4examples;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.Test;

/**
 * @author cas
 */

public class ShowTimeoutTest {

    @Test(timeout = 100)
    public void showTimeout() {
        try {
            Thread.sleep(100);
        } catch (InterruptedException ex) {
            Logger.getLogger(ShowTimeoutTest.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}