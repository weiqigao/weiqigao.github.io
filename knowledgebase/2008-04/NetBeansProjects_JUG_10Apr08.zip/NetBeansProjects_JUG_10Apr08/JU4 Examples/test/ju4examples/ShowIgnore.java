
package ju4examples;

import org.junit.Test;
import static org.junit.Assert.assertTrue;
import org.junit.Ignore;

/**
 *
 * @author cas
 */
public class ShowIgnore {

    @Test
    public void testExistingMethod() {
        assertTrue(true);
    }

    @Ignore("Hasn't been written yet.")
    @Test
    public void testNonexistentMethod() {
        assertTrue(true);
    }

    @Test
    public void testExistingMethod1() {
        assertTrue(true);
    }

}
