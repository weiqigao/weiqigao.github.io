
package ju4examples;

import java.util.ArrayList;
import org.junit.Test;

/**
 *
 * @author cas
 */
public class ShowException {

    @Test
    public void testIndexOutOfBoundsException3_8() {
        try {
            Object o = new ArrayList().get(1);
        } catch (IndexOutOfBoundsException ioobe) {
            System.out.println("As expected...");
        }
    }

    @Test(expected=IndexOutOfBoundsException.class)
    public void testIndexOutOfBoundsException4_4() {
        Object o = new ArrayList().get(1);
    }

    @Test(expected=IndexOutOfBoundsException.class)
    public void testIndexOutOfBoundsException4_4_uhoh() {
        System.out.println("No nasty exceptions here!");
    }

    @Test(expected=IndexOutOfBoundsException.class)
    public void testArithmeticException4_4() {
        int n = 15 / 0;
    }
}
