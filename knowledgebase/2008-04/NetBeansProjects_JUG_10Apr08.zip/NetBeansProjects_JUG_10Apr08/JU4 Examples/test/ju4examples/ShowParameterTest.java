
package ju4examples;

import java.util.Arrays;
import java.util.Collection;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import static org.junit.Assert.*;

/**
 *
 * @author cas
 */
@RunWith(Parameterized.class)
public class ShowParameterTest {
    private int expectedSum;
    private int addend1;
    private int addend2;

    public ShowParameterTest(int expectedSum, int addend1, int addend2) {
        this.expectedSum = expectedSum;
        this.addend1 = addend1;
        this.addend2 = addend2;
    }

    /*
    public ShowParameterTest(int expectedSum, String string1, int addend2) {
        this.expectedSum = expectedSum;
        this.addend1 = Integer.parseInt(string1);
        this.addend2 = addend2;
    }
     */

  @Parameters
  public static Collection data () {
      Object [][] additionTestData = new Object [] [] {
            {0, 0, 0}, 
            {1, 1, 0}, 
            {2, 1, 1}, 
            {3, 2, 1}, 
            {4, 3, 1}, 
            {5, 5, 0}, 
            {6, 8, -2},
            {42, 20, 22},
        };
     return Arrays.asList(additionTestData);
  }
		
  @Test
  public void testAdd() {
    assertEquals(expectedSum, (addend1 + addend2));
    
  }

}
