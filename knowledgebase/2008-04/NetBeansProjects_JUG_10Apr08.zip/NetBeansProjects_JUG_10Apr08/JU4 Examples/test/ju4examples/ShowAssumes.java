
package ju4examples;

import org.junit.After;
import org.junit.Test;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;
import static org.junit.Assume.*;

/**
 *
 * @author cas
 */
public class ShowAssumes {

    @After
    public void tearDown() {
        System.out.println("made it to tearDown");
    }

    @Test
    public void testAssumeThat() {
        Integer I = new Integer(3);
        assumeThat(I, is(4));
        System.out.println("Shouldn't see this.");
        assertThat(I, is(4));
    }

    @Test
    public void testAssumeNotNull() {
        Integer I = null;
        assumeNotNull(I);
        System.out.println("Shouldn't see this either.");
        int i = I.intValue();
    }

    @Test
    public void testAssumeTrue() {
        String s = "bee's knees";
        assumeTrue(s.equals("sliced bread"));
        System.out.println("Nope, not this one.");
        assertThat(s, not(s));
       
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testAssumeNoException() {
        try {
            int n = 15 / 0;
        } catch (ArithmeticException ae) {
            assumeNoException(ae);
            System.out.println("Yikes!");
        }
    }
}
