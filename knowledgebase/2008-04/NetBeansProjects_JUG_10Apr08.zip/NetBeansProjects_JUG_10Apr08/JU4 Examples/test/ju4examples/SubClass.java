package ju4examples;


import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.junit.BeforeClass;


public class SubClass extends BaseClass {


	public SubClass() {
		super();
	}

	@BeforeClass
	public static void subClassSetUp() {
		System.out.println("Sub Class setup");
	}

	@AfterClass
	public static void subClassTearDown() {
		System.out.println("Sub Class tear down");
	}

	@Before
	public void subSetUp() {
		System.out.println("Sub Test setup");
	}

	@After
	public void subTearDown() {
		System.out.println("Sub Test tear down");
	}

    @Test
	@Override
    public void test1() {
		System.out.println("Sub Test 1");
    }

    @Test
	@Override
    public void test2() {
		System.out.println("Sub Test 2");
    }
}