package ju4examples;


import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


/**
 * @author cas
 */
public class BaseClass {

	public BaseClass() {
		super();
	}

	@BeforeClass
	public static void parentClassSetUp() {
		System.out.println("Parent Class setup");
	}

	@AfterClass
	public static void parentClassTearDown() {
		System.out.println("Parent Class tear down");
	}

	@Before
	public void parentSetUp() {
		System.out.println("Parent Test setup");
	}

	@After
	public void parentTearDown() {
		System.out.println("Parent Test tear down");
	}

    @Test
    public void test1() {
		System.out.println("Parent Test 1");
    }

    @Test
    public void test2() {
		System.out.println("Parent Test 2");
    }
}