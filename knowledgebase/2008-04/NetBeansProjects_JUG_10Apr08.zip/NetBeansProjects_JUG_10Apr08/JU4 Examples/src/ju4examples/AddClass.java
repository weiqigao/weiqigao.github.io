
package ju4examples;

/**
 *
 * @author cas
 */
public class AddClass {
    public int add(int addend1, int addend2) {
        return addend1 + addend2;
    }

}
