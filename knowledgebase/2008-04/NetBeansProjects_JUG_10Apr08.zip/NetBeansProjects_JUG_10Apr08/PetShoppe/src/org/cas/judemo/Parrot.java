
package org.cas.judemo;

/**
 *
 * @author cas
 */
public class Parrot {
    private String breed = null;
    private boolean liveness = false;
    
    Parrot() {
        this.breed = "Norwegian Blue";
        this.liveness = false;
    }
    
    Parrot(String breed, boolean alive) {
        this.breed = breed;
        this.liveness = alive;
    }
    
    String getBreed() {
        return breed;
    }
    
    boolean isAlive() {
        return liveness;
    }
   
    void setAlive(boolean viable) {
        liveness = viable;
    }
}
