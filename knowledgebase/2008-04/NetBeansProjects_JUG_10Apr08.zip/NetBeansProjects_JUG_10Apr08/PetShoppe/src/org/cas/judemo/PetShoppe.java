
package org.cas.judemo;

import java.util.Random;

/**
 *
 * @author cas
 */
public class PetShoppe {
    private static final Random random = new Random();
    
    
    private String[] ownerEval = {
        "he's, he's restin'! Remarkable bird, the Norwegian Blue, idn'it, ay? Beautiful plumage!",
        "'e's uh,...he's resting.",
        "'e's stunned!",
        "tired and shagged out following a prolonged squawk.",
        "ah...probably pining for the fjords.",
        "'E's pining!"};

    private String[] customerEval = {
        "'E's dead, that's what's wrong with it!",
        "It's stone dead.",
        "definitely deceased,", 
        "'E's bleedin' demised!",
        "'E's passed on!",
        "This parrot is no more!",
        "He has ceased to be!",
        "'E's expired and gone to meet 'is maker!",
        "'E's a stiff!",
        "Bereft of life",
        "'e rests in peace!",
        "pushing up the daisies!",
        "'Is metabolic processes are now 'istory!",
        "'E's off the twig!",
        "'E's kicked the bucket",
        "'e's shuffled off 'is mortal coil",
        "run down the curtain",
        "joined the bleedin' choir invisibile",
        "THIS IS AN EX-PARROT!!"};

    private String loc1 = "Ipswitch";
    private String loc2 = "Bolton";
    
    public String checkParrotWithOwner(Parrot aParrot) {
        return ownerEval[random.nextInt(ownerEval.length)];
    }
    
    public String checkParrotWithCustomer(Parrot aParrot) {
        return customerEval[random.nextInt(ownerEval.length)];
    }
}
