
package org.cas.judemo;

import org.junit.*;
import static org.junit.Assert.*;

/**
 *
 * @author cas
 */
public class ParrotTest {
    
    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getBreed method, of class Parrot.
     * Default constructor
     */
    @Test
    public void testGetBreedDefaultConstruction() {
        Parrot instance = new Parrot();
        String expResult = "Norwegian Blue";
        String result = instance.getBreed();
        assertEquals(expResult, result);
    }

    /**
     * Test of isAlive method, of class Parrot.
     * Default contructor
     */
    @Test
    public void testIsAliveDefaultConstruction() {
        Parrot instance = new Parrot();
        boolean expResult = false;
        boolean result = instance.isAlive();
        assertEquals(expResult, result);
    }
    /**
     * Test of getBreed method, of class Parrot.
     * Constructed with arguments
     */
    @Test
    public void testGetBreedArgConstruction() {
        Parrot instance = new Parrot("African Grey", true);
        String expResult = "African Grey";
        String result = instance.getBreed();
        assertEquals(expResult, result);
    }

    /**
     * Test of isAlive method, of class Parrot.
     * Constructed with arguments.
     */
    @Test
    public void testIsAliveArgConstruction() {
        Parrot instance = new Parrot("African Grey", true);
        boolean expResult = true;
        assertEquals(expResult, instance.isAlive());
    }

    @Test
    public void testSetAlive() {
        Parrot instance = new Parrot();
        boolean currentState = instance.isAlive();
        instance.setAlive(!currentState);
        boolean actualState = instance.isAlive();
        assertEquals(!currentState, actualState);
        instance.setAlive(currentState);
        assertEquals(currentState, instance.isAlive());
    }
}