
package org.cas.judemo;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 *
 * @author cas
 */
@RunWith(Suite.class)
@SuiteClasses({
    ParrotTest.class,
    PetShoppeTest.class
})

public class ParrotTestSuite {
    

    protected void setUp() {
    }

    protected void tearDown() {
    }
}
