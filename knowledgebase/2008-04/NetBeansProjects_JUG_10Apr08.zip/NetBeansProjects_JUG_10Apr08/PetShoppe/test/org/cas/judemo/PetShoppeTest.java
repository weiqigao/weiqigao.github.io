
package org.cas.judemo;

import org.junit.*;
import static org.junit.Assert.*;

/**
 * @author cas
 */
public class PetShoppeTest {
    
    /**
     * Test of checkParrotWithOwner method, of class PetShoppe.
     */
    @Test
    public void testCheckParrotWithOwner() {
        Parrot aParrot = new Parrot();
        PetShoppe instance = new PetShoppe();
        String result = instance.checkParrotWithOwner(aParrot);
        System.out.println("result: " + result);
        assertTrue(checkOwnerResult(result));
    }

    /**
     * Test of checkParrotWithCustomer method, of class PetShoppe.
     */
    @Test
    public void testCheckParrotWithCustomer() {
        Parrot aParrot = new Parrot();
        PetShoppe instance = new PetShoppe();
        String result = instance.checkParrotWithCustomer(aParrot);
        System.out.println("result:" + result);
        assertTrue(checkCustomerResult(result));
    }

    // End of tests
      private String[] ownerConditions = {
        "he's, he's restin'! Remarkable bird, the Norwegian Blue, idn'it, ay? Beautiful plumage!",
        "'e's uh,...he's resting.",
        "'e's stunned!",
        "tired and shagged out following a prolonged squawk.",
        "ah...probably pining for the fjords.",
        "'E's pining!"};
      
    private boolean checkOwnerResult(String resultToCheck) {
        for (String condition : ownerConditions) {
            if (condition.equals(resultToCheck)) return true;
        }
        return false;
    }
    
    private String[] customerConditions = {
        "'E's dead, that's what's wrong with it!",
        "It's stone dead.",
        "definitely deceased,", 
        "'E's bleedin' demised!",
        "'E's passed on!",
        "This parrot is no more!",
        "He has ceased to be!",
        "'E's expired and gone to meet 'is maker!",
        "'E's a stiff!",
        "Bereft of life",
        "'e rests in peace!",
        "pushing up the daisies!",
        "'Is metabolic processes are now 'istory!",
        "'E's off the twig!",
        "'E's kicked the bucket",
        "'e's shuffled off 'is mortal coil",
        "run down the curtain",
        "joined the bleedin' choir invisibile",
        "THIS IS AN EX-PARROT!!"};
  
    private boolean checkCustomerResult(String resultToCheck) {
        for (String condition : customerConditions) {
            if (condition.equals(resultToCheck)) return true;
        }
        return false;
    } 
}
