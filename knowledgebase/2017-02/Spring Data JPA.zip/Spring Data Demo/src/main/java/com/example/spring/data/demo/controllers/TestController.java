package com.example.spring.data.demo.controllers;

import com.example.spring.data.demo.domain.User;
import com.example.spring.data.demo.repository.UserRepository;
import com.example.spring.data.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * Created by dennyslover on 7/17/16.
 */


    // h2 JDBC --> jdbc:h2:mem:testdb

    // http://localhost:8080/h2-console

@RestController
public class TestController {

    @Autowired
    private UserService userService;


    @RequestMapping("/")
    String test() {
        return "Hello World!";
    }

    @RequestMapping(value = "/users", method = RequestMethod.GET)
    List<User> retrieveAllUsers(){
        return userService.findAll();
    }

    @RequestMapping(value = "/user/{userid}", method = RequestMethod.GET)
    User retrieveSingleUsers(@PathVariable Long userid){
        return userService.findByUserId(userid);
    }

    @RequestMapping(value = "/user", method = RequestMethod.POST)
    ResponseEntity createUser(@RequestBody User user){
        userService.createUser(user);
        return new ResponseEntity(HttpStatus.CREATED);
    }

    @RequestMapping(value = "/user", method = RequestMethod.PUT)
    User updateUser(@RequestBody  User user){
        return userService.updateUser(user);
    }

    @RequestMapping(value = "/user/{userId}", method = RequestMethod.DELETE)
    ResponseEntity deleteUser(@PathVariable Long userId){
        userService.deleteUser(userId);
        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }


    @RequestMapping(value = "/test/{testStr}", method = RequestMethod.GET)
    ResponseEntity testUser(@PathVariable String testStr){
        User response = userService.testService(testStr);
        return new ResponseEntity(response, HttpStatus.OK);
    }


}