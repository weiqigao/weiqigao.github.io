package com.example.spring.data.demo.service;

import com.example.spring.data.demo.domain.User;
import com.example.spring.data.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by dennyslover on 7/19/16.
 */

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> findAll() {
        return userRepository.findAll();
    }


    public User findByUserId(Long userId) {
        return userRepository.findOne(userId);
    }

    public User updateUser(User user) {
        User currentUser = userRepository.findOne(user.getUserId());
        user.setUserId(currentUser.getUserId());
        return userRepository.save(user);
    }

    public void deleteUser(Long userId) {
        User deleteUser = userRepository.findOne(userId);
        userRepository.delete(deleteUser);
    }

    public User createUser(User user) {
        return userRepository.save(user);
    }

    public User testService(String testStr) {
        return userRepository.findByFirstNameIgnoreCase(testStr);
    }
}
