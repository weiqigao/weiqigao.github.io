package com.example.spring.data.demo;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.SpringApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * Created by dennyslover on 7/16/16.
 */


// h2 JDBC --> jdbc:h2:mem:testdb

@EnableJpaRepositories
@SpringBootApplication
public class DemoApp {

    public static void main(String[] args) {
        SpringApplication.run(DemoApp.class, args);
    }
}
