package com.example.spring.data.demo.domain;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


/**
 * Created by dennyslover on 7/17/16.
 */

@Entity
@Data
public class Application {

    @Id
    @Column(name = "APPLICATION_ID")
    private Long applicationId;

    @Column(name = "USER_ID")
    private Long userId;

    @Column(name = "APPLICATION_NAME")
    private String applicationName;

    @Column(name = "APPLICATION_DESCRIPTION")
    private String applicationDescription;
}
