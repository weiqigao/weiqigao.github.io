package com.example.spring.data.demo.repository;
import com.example.spring.data.demo.domain.User;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by dennyslover on 7/16/16.
 */

@Repository
public interface UserRepository  extends JpaRepository<User, Long> {

    List<User> findAll();

    User findByFirstNameIgnoreCase(String firstName);

    List<User> findByRoleRoleName(String roleName);



}
