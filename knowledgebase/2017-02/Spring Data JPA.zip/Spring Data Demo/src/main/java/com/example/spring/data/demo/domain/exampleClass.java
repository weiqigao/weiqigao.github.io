package com.example.spring.data.demo.domain;

/**
 * Created by denny on 30/10/16.
 */
public class exampleClass {

    private String str;
    
    private Boolean active;

    public Boolean getActive() {
        return this.active;
    }
}
