insert into ROLE (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION ) values (100, 'ADMIN', 'Admin');
insert into ROLE (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION ) values (101, 'MANAGER', 'Manager');
insert into ROLE (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION ) values (102, 'USER', 'User');


insert into USER (USER_ID, FIRST_NAME, LAST_NAME, USER_NAME, ROLE_ID ) values (100, 'Luke', 'Skywalker', 'LSKY', (select role_id from ROLE where ROLE_NAME = 'USER'));
insert into USER (USER_ID, FIRST_NAME, LAST_NAME, USER_NAME, ROLE_ID ) values (101, 'Han', 'Solo', 'HSOL', (select role_id from ROLE where ROLE_NAME = 'USER'));
insert into USER (USER_ID, FIRST_NAME, LAST_NAME, USER_NAME, ROLE_ID ) values (102, 'Darth', 'Vader', 'DVad', (select role_id from ROLE where ROLE_NAME = 'MANAGER'));
insert into USER (USER_ID, FIRST_NAME, LAST_NAME, USER_NAME, ROLE_ID ) values (103, 'General', 'Moff', 'GENM', (select role_id from ROLE where ROLE_NAME = 'ADMIN'));

insert into APPLICATION (APPLICATION_ID, APPLICATION_NAME,APPLICATION_DESCRIPTION, USER_ID) values (100, 'HR','HR', 100);
insert into APPLICATION (APPLICATION_ID, APPLICATION_NAME,APPLICATION_DESCRIPTION, USER_ID) values (101, 'PAYROLL','Payroll', 100);
insert into APPLICATION (APPLICATION_ID, APPLICATION_NAME,APPLICATION_DESCRIPTION, USER_ID) values (102, 'DATABASE','DATABASE', 101);
insert into APPLICATION (APPLICATION_ID, APPLICATION_NAME,APPLICATION_DESCRIPTION, USER_ID) values (103, 'CMS','CMS', 102);
