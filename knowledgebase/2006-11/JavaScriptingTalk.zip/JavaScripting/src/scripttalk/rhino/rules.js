function canDrag() {
	if(order.urgency == '2')
		return "ok";
	return "nope";
}

