package scripttalk.bsf;

public class Commands {
	public void write(String message) {
		System.out.println(message);
	}
}
