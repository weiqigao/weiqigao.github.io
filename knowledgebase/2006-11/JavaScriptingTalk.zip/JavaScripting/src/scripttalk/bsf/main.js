
function start() {
	commands.write("start called");
}

