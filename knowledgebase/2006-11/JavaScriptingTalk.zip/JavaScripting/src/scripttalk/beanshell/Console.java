/*
 * Created on Nov 4, 2006
 */
package scripttalk.beanshell;

public class Console {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		bsh.Console.main(args);
	}

}
